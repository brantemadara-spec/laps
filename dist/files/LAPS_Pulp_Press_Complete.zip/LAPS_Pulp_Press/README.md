# LAPS — reusable paper and autumn-leaf card mold

This package turns the undimensioned sketch in Laps.pdf into a reusable prototype for an 85 × 55 mm rounded card. The mold footprint is 130 × 100 mm. It uses two printed PETG faces, two purchased 8 mm steel backers, M6 through-bolts, two fine filter screens and one replaceable spacer ring.

## Start here

- `blender/LAPS_Blender_Prototips.py`: self-contained script to paste into Blender's Text Editor and run. It creates two plates and five rings, writes individual millimetre STL files and saves a prototype project under your home folder's `LAPS_prototips` directory. No external Python packages or STL add-ons are required. It was executed and checked in Blender 4.3.2.
- `docs/Blender_Lietosana_LV.pdf`: Latvian instructions for pasting/running the script, navigating Blender, checking dimensions and slicing the PETG prototype. Editable Markdown is alongside it.
- `procurement/LAPS_Pirkumu_saraksts_DEPO_Bergi.pdf`: Latvian shopping list with quantities, precise specifications, price sources and explicitly marked gaps in price verification. DEPO Berģi prices/stock are not directly verified; finished steel and fine mesh require quotations. `LAPS_Pirkumu_budzets.xlsx` provides editable confirmed-price fields.
- `docs/LAPS_Print_and_Experiment_Guide.pdf`: printing, shopping list, assembly, pressing, drying and material comparison.
- `drawings/LAPS_Pulp_Press_Technical_Drawings_RevA.pdf`: dimensioned views, sections, hole coordinates and full-size templates. Print only the identified template pages at **100% / actual size** and verify their scale bar.
- `blender/Pulp_Press.blend`: editable presentation with assembled, exploded, five-spacer, drainage and open-cavity scenes. Select the scene from Blender's scene selector. The model uses real metre coordinates and displays dimensions in millimetres.
- `ar/Pulp_Press_assembled.usdz`: real-scale iPhone AR model. Save to Files, open with Apple's Quick Look and select AR. `Pulp_Press_exploded.usdz` shows the separated components. Files passed structural and scale checks; they were not tested on an iPhone here.
- `renders/`: seven PNG views rendered from the Blender geometry, with Open Image Denoise used to remove stochastic render noise. The physical model is unchanged by this filter.
- `cad/`: printable STL files, editable CadQuery source, individual STEP files and the STEP assembly. The assembly omits purchased fasteners.

## Print and purchase

Print **two** copies of `cad/petg_drain_plate_PRINT_2.stl`, and one copy of each desired `gap_ring_*_PRINT_1.stl`. STL units are **millimetres**. The five actual ring heights are **1.4, 2.4, 3.4, 4.4 and 5.4 mm**. They correspond to nominal wet pulp gaps of **1–5 mm** only when each of the two compressed filter screens measures 0.20 mm. The rings are alternatives; use one at a time. Buy the steel, mesh and M6 hardware; the reference mesh files in `data/` are not printing parts.

The guide assumes the user's ELEGOO Carbon is a **Centauri Carbon with a 0.4 mm nozzle**. Every part fits its 256 × 256 mm bed. Slice with the profile for your exact printer and filament; no machine-specific G-code is supplied. Calibrate flow, check channel bridges and measure printed flatness before pressing.

The standalone Blender script's exports are a separate route: print `plate_A.stl` and `plate_B.stl` **once each**, rather than printing two copies of each. They are geometrically identical. Its seven-part scene is spread out for viewing; import individual STL files into the slicer. The checked output is in `blender/prototype_generated/`. Numeric mesh coordinates and STL values are millimetres; the Blender unit scale is 0.001. This differs from the metre-based presentation file `Pulp_Press.blend` described above.

## What the thickness and pressure settings mean

The spacer sets a **wet compressed gap**. Dry thickness, shrinkage and strength depend on the paper, leaf species, leaf fraction, solids charge and drying method. Measure dry samples and calibrate a custom ring if exact finished thickness is needed.

With the rounded cavity area of 4667.274 mm², **0.05, 0.10 and 0.20 MPa** correspond to approximately **233, 467 and 933 N** before the spacer carries load. These are proposed measured-force trials, **not a certified load rating or an established optimum**. Once the spacer seats, some load bypasses the pulp, so total force divided by cavity area no longer measures pulp pressure. Hand-tightened bolts are a repeatable closure method, not a pressure gauge. Use the cold-press procedure in the guide and keep the drains open.

## Modify and reproduce

Change dimensions and the measured mesh thickness in `cad/build_cad.py`, then run it with CadQuery installed. Rebuild the Blender file using `blender -b --factory-startup --python create_blender.py`. Blender exports GLB in metres; `validation/glb_to_usdz.py` converts it to the USDZ files. See `validation/README.md` for dependencies and checks, and `validation/Render_denoising.md` for the PNG noise-filter step. If a dimension changes, regenerate the drawings too; their source is `drawings/create_drawings.py`.

The Blender presentation uses the supplied 3 mm assembly layout. If you change the plate sizes, bolt pattern, mesh allowance or displayed gap, synchronize its constants and object positions with the revised CAD. Adding a custom printing ring alone can be done in the CadQuery source without changing this default presentation.

`data/cad_validation.json` records closed STL topology and STEP re-import checks. `validation/` holds AR and deliverable review reports. These checks verify digital geometry and file structure; a physical prototype still needs water-flow, flatness, fit and low-force trial checks.

Revision A · 6 October 2026
