#!/usr/bin/env python3
"""Rebuild the reusable paper/leaf-pulp press CAD package with CadQuery.

Units are millimetres. All exported individual PETG parts have their flat
draining back on Z=0, ready to orient for manufacture. The press face is Z=12.
The STEP assembly uses the 3 mm nominal wet-pulp setting and represents the
upper plate in its operating, face-down orientation.

Run: python /workspace/pulp_press/cad/build_cad.py
Requires: cadquery >= 2.7

This is a concept/prototype tool, not a certified force-rated press. The two
steel backers spread load; drainage channels remain between PETG and steel.
Gap labels compensate for TWO mesh sheets of nominal compressed thickness
0.2 mm each. Measure the mesh actually used and edit MESH_THICKNESS_MM.
"""

from pathlib import Path
import json
import math
import cadquery as cq


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "cad"
DATA = ROOT / "data"

# Edit these parameters and rerun to regenerate the complete CAD set.
OUTER_X_MM = 130.0
OUTER_Y_MM = 100.0
OUTER_RADIUS_MM = 6.0
PETG_PLATE_THICKNESS_MM = 12.0
STEEL_BACKER_THICKNESS_MM = 8.0
CAVITY_X_MM = 85.0
CAVITY_Y_MM = 55.0
CAVITY_RADIUS_MM = 3.0
BOLT_CLEARANCE_DIAMETER_MM = 6.6
BOLT_POINTS_MM = [(-53., -38.), (0., -38.), (53., -38.),
                  (-53., 0.), (53., 0.),
                  (-53., 38.), (0., 38.), (53., 38.)]
DRAIN_DIAMETER_MM = 2.0
DRAIN_GRID_X_MM = [float(x) for x in range(-35, 36, 7)]
DRAIN_GRID_Y_MM = [float(y) for y in range(-21, 22, 7)]
GROOVE_WIDTH_MM = 1.6
GROOVE_DEPTH_MM = 1.2
CENTRAL_CHANNEL_BRANCH_X_MM = 46.0
MESH_THICKNESS_MM = 0.2
MESH_X_MM = 84.5
MESH_Y_MM = 54.5
MESH_RADIUS_MM = 3.0
NOMINAL_PULP_GAPS_MM = [1, 2, 3, 4, 5]
ASSEMBLY_GAP_MM = 3
STL_LINEAR_TOLERANCE_MM = 0.05
STL_ANGULAR_TOLERANCE_RAD = 0.08


def rounded_plate(width, height, thickness, radius):
    """A filleted rectangle extruded from Z=0 with no face-edge rounding."""
    return (cq.Workplane("XY")
            .box(width, height, thickness, centered=(True, True, False))
            .edges("|Z").fillet(radius))


def drilled(part, diameter, points):
    return part.faces(">Z").workplane().pushPoints(points).hole(diameter)


def channel_box(xmin, xmax, ymin, ymax):
    # A tiny lower overcut avoids coincident surfaces at the back face.
    return (cq.Workplane("XY")
            .box(xmax - xmin, ymax - ymin, GROOVE_DEPTH_MM + 0.1,
                 centered=(True, True, False))
            .translate(((xmin + xmax) / 2, (ymin + ymax) / 2, -0.1)))


def make_petg_plate():
    p = rounded_plate(OUTER_X_MM, OUTER_Y_MM,
                      PETG_PLATE_THICKNESS_MM, OUTER_RADIUS_MM)
    p = drilled(p, BOLT_CLEARANCE_DIAMETER_MM, BOLT_POINTS_MM)
    drains = [(x, y) for y in DRAIN_GRID_Y_MM for x in DRAIN_GRID_X_MM]
    p = drilled(p, DRAIN_DIAMETER_MM, drains)
    half = GROOVE_WIDTH_MM / 2
    for y in DRAIN_GRID_Y_MM:
        if y != 0:
            p = p.cut(channel_box(-OUTER_X_MM/2-1, OUTER_X_MM/2+1,
                                  y-half, y+half))
    # Preserve bearing material surrounding the two mid-side bolt holes.
    # Centre-row drainage reaches the front edge via two vertical branches.
    bx = CENTRAL_CHANNEL_BRANCH_X_MM
    p = p.cut(channel_box(-bx-half, bx+half, -half, half))
    for x in (-bx, bx):
        p = p.cut(channel_box(x-half, x+half,
                              -OUTER_Y_MM/2-1, half))
    return p.clean()


def make_ring(nominal_pulp_gap):
    h = nominal_pulp_gap + 2*MESH_THICKNESS_MM
    ring = rounded_plate(OUTER_X_MM, OUTER_Y_MM, h, OUTER_RADIUS_MM)
    inner = (rounded_plate(CAVITY_X_MM, CAVITY_Y_MM, h+2,
                           CAVITY_RADIUS_MM).translate((0, 0, -1)))
    ring = ring.cut(inner)
    return drilled(ring, BOLT_CLEARANCE_DIAMETER_MM, BOLT_POINTS_MM).clean()


def make_backer():
    return drilled(rounded_plate(OUTER_X_MM, OUTER_Y_MM,
                                  STEEL_BACKER_THICKNESS_MM,
                                  OUTER_RADIUS_MM),
                   BOLT_CLEARANCE_DIAMETER_MM, BOLT_POINTS_MM).clean()


def describe_part(part, filename, material, qty, purpose, **extra):
    solids = part.solids().vals()
    assert len(solids) == 1, f"{filename}: expected one connected solid"
    shape = part.val()
    assert shape.isValid(), f"{filename}: invalid BREP"
    assert all(s.Closed() for s in shape.Shells()), f"{filename}: open shell"
    bb = shape.BoundingBox()
    meta = {
        "name": filename,
        "material": material,
        "quantity": qty,
        "purpose": purpose,
        "single_valid_closed_solid": True,
        "volume_mm3": round(shape.Volume(), 6),
        "bounds_mm": {"x_min": bb.xmin, "x_max": bb.xmax,
                      "y_min": bb.ymin, "y_max": bb.ymax,
                      "z_min": bb.zmin, "z_max": bb.zmax},
        **extra,
    }
    return meta


def export_part(part, filename, print_stl=True):
    cq.exporters.export(part, str(OUT / (filename + ".step")))
    if print_stl:
        cq.exporters.export(part, str(OUT / (filename + ".stl")),
                            tolerance=STL_LINEAR_TOLERANCE_MM,
                            angularTolerance=STL_ANGULAR_TOLERANCE_RAD)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    DATA.mkdir(parents=True, exist_ok=True)
    plate = make_petg_plate()
    backer = make_backer()
    parts = {}
    export_part(plate, "petg_drain_plate_PRINT_2")
    parts["petg_drain_plate_PRINT_2"] = describe_part(
        plate, "petg_drain_plate_PRINT_2", "PETG", 2,
        "Reusable perforated compression face with rear drainage grooves",
        print_orientation="Drainage back down at Z=0; press face up at Z=12",
        outer_size_mm=[OUTER_X_MM, OUTER_Y_MM, PETG_PLATE_THICKNESS_MM],
        drain_hole_count=len(DRAIN_GRID_X_MM)*len(DRAIN_GRID_Y_MM),
        bolt_hole_count=len(BOLT_POINTS_MM))

    export_part(backer, "steel_backer_MAKE_2", print_stl=False)
    cq.exporters.export(backer, str(DATA / "steel_backer_REFERENCE_METAL_ONLY.stl"),
                        tolerance=STL_LINEAR_TOLERANCE_MM,
                        angularTolerance=STL_ANGULAR_TOLERANCE_RAD)
    parts["steel_backer_MAKE_2"] = describe_part(
        backer, "steel_backer_MAKE_2", "Mild steel", 2,
        "Flat unperforated load spreading backer; machine or purchase metal",
        outer_size_mm=[OUTER_X_MM, OUTER_Y_MM, STEEL_BACKER_THICKNESS_MM],
        bolt_hole_count=len(BOLT_POINTS_MM),
        warning="Do not replace with a printed PETG backer")

    rings = {}
    for gap in NOMINAL_PULP_GAPS_MM:
        name = f"gap_ring_{gap}mm_pulp_{gap+2*MESH_THICKNESS_MM:.1f}mm_actual_PRINT_1"
        ring = make_ring(gap)
        rings[gap] = ring
        export_part(ring, name)
        parts[name] = describe_part(
            ring, name, "PETG", 1,
            "Replaceable full-footprint thickness stop and pulp side wall",
            nominal_pulp_gap_mm=gap,
            actual_ring_height_mm=gap+2*MESH_THICKNESS_MM,
            inner_opening_mm=[CAVITY_X_MM, CAVITY_Y_MM],
            inner_corner_radius_mm=CAVITY_RADIUS_MM,
            bolt_hole_count=len(BOLT_POINTS_MM))

    # Mesh sheets are only their bounding envelopes, not an actual woven mesh.
    # They are bought components; their compression thickness is empirical.
    mesh = rounded_plate(MESH_X_MM, MESH_Y_MM,
                         MESH_THICKNESS_MM, MESH_RADIUS_MM)
    cq.exporters.export(mesh, str(DATA / "mesh_envelope_REFERENCE_ONLY.stl"),
                        tolerance=STL_LINEAR_TOLERANCE_MM,
                        angularTolerance=STL_ANGULAR_TOLERANCE_RAD)
    parts["mesh_envelope_REFERENCE_ONLY"] = describe_part(
        mesh, "mesh_envelope_REFERENCE_ONLY", "Fine woven mesh", 2,
        "Reference envelope for purchased drainage mesh, not print geometry",
        represented_size_mm=[MESH_X_MM, MESH_Y_MM, MESH_THICKNESS_MM])

    gap = ASSEMBLY_GAP_MM
    ringh = gap + 2*MESH_THICKNESS_MM
    upperface = PETG_PLATE_THICKNESS_MM + ringh
    topback = upperface + PETG_PLATE_THICKNESS_MM
    assembly = cq.Assembly(name=f"pulp_press_{gap}mm_setting")
    blue = cq.Color(0.08, 0.31, 0.44)
    yellow = cq.Color(0.88, 0.59, 0.12)
    grey = cq.Color(0.56, 0.61, 0.64)
    meshcolor = cq.Color(0.74, 0.77, 0.71)
    assembly.add(backer, name="lower_steel_backer", color=grey,
                 loc=cq.Location(cq.Vector(0,0,-STEEL_BACKER_THICKNESS_MM)))
    assembly.add(plate, name="lower_petg_drain_plate", color=blue)
    assembly.add(rings[gap], name=f"{gap}mm_gap_ring", color=yellow,
                 loc=cq.Location(cq.Vector(0,0,PETG_PLATE_THICKNESS_MM)))
    # Rotate about X then translate: local Z=12 becomes the downward press face.
    assembly.add(plate, name="upper_petg_drain_plate", color=blue,
                 loc=cq.Location(cq.Vector(0,0,topback), cq.Vector(1,0,0), 180))
    assembly.add(backer, name="upper_steel_backer", color=grey,
                 loc=cq.Location(cq.Vector(0,0,topback)))
    assembly.add(mesh, name="lower_mesh_REFERENCE_NOT_FOR_PRINT", color=meshcolor,
                 loc=cq.Location(cq.Vector(0,0,PETG_PLATE_THICKNESS_MM)))
    assembly.add(mesh, name="upper_mesh_REFERENCE_NOT_FOR_PRINT", color=meshcolor,
                 loc=cq.Location(cq.Vector(0,0,upperface-MESH_THICKNESS_MM)))
    assembly.save(str(OUT / "pulp_press_assembled_3mm.step"))

    metadata = {
        "units": "mm",
        "revision": "A",
        "model_note": "Prototype; force and mesh thickness require measured validation",
        "parameters": {
            "outer_size_xy_mm": [OUTER_X_MM, OUTER_Y_MM],
            "outer_corner_radius_mm": OUTER_RADIUS_MM,
            "petg_plate_thickness_mm": PETG_PLATE_THICKNESS_MM,
            "steel_backer_thickness_mm": STEEL_BACKER_THICKNESS_MM,
            "cavity_xy_mm": [CAVITY_X_MM, CAVITY_Y_MM],
            "cavity_corner_radius_mm": CAVITY_RADIUS_MM,
            "cavity_flat_plan_area_mm2": round(CAVITY_X_MM*CAVITY_Y_MM
                -(4-math.pi)*CAVITY_RADIUS_MM**2,6),
            "bolt_clearance_diameter_mm": BOLT_CLEARANCE_DIAMETER_MM,
            "bolt_points_xy_mm": BOLT_POINTS_MM,
            "drain_hole_diameter_mm": DRAIN_DIAMETER_MM,
            "drain_grid_x_mm": DRAIN_GRID_X_MM,
            "drain_grid_y_mm": DRAIN_GRID_Y_MM,
            "drain_hole_count_per_plate": len(DRAIN_GRID_X_MM)*len(DRAIN_GRID_Y_MM),
            "drain_open_area_per_plate_mm2": round(len(DRAIN_GRID_X_MM)*
                len(DRAIN_GRID_Y_MM)*math.pi*DRAIN_DIAMETER_MM**2/4,6),
            "drain_points_xy_mm": [(x,y) for y in DRAIN_GRID_Y_MM for x in DRAIN_GRID_X_MM],
            "back_groove_width_mm": GROOVE_WIDTH_MM,
            "back_groove_depth_mm": GROOVE_DEPTH_MM,
            "back_groove_floor_z_mm": GROOVE_DEPTH_MM,
            "back_groove_centerlines_xy_mm": [
                {"start": [-OUTER_X_MM/2, y], "end": [OUTER_X_MM/2, y]}
                for y in DRAIN_GRID_Y_MM if y != 0
            ] + [
                {"start": [-CENTRAL_CHANNEL_BRANCH_X_MM,0],
                 "end": [CENTRAL_CHANNEL_BRANCH_X_MM,0]},
                {"start": [-CENTRAL_CHANNEL_BRANCH_X_MM,0],
                 "end": [-CENTRAL_CHANNEL_BRANCH_X_MM,-OUTER_Y_MM/2]},
                {"start": [CENTRAL_CHANNEL_BRANCH_X_MM,0],
                 "end": [CENTRAL_CHANNEL_BRANCH_X_MM,-OUTER_Y_MM/2]},
            ],
            "mesh_nominal_compressed_thickness_each_mm": MESH_THICKNESS_MM,
            "mesh_envelope_xy_mm": [MESH_X_MM,MESH_Y_MM],
            "ring_height_rule": "nominal_pulp_gap_mm + 2 * measured_compressed_mesh_thickness_mm",
            "nominal_pulp_gaps_mm": NOMINAL_PULP_GAPS_MM,
            "ring_actual_heights_mm": [g+2*MESH_THICKNESS_MM for g in NOMINAL_PULP_GAPS_MM],
        },
        "parts": parts,
        "assembly": {
            "nominal_pulp_gap_mm": ASSEMBLY_GAP_MM,
            "actual_ring_height_mm": ringh,
            "overall_z_extent_mm": [-STEEL_BACKER_THICKNESS_MM,topback+STEEL_BACKER_THICKNESS_MM],
            "objects": {
                "lower_steel_backer": {"translation_mm": [0,0,-STEEL_BACKER_THICKNESS_MM], "rotation_x_deg": 0},
                "lower_petg_drain_plate": {"translation_mm": [0,0,0], "rotation_x_deg": 0},
                "gap_ring_3mm": {"translation_mm": [0,0,PETG_PLATE_THICKNESS_MM], "rotation_x_deg": 0},
                "upper_petg_drain_plate": {"translation_mm": [0,0,topback], "rotation_x_deg": 180},
                "upper_steel_backer": {"translation_mm": [0,0,topback], "rotation_x_deg": 0},
                "lower_mesh": {"translation_mm": [0,0,PETG_PLATE_THICKNESS_MM], "rotation_x_deg": 0},
                "upper_mesh": {"translation_mm": [0,0,upperface-MESH_THICKNESS_MM], "rotation_x_deg": 0},
            },
            "hardware_note": "Fasteners omitted from STEP; M6 x 60 bolts and flat washers are purchased parts",
            "parts_fit": "Plate mating faces and ring are coplanar; mesh envelopes fit wholly inside cavity",
        },
        "manufacturing_notes": [
            "STLs are millimetres; print two drainage plates and one of each desired ring.",
            "Machine two steel backers from 8 mm plate; never print them as a load-rated substitute.",
            "Measure and face/trim rings after printing; achieved wet gap depends on mesh and plate flatness.",
            "Do not stack rings for nominal labels: only a single ring includes the correct two-mesh allowance.",
            "A wet compressed gap does not predict final dry thickness: record springback and shrinkage.",
            "Backside channels discharge at plate edges; leave those edges open above a catch tray.",
        ],
    }
    (DATA / "cad_dimensions.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps({"CAD_outputs": [p.name for p in OUT.iterdir()],
                      "parts_validated": len(parts),
                      "metadata": str(DATA / "cad_dimensions.json")}, indent=2))


if __name__ == "__main__":
    main()
