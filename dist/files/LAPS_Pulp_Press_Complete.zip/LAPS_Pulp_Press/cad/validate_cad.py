#!/usr/bin/env python3
"""Check exported binary STL topology, volume and STEP re-import.

Run after build_cad.py. Requires only the Python standard library and CadQuery.
"""
import json
from collections import defaultdict
from pathlib import Path
import struct
import cadquery as cq

ROOT = Path(__file__).resolve().parents[1]


def check_stl(path, expected_volume):
    data = path.read_bytes()
    triangle_count = struct.unpack_from('<I', data, 80)[0]
    assert len(data) == 84 + triangle_count*50, f'{path}: unexpected STL format'
    vertex_ids = {}
    edges = defaultdict(list)
    signed_volume = 0.0
    parents = list(range(triangle_count))

    def root(i):
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i

    for ti in range(triangle_count):
        values = struct.unpack_from('<12fH', data, 84+ti*50)
        vertices = [values[i:i+3] for i in (3, 6, 9)]
        ids = []
        for vertex in vertices:
            key = tuple(round(v, 5) for v in vertex)
            ids.append(vertex_ids.setdefault(key, len(vertex_ids)))
        a, b, c = vertices
        signed_volume += (a[0]*(b[1]*c[2]-b[2]*c[1]) +
                          a[1]*(b[2]*c[0]-b[0]*c[2]) +
                          a[2]*(b[0]*c[1]-b[1]*c[0])) / 6
        for i, j in ((0,1), (1,2), (2,0)):
            u, v = ids[i], ids[j]
            assert u != v, f'{path}: collapsed triangle'
            edges[tuple(sorted((u,v)))].append((ti, 1 if u < v else -1))
    assert all(len(v) == 2 for v in edges.values()), f'{path}: non-manifold edge'
    assert all(v[0][1] == -v[1][1] for v in edges.values()), f'{path}: inconsistent normals'
    for pair in edges.values():
        a, b = root(pair[0][0]), root(pair[1][0])
        parents[b] = a
    assert len({root(i) for i in range(triangle_count)}) == 1, f'{path}: disconnected shells'
    assert signed_volume > 0, f'{path}: inward-facing mesh'
    error = abs(signed_volume-expected_volume)/expected_volume
    assert error < 0.001, f'{path}: volume error {error}'
    return {'file': str(path.relative_to(ROOT)), 'triangles': triangle_count,
            'watertight_two_faces_per_edge': True, 'consistent_outward_normals': True,
            'single_connected_shell': True, 'mesh_volume_mm3': signed_volume,
            'relative_mesh_to_brep_volume_error': error}


def main():
    metadata = json.loads((ROOT/'data/cad_dimensions.json').read_text())
    report = {'stl': [], 'step': []}
    stls = list(sorted((ROOT/'cad').glob('*.stl')))
    stls += [ROOT/'data/steel_backer_REFERENCE_METAL_ONLY.stl',
             ROOT/'data/mesh_envelope_REFERENCE_ONLY.stl']
    for path in stls:
        key = 'steel_backer_MAKE_2' if path.name.startswith('steel_backer_REFERENCE') else path.stem
        report['stl'].append(check_stl(path, metadata['parts'][key]['volume_mm3']))
    for path in sorted((ROOT/'cad').glob('*.step')):
        solids = cq.importers.importStep(str(path)).solids().vals()
        assert all(s.isValid() and all(sh.Closed() for sh in s.Shells()) for s in solids), path
        report['step'].append({'file':str(path.relative_to(ROOT)),
                               'reimported_valid_closed_solids':len(solids)})
    (ROOT/'data/cad_validation.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
