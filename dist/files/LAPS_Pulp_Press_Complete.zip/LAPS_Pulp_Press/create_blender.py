#!/usr/bin/env python3
"""Create the Blender presentation and physically scaled GLB exports.

Run: blender -b --factory-startup --python create_blender.py
CAD/STL input is in millimetres; all scene meshes are baked to metres.
Purchased hardware is simplified visual reference geometry, not printable.
The green card is a nominal wet-pulp envelope, not a prediction of dry shape.
"""
import bpy
import math
import json
from pathlib import Path
from mathutils import Vector

ROOT = Path(__file__).resolve().parent
for directory in ('blender', 'renders', 'ar'):
    (ROOT / directory).mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for scene in list(bpy.data.scenes):
    if scene != bpy.context.scene:
        bpy.data.scenes.remove(scene)

MM = 0.001
BOLTS = [(-53,-38),(0,-38),(53,-38),(-53,0),(53,0),(-53,38),(0,38),(53,38)]

def material(name, color, metallic=0, roughness=.36):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = (*color, 1)
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value = (*color, 1)
    shader.inputs['Metallic'].default_value = metallic
    shader.inputs['Roughness'].default_value = roughness
    return mat

TEAL = material('PETG / deep teal', (.035,.23,.27), 0, .31)
GOLD = material('PETG / amber thickness stop', (.92,.45,.075), 0, .34)
STEEL = material('Purchased steel / brushed finish', (.47,.53,.58), .85, .32)
HARDWARE = material('Purchased M6 hardware / zinc plated', (.63,.68,.72), .82, .24)
MESH = material('Purchased filter mesh / envelope only', (.25,.30,.26), .15, .65)
PULP = material('Wet pulp / illustrative envelope', (.30,.36,.16), 0, .9)
FLOOR = material('Studio background', (.84,.86,.84), 0, .8)

def set_material(obj, mat):
    obj.data.materials.clear()
    obj.data.materials.append(mat)

def move_to(obj, collection):
    for current in list(obj.users_collection):
        current.objects.unlink(obj)
    collection.objects.link(obj)

def rounded_prism(name, w, d, h, radius, mat, collection, xyz=(0,0,0)):
    outline=[]
    for cx, cy, start in [(w/2-radius,d/2-radius,0),(-w/2+radius,d/2-radius,90),
                          (-w/2+radius,-d/2+radius,180),(w/2-radius,-d/2+radius,270)]:
        for i in range(9):
            angle=math.radians(start+i*90/8)
            outline.append((cx+radius*math.cos(angle),cy+radius*math.sin(angle)))
    n=len(outline)
    verts=[(x*MM,y*MM,z*MM) for z in (0,h) for x,y in outline]
    faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]
    faces += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    mesh=bpy.data.meshes.new(name)
    mesh.from_pydata(verts,[],faces)
    mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    collection.objects.link(obj)
    obj.location=Vector(xyz)*MM
    set_material(obj,mat)
    return obj

def annulus(name, outer, inner, h, mat, collection, xyz, segments=64):
    verts=[]
    for z in (0,h):
        for r in (outer,inner):
            for i in range(segments):
                a=2*math.pi*i/segments
                verts.append((r*math.cos(a)*MM,r*math.sin(a)*MM,z*MM))
    n=segments
    faces=[]
    for i in range(n):
        j=(i+1)%n
        faces += [(i,j,2*n+j,2*n+i),(n+j,n+i,3*n+i,3*n+j),
                  (j,i,n+i,n+j),(2*n+i,2*n+j,3*n+j,3*n+i)]
    mesh=bpy.data.meshes.new(name)
    mesh.from_pydata(verts,[],faces)
    mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    collection.objects.link(obj)
    obj.location=Vector(xyz)*MM
    set_material(obj,mat)
    return obj

def cylinder(name, radius, depth, mat, collection, xyz, vertices=48):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius*MM,depth=depth*MM,
                                      location=Vector((xyz[0],xyz[1],xyz[2]+depth/2))*MM)
    obj=bpy.context.object
    obj.name=name
    move_to(obj,collection)
    set_material(obj,mat)
    return obj

def import_cad(path, name, mat, collection, xyz=(0,0,0), flip=False):
    bpy.ops.wm.stl_import(filepath=str(path))
    obj=bpy.context.object
    obj.name=name
    for vertex in obj.data.vertices:
        vertex.co *= MM
    obj.location=Vector(xyz)*MM
    if flip:
        obj.rotation_euler.x=math.pi
    set_material(obj,mat)
    move_to(obj,collection)
    return obj

def setup_scene(name):
    scene=bpy.data.scenes.new(name)
    scene.unit_settings.system='METRIC'
    scene.unit_settings.scale_length=1
    scene.unit_settings.length_unit='MILLIMETERS'
    scene.render.engine='CYCLES'
    scene.cycles.samples=64
    scene.cycles.max_bounces=4
    scene.cycles.diffuse_bounces=2
    scene.cycles.glossy_bounces=2
    # This portable Blender build has no OpenImageDenoise support.
    scene.cycles.use_denoising=False
    scene.render.resolution_x=1600
    scene.render.resolution_y=1200
    scene.render.resolution_percentage=100
    scene.render.image_settings.file_format='PNG'
    scene.render.film_transparent=False
    scene.view_settings.view_transform='AgX'
    scene.view_settings.exposure=-3
    world=bpy.data.worlds.new(name+' world')
    world.use_nodes=True
    world.node_tree.nodes['Background'].inputs[0].default_value=(.78,.82,.86,1)
    world.node_tree.nodes['Background'].inputs[1].default_value=.35
    scene.world=world
    collection=bpy.data.collections.new(name+' | model')
    scene.collection.children.link(collection)
    studio=bpy.data.collections.new(name+' | studio')
    scene.collection.children.link(studio)
    bpy.context.window.scene=scene
    return scene,collection,studio

def light(studio, name, location, energy, size):
    data=bpy.data.lights.new(name,'AREA')
    data.energy=energy
    data.shape='DISK'
    data.size=size
    obj=bpy.data.objects.new(name,data)
    studio.objects.link(obj)
    obj.location=location
    obj.rotation_euler=(Vector((0,0,.035))-obj.location).to_track_quat('-Z','Y').to_euler()

def studio_setup(scene, studio, floor_z=0):
    rounded_prism('Studio surface',10000,10000,1,10,FLOOR,studio,xyz=(0,0,floor_z-1))
    light(studio,'Large softbox / left',(-.22,-.17,.35),18,.23)
    light(studio,'Softbox / right',(.24,.08,.23),12,.18)
    light(studio,'Rim / rear',(-.08,.22,.28),18,.18)

def camera(scene, studio, name, location, target, ortho=None):
    data=bpy.data.cameras.new(name)
    obj=bpy.data.objects.new(name,data)
    studio.objects.link(obj)
    obj.location=location
    obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler()
    data.lens=48
    data.clip_start=.001
    data.clip_end=20
    if ortho:
        data.type='ORTHO'
        data.ortho_scale=ortho
    scene.camera=obj
    return obj

def select_model(scene, collection):
    bpy.context.window.scene=scene
    bpy.ops.object.select_all(action='DESELECT')
    for obj in collection.objects:
        obj.select_set(True)
    bpy.context.view_layer.objects.active=next(iter(collection.objects))

def export_glb(scene, collection, filename):
    select_model(scene,collection)
    bpy.ops.export_scene.gltf(filepath=str(ROOT/'ar'/filename),export_format='GLB',
                             use_selection=True,export_yup=True,export_apply=True,
                             export_materials='EXPORT',export_extras=True)

def render(scene, cam, filename):
    bpy.context.window.scene=scene
    scene.camera=cam
    scene.render.filepath=str(ROOT/'renders'/filename)
    bpy.ops.render.render(write_still=True)

platepath=ROOT/'cad'/'petg_drain_plate_PRINT_2.stl'
backpath=ROOT/'data'/'steel_backer_REFERENCE_METAL_ONLY.stl'
meshpath=ROOT/'data'/'mesh_envelope_REFERENCE_ONLY.stl'
ringpaths={gap:ROOT/'cad'/f'gap_ring_{gap}mm_pulp_{gap+.4:.1f}mm_actual_PRINT_1.stl' for gap in range(1,6)}

assembled, coll, studio=setup_scene('01 ASSEMBLED / 3 mm nominal wet gap')
# The lowest bolt heads sit at the floor; the complete hardware height is 64mm.
shift=13.6
import_cad(backpath,'01 Lower STEEL backer / 8 mm / BUY',STEEL,coll,(0,0,-8+shift))
import_cad(platepath,'02 Lower PETG drain face / 12 mm / PRINT',TEAL,coll,(0,0,shift))
import_cad(ringpaths[3],'03 Spacer / 3.4 mm / 3 mm nominal pulp / PRINT',GOLD,coll,(0,0,12+shift))
import_cad(meshpath,'04 Lower filter / 0.2 mm assumed / BUY',MESH,coll,(0,0,12+shift))
rounded_prism('05 Wet pulp envelope / 85 x 55 x 3 / REFERENCE',85,55,3,3,PULP,coll,(0,0,12.2+shift))
import_cad(meshpath,'06 Upper filter / 0.2 mm assumed / BUY',MESH,coll,(0,0,15.2+shift))
import_cad(platepath,'07 Upper PETG drain face / mirrored / PRINT',TEAL,coll,(0,0,27.4+shift),True)
import_cad(backpath,'08 Upper STEEL backer / 8 mm / BUY',STEEL,coll,(0,0,27.4+shift))
for index,(x,y) in enumerate(BOLTS,1):
    cylinder(f'M6 bolt {index:02d} / simplified 60 mm shank',3,60,HARDWARE,coll,(x,y,-9.6+shift))
    cylinder(f'M6 bolt {index:02d} / hex head AF10',10/math.sqrt(3),4,HARDWARE,coll,(x,y,-13.6+shift),6)
    annulus(f'M6 washer {index:02d} lower / OD18',9,3.3,1.6,HARDWARE,coll,(x,y,-9.6+shift))
    annulus(f'M6 washer {index:02d} upper / OD18',9,3.3,1.6,HARDWARE,coll,(x,y,35.4+shift))
    # Nut inner bore uses a simple six-sided reference, not a manufacturing thread.
    annulus(f'M6 nut {index:02d} / simplified AF10',10/math.sqrt(3),3.05,5,HARDWARE,coll,(x,y,37+shift),6)
assembled['design_note']='Nominal 3 mm WET pulp gap; dry thickness requires measured calibration.'
assembled['manufacturing_note']='Only PETG plate and five spacer STLs are printable. Steel, mesh and hardware are purchased.'
studio_setup(assembled,studio)
cam45=camera(assembled,studio,'Camera / assembled 45 degree perspective',(.24,-.24,.27),(0,0,.03))
cam45.data.lens=70
camside=camera(assembled,studio,'Camera / true side',(0,-.30,.033),(0,0,.033),.185)
camtop=camera(assembled,studio,'Camera / true top',(0,0,.32),(0,0,.02),.19)
export_glb(assembled,coll,'Pulp_Press_assembled.glb')

exploded, ecoll, estud=setup_scene('02 EXPLODED / drainage and pulp stack')
import_cad(backpath,'01 Lower STEEL backer / 8 mm',STEEL,ecoll,(0,0,0))
import_cad(platepath,'02 Lower PETG drain face / 77 holes',TEAL,ecoll,(0,0,22))
import_cad(meshpath,'03 Lower filter / illustrative envelope',MESH,ecoll,(0,0,46))
import_cad(ringpaths[3],'04 Replaceable spacer / 3.4 mm',GOLD,ecoll,(0,0,62))
rounded_prism('05 Nominal wet pulp card',85,55,3,3,PULP,ecoll,(0,0,80))
import_cad(meshpath,'06 Upper filter / illustrative envelope',MESH,ecoll,(0,0,98))
import_cad(platepath,'07 Upper PETG plate / drainage back visible',TEAL,ecoll,(0,0,130),True)
import_cad(backpath,'08 Upper STEEL backer / 8 mm',STEEL,ecoll,(0,0,148))
# One detached hardware set illustrates the required purchased components.
cylinder('Reference M6 bolt / 60 mm shank',3,60,HARDWARE,ecoll,(-88,0,14))
cylinder('Reference M6 bolt / AF10 head',10/math.sqrt(3),4,HARDWARE,ecoll,(-88,0,10),6)
annulus('Reference lower M6 washer',9,3.3,1.6,HARDWARE,ecoll,(-88,0,81))
annulus('Reference upper M6 washer',9,3.3,1.6,HARDWARE,ecoll,(-88,0,93))
annulus('Reference M6 nut / AF10',10/math.sqrt(3),3.05,5,HARDWARE,ecoll,(-88,0,105),6)
studio_setup(exploded,estud)
ecam=camera(exploded,estud,'Camera / exploded 45 degree perspective',(.31,-.40,.285),(-.008,0,.080))
ecam.data.lens=60
export_glb(exploded,ecoll,'Pulp_Press_exploded.glb')

spacers, scoll, sstud=setup_scene('03 SPACERS / five nominal wet pulp gaps')
for index,gap in enumerate(range(1,6)):
    x=(index%3-1)*148
    y=60 if index<3 else -62
    import_cad(ringpaths[gap],f'GAP {gap} mm / spacer {gap+.4:.1f} mm',GOLD,scoll,(x,y,0))
    # A Blender text label is for display only, separate from the stop geometry.
    curve=bpy.data.curves.new(f'{gap} mm label','FONT')
    curve.body=f'{gap} mm  |  {gap+.4:.1f} mm spacer'
    curve.align_x='CENTER'
    curve.size=.008
    label=bpy.data.objects.new(f'Caption {gap} mm',curve)
    scoll.objects.link(label)
    label.location=(x*MM,(y-63)*MM,.0001)
    curve.materials.append(TEAL)
studio_setup(spacers,sstud)
scam=camera(spacers,sstud,'Camera / spacer set',(.13,-.43,.56),(0,0,0),.51)

detail, dcoll, dstud=setup_scene('04 DRAINAGE / back face inspection')
import_cad(platepath,'PETG plate / reverse grooves facing up',TEAL,dcoll,(0,0,12),True)
studio_setup(detail,dstud)
dcam=camera(detail,dstud,'Camera / drain grooves',(.19,-.23,.24),(0,0,.006),.19)

forming, fcoll, fstud=setup_scene('05 FORMING / open card cavity')
import_cad(platepath,'Lower PETG face / bare face inspection',TEAL,fcoll)
import_cad(ringpaths[3],'3.4 mm spacer / open card cavity',GOLD,fcoll,(0,0,12))
studio_setup(forming,fstud)
fcam=camera(forming,fstud,'Camera / open mold true top',(0,0,.30),(0,0,0),.17)
forming['display_note']='Bare-face inspection: filters and pulp omitted to reveal the drainage grid.'

# Editable source and display help is embedded in the native Blender file.
helptext=bpy.data.texts.new('READ ME / dimensions, layers and limits')
helptext.write('PULP PRESS - Revision A\n\n'
               'Five scenes: assembled, exploded, spacer set, reverse drainage and open cavity.\n'
               'All physical mesh coordinates are metres. UI shows millimetres.\n'
               'Card opening 85 x 55 R3; outer footprint 130 x 100 R6.\n'
               'PETG plates 12 mm; purchased steel backers 8 mm.\n'
               'Spacers 1.4 / 2.4 / 3.4 / 4.4 / 5.4 mm allow two assumed 0.2 mm filters.\n'
               'Dry pulp thickness is not guaranteed by the spacer size.\n'
               'Mesh solids and green pulp are reference envelopes.\n'
               'M6 hardware is simplified visual geometry, not a thread model.\n'
               'Do not print the steel, filters, pulp or hardware.\n'
               'Change manufacturing dimensions in cad/build_cad.py and rerun.\n'
               'Prototype: no certified force rating; see engineering guide.\n')
bpy.context.window.scene=assembled
assembled.camera=cam45
if 'Scene' in bpy.data.scenes and bpy.data.scenes['Scene'] != assembled:
    bpy.data.scenes.remove(bpy.data.scenes['Scene'])
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.clip_start=.001
            area.spaces.active.clip_end=10
            area.spaces.active.region_3d.view_distance=.26
            area.spaces.active.region_3d.view_location=Vector((0,0,.03))
            area.spaces.active.region_3d.view_rotation=cam45.rotation_euler.to_quaternion()
            area.spaces.active.region_3d.view_perspective='CAMERA'
            area.spaces.active.shading.color_type='MATERIAL'
            area.spaces.active.overlay.show_extras=False
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'blender'/'Pulp_Press.blend'))

# Export first, then render: AR packaging can proceed while Cycles runs.
render(assembled,cam45,'01_assembled_45deg.png')
render(exploded,ecam,'02_exploded_45deg.png')
render(assembled,camside,'03_assembled_side.png')
render(assembled,camtop,'04_assembled_top.png')
render(spacers,scam,'05_five_spacers.png')
render(detail,dcam,'06_drainage_back.png')
render(forming,fcam,'07_open_mold_top.png')
bpy.context.window.scene=assembled
assembled.camera=cam45
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'blender'/'Pulp_Press.blend'))
print('BLENDER PACKAGE COMPLETE')
