# LAPS prototips Blenderī un pirmā izdruka

Šī pamācība paredzēta failam **LAPS_Blender_Prototips.py**. To palaiž pašā Blenderī: ārējas Python bibliotēkas un CAD papildinājumi nav jāinstalē. Skripts izveido divas PETG plāksnes un piecas maināmas rāmja veida starplikas, saglabā Blender projektu un eksportē atsevišķus STL failus drukāšanai.

Printera profils šajā projektā pieņem **ELEGOO Centauri Carbon ar 0,4 mm sprauslu**. Pārbaudi printera pilno nosaukumu un sprauslu pirms sagriešanas slāņos.

## 1. Kā ielīmēt un palaist kodu

1. Atver Blender un sāc jaunu ainu: **File → New → General**. Ja pašreizējā ainā ir nesaglabāts darbs, vispirms saglabā to ar **File → Save As**.
2. Augšējā darba telpu joslā izvēlies **Scripting**. Ja šīs cilnes nav, pie darba telpām nospied **+ → General → Scripting**.
3. Logā **Text Editor** nospied **New**.
4. Iekopē visu faila **LAPS_Blender_Prototips.py** saturu, ieskaitot sākumu un beigas. Nekopē Markdown koda bloka atzīmes, ja kods attēlots sarakstē. Vari arī atvērt pašu `.py` failu ar **Text → Open**; tad ielīmēšana nav nepieciešama.
5. Novieto peli virs **Text Editor** un nospied **Alt + P**; macOS tastatūrā Alt atbilst **Option**. Tā pati darbība pieejama ar **Text → Run Script** vai palaišanas pogu teksta redaktora augšējā joslā.
6. Sagaidi, līdz skripts pabeidz darbu. Pārej uz **Layout** un 3D skatā izmanto **View → Frame All**, lai redzētu detaļas.

Skripts izveido savu ainu **LAPS_Prototips**; sākotnējās ainas lietotāja objektus nedzēš. Detaļas ainā izvietotas apskatei; šis izvietojums nav vienas drukas pamatnes izkārtojums. Katrs STL tiek eksportēts atsevišķi, ar ģeometriju centrētu XY plaknē un apakšu pie Z = 0.

## 2. Kur atrast saglabātos failus

Pēc noklusējuma skripts izveido mapi **LAPS_prototips** tava lietotāja mājas mapē. Saglabātais projekts ir **LAPS_Prototips.blend**, un drukas faili atrodas apakšmapē **STL**.

| Sistēma | Noklusējuma mapes piemērs |
| --- | --- |
| Windows | `C:\Users\TavsLietotajs\LAPS_prototips` |
| macOS | `/Users/TavsLietotajs/LAPS_prototips` |
| Linux | `/home/tavslietotajs/LAPS_prototips` |

`TavsLietotajs` ir tava konta nosaukums; šie ir atrašanās vietas piemēri, nevis teksts, ko jāievada kodā. macOS vari atvērt Finder izvēlni **Go → Home**, bet Linux failu pārvaldniekā — **Home**. Windows lietotāja mapi var atrast File Explorer adreses joslā, ievadot `%USERPROFILE%`.

Lai vēlāk turpinātu darbu Blenderī, atver **File → Open** un izvēlies **LAPS_Prototips.blend**. Lai drukātu, izmanto STL failus.

| STL fails | Drukājamais skaits | Detaļa |
| --- | --- | --- |
| `plate_A.stl` | 1 | Pirmā PETG plāksne, 130 × 100 × 12 mm |
| `plate_B.stl` | 1 | Otrā, identiskā PETG plāksne, 130 × 100 × 12 mm |
| `starplika_1mm_mitra_h1p4mm.stl` | 1, ja testē šo spraugu | 1 mm nominālā mitrās masas sprauga; starplikas augstums 1,4 mm |
| `starplika_2mm_mitra_h2p4mm.stl` | 1, ja testē šo spraugu | 2 mm mitrā sprauga; augstums 2,4 mm |
| `starplika_3mm_mitra_h3p4mm.stl` | 1, ja testē šo spraugu | 3 mm mitrā sprauga; augstums 3,4 mm |
| `starplika_4mm_mitra_h4p4mm.stl` | 1, ja testē šo spraugu | 4 mm mitrā sprauga; augstums 4,4 mm |
| `starplika_5mm_mitra_h5p4mm.stl` | 1, ja testē šo spraugu | 5 mm mitrā sprauga; augstums 5,4 mm |

Drukā **plate_A vienu reizi un plate_B vienu reizi** — kopā divas plāksnes. Pirmajam mēģinājumam pietiek ar abām plāksnēm un vienu 3 mm mitrās spraugas starpliku. Visus piecus gredzenus vari izdrukāt vēlāk.

## 3. Kā apskatīt un pārbaudīt modeli

- **Pietuvināt / attālināt:** peles rullītis.
- **Pagriezt skatu:** turi nospiestu peles vidējo pogu un velc.
- **Pārvietot skatu sāniski:** **Shift + peles vidējā poga** un velc.
- **Izvēlēties detaļu:** klikšķini uz tās 3D skatā vai tās nosaukuma sarakstā **Outliner** augšējā labajā pusē.
- **Pietuvināt izvēlēto detaļu:** 3D skata izvēlne **View → Frame Selected**.
- **Pārbaudīt izmērus:** 3D skatā nospied **N**, atver **Item** un skaties **Dimensions**. Taustiņš **T** atver rīku joslu, nevis izmēru paneli.

Ja nav vidējās peles pogas, skatu var pagriezt ar XYZ skata vadīklu 3D skata augšējā labajā stūrī. Alternatīvi **Edit → Preferences → Input → Emulate 3 Button Mouse** ļauj izmantot **Alt + kreiso peles pogu** vidējās pogas vietā.

Vienai plāksnei jābūt **130 × 100 × 12 mm**. Kartītes atvērums starplikā ir **85 × 55 mm**, ar 3 mm iekšējo stūru rādiusu. Plākšņu ārējais stūru rādiuss ir 6 mm. Katrai plāksnei ir 77 drenāžas caurumi Ø2 mm un astoņi skrūvju caurumi Ø6,6 mm.

Blender ainā ģeometrijas koordinātas izveidotas milimetros, un vienību mērogs ir **0,001**. Atsevišķo STL failu skaitliskie izmēri arī ir milimetros. Papildu palielinājums vai samazinājums nav vajadzīgs.

## 4. No STL līdz drukāšanai

1. Atver printerim piemērotu slāņotāju, piemēram, ELEGOO Slicer vai OrcaSlicer, un izvēlies pareizo **Centauri Carbon / 0,4 mm** printera profilu.
2. Importē `plate_A.stl`, `plate_B.stl` un izvēlēto starpliku. Ja visas detaļas neietilpst vienā izkārtojumā, sadali tās vairākās drukās. Neimportē visu Blender ainas izvietojumu kā vienu drukājamu detaļu.
3. Pārbaudi izmērus slāņotājā: plāksne **130 × 100 × 12 mm**, mērogs **100%**. Nepiekrīti automātiskai 1000 reižu mēroga maiņai; ja izmērs nav pareizs, pārbaudi importēšanas vienības.
4. Izvēlies **PETG**, nevis PLA profilu. Sprauslas un pamatnes temperatūru, ventilatoru un materiāla plūsmas kalibrēšanu nosaka iegādātais PETG. Projektā nav viena temperatūras iestatījuma visiem PETG zīmoliem.
5. Sākuma strukturālie iestatījumi: **0,20 mm slānis**, **6 sienu līnijas**, **100% pildījums**. Lai starplikas augstums sakristu ar pilnu slāņu skaitu, arī pirmajam slānim izmanto 0,20 mm, ja printera profils to ļauj. Nelieto mainīgu slāņu augstumu pirmajā kalibrēšanas drukā.
6. Liec plāksnes ar **aizmugures drenāžas rievām uz pamatnes**, bet gludo, perforēto masas kontakta virsmu uz augšu. Starplikas liec plakaniski. Sākotnēji atbalstus nelieto; rievu jumtiņiem jāpārtilto tikai **1,6 mm**, tomēr to pārbaudi slāņu priekšskatījumā un pirmajā izdrukā.
7. Pārskati pirmo slāni, caurumus, rievu jumtiņus un materiāla daudzumu. Tad slāņotājā izvēlies **Slice** un eksportē printerim piemērotu **G-code** vai izmanto tā atbalstīto nosūtīšanas veidu.

**Blender veido 3D ģeometriju; printera G-code veido slāņotājs.** Blender skripts neizvēlas printera kustību, temperatūras vai ekstrūzijas komandas. Printera piegādāto PETG pamatnes sagatavošanas metodi ievēro arī šim modelim.

Pēc atdzišanas nomēri katru starpliku vairākās vietās, pārbaudi plākšņu līdzenumu un iztīri visus caurumus un rievu izvadus. Starplikas iespiedums, pirmā slāņa izplešanās vai nekvalitatīvs īsais tiltiņš var mainīt reālo darbību arī tad, ja STL izmērs ir pareizs.

## 5. Kas vajadzīgs samontētam prototipam

Plastmasas detaļas ir tikai daļa no komplekta. Pilnam projektam vajag:

- **2 tērauda atbalsta plāksnes, 130 × 100 × 8 mm**, ar tiem pašiem astoņiem Ø6,6 mm caurumiem; tās izgatavo no metāla pēc tehniskā rasējuma.
- **8 pilnas vītnes M6 × 60 mm metāla sešstūra skrūves**, **8 M6 uzgriežņus** un **16 lielās M6 paplāksnes**, aptuveni Ø18 × 1,6 mm.
- **2 smalka austa sieta gabalus, 84,5 × 54,5 mm**, ar aptuveni 100–200 µm atvērumiem un noapaļotiem stūriem.

Starplikas augstums ietver **0,20 mm katram no diviem sietiem**. Reālo sieta biezumu nomēri: mitrās masas sprauga ir aptuveni **starplikas augstums − abu sietu kopējais biezums**. Siets pilnībā jāievieto atvērumā; to nedrīkst pārklāt pāri starplikas balsta virsmām. Montāžā izmanto vienu starpliku vienlaikus.

Divu PETG plākšņu, tērauda atbalstu un starplikas samontēšanas secība dota pilnajā ražošanas pamācībā. Tērauda atbalstus, metāla skrūves un smalko sietu neaizstāj ar izdrukātām vizualizācijas detaļām.

## 6. Biezums un slodze: ko prototips nosaka

**1–5 mm apzīmē mitrās, saspiestās masas spraugu.** Izžuvusi papīra un lapu kartīte var būt plānāka vai atsperties; izmēri to pēc vienādas žāvēšanas un kondicionēšanas. Sausās kartītes biezumu neizmanto vienādu ar faila nosaukumā norādīto mitro spraugu.

Skrūves ļauj aizvērt formu pret starpliku, bet pēc to pievilkšanas nav zināms precīzs spiediens uz masu. Kad starplika sāk nest daļu slodzes, kopējais preses spēks vairs neapraksta tikai masas spiedienu. Ja vajag salīdzināt spiedienus, nepieciešama skolotāja uzraudzīta prese ar spēka mērījumu un noteikta izmēģinājumu metode. Prototipam nav fiziski pārbaudītas slodzes vērtējuma vai sertificēta spiediena limita.

## 7. Ja vēlāk jāmaina skripta parametri

Skripta sākumā ir iestatījumi **OUTPUT_DIR**, **MESH_THICKNESS_MM**, **WET_GAPS_MM**, **EXPORT_STL** un **SAVE_BLEND**. Noklusējumā sieta biezums ir 0,2 mm katram gabalam un mitrās spraugas ir `(1, 2, 3, 4, 5)`.

Atkārtota palaišana pārraksta šī skripta izvades failus norādītajā mapē. Eksperimenta versijām lieto jaunu **OUTPUT_DIR** vai saglabā iepriekšējās versijas kopiju. Eksportu aprēķina no skripta radītās ģeometrijas; pēc manuālām objekta izmaiņām pats skripts to no jauna izveidos pēc parametriem.

Pēc izmēģinājuma vari ievadīt izmērīto sieta biezumu un vajadzīgo mitro spraugu. Pārģenerē detaļas un vēlreiz pārbaudi faktiskos izmērus slāņotājā. Ja palielini starplikas augstumu, pārbaudi arī skrūvju garumu, uzgriežņa vītnes saķeri un visas konstrukcijas saderību. Nemaini vienlaikus vairākus eksperimenta faktorus, ja vēlies saprast, kurš ietekmēja rezultātu.

Ja skripts rāda kļūdu, pārbaudi, vai kopēts viss kods un tas palaists Blender **Text Editor**, nevis atsevišķā Python terminālī. Precīzu kļūdas tekstu var nolasīt Blender paziņojumā vai konsolē. Izveidotu `.blend` projektu un STL failus izmanto tikai pēc izmēru un detaļu pārbaudes.
