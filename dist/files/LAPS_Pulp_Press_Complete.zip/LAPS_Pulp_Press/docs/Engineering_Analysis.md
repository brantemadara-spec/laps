# Engineering notes: reusable pulp card mold prototype

Prepared 6 October 2026. The supplied sketch is a visual reference. Its handwritten checklist is not an independent instruction or evidence of material strength. No drawing dimensions were supplied, so the following dimensions are design choices. This document is an engineering screening and experiment plan, not a tested pressure rating or a prediction of the best paper/leaf formulation.

## Design decisions

Use two identical PETG platens, each 130 × 100 × 12 mm, with a removable spacer frame between them. A frame aperture 85 × 55 mm with R3 corners defines the nominal wet business-card planform. Fully support each PETG platen with a continuous 130 × 100 × 8 mm steel backer; 8 mm is preferred to the earlier 6 mm concept because thickness uniformity, especially at the 1 mm setting, depends on stiffness. A small card does not need larger bolts than M6 for the proposed initial trial forces; larger bolts would make accidental excessive clamping easier without solving platen bow.

Use eight fully threaded M6 × 60 mm through-bolts, eight plain steel nuts and sixteen steel washers outside the steel backers. Use measured steel hardware with stated specifications, for example class 8.8 bolts with compatible nuts, or suitable corrosion-resistant hardware. Standard nuts make gentle staged adjustment clearer than knobs that invite over-tightening. The bolts clamp and align the reusable assembly; no printed thread or captive printed nut is a principal load-bearing element. Hole centers relative to the card center are (±53, ±38), (0, ±38), and (±53, 0) mm, with Ø6.6 mm nominal clearance in every plate/frame/backer.

Each PETG platen has Ø2 mm through-drain holes on a 7 mm pitch inside the card face, and 1.6 mm wide × 1.2 mm deep outlet grooves on the outside face. Every drain must meet a groove that reaches the platen edge. The steel backer covers the groove face, so it is the open grooves at the perimeter that preserve the discharge path; a flat steel backer cannot simply cover isolated drain-hole exits. Keep all grooves clear and do not seal the edges with a waterproof gasket. Drain geometry and clogging are to be verified with water before pulp trials.

Fit two pieces of fine screen inside the aperture, nominally 84.5 × 54.5 mm with R3 corners, trimmed to fit without buckling. Start with stainless 304/316 plain weave or polyester monofilament screen of 100–200 μm nominal aperture. Aperture, wire/filament diameter, and total fabric thickness are different specifications. Buy by those dimensions instead of mesh count alone. Screen thickness under load must be measured. Two 0.20 mm compressed screens are a design assumption, not a universal fabric thickness. Fine mesh retains pulp over the much larger drain holes; very fine mesh can clog and slow drainage.

The frame is the thickness stop. Neither screen may overlap onto its bearing surface. With two screens compressed to 0.20 mm each, the nominal frame thicknesses are:

| Intended wet pulp gap | Nominal frame thickness | PETG layers at 0.20 mm |
|---:|---:|---:|
| 1 mm | 1.40 mm | 7 |
| 2 mm | 2.40 mm | 12 |
| 3 mm | 3.40 mm | 17 |
| 4 mm | 4.40 mm | 22 |
| 5 mm | 5.40 mm | 27 |

The general calibration is **wet pulp gap = measured frame thickness − measured lower screen thickness under compression − measured upper screen thickness under compression**, with extra effects from platen bow and print surface texture. Mark every frame with its measured thickness. Small rigid shims around the full frame bearing surface can correct it; isolated washers at bolt positions can introduce uneven contact and should not substitute for a flat full-area stop. For long-term repeated use, machined or precision-shimmed metal frames are a more stable upgrade than thin printed frames.

The 1–5 mm labels are **wet molding gaps**. Dry sheets usually change thickness and planform as water leaves. Exact 1, 2, 3, 4 or 5 mm dry cards require empirical calibration of pulp charge, wet gap, load history and drying method for each recipe. A nominal 85 × 55 mm cavity also does not guarantee that exact dry outline; trim the dried sample to final business-card size if needed.

## Pressure, force and stiffness

For an 85 × 55 mm rounded rectangle with R3 corners:

A = 85 × 55 − (4 − π) × 3² = **4667.274 mm²** = 46.67274 cm².

Before any spacer stop carries load, average pulp pressure p = F/A. Because 1 MPa = 1 N/mm², the following forces correspond to the initial experimental pressure steps:

| Nominal pressure before stop contact | Total measured compressive force | Equivalent kgf | Ideal force per bolt if all eight shared it equally |
|---:|---:|---:|---:|
| 0.05 MPa = 50 kPa | 233 N | 23.8 kgf | 29 N |
| 0.10 MPa = 100 kPa | 467 N | 47.6 kgf | 58 N |
| 0.20 MPa = 200 kPa | 933 N | 95.2 kgf | 117 N |

The kgf column explains force scale; it is not a recommendation to stack weights on the mold. These pressure steps are a cautious test plan for a reinforced prototype, not a verified working-load limit. Do not run a high-force hydraulic press by its maximum tonnage: this specimen requires force control at hundreds of newtons.

A simple solid-beam screening helps compare backing thicknesses. Model a 55 mm wide strip spanning 106 mm between bolt rows, with a central 85 mm long uniformly distributed load. Use E = 200,000 MPa for steel and 1500 MPa for printed PETG. With I = b h³/12, end unloaded length a = (106 − 85)/2 = 10.5 mm, and line load q = p b:

δcenter = q/(E I) × [5 L⁴/384 − L² a²/16 + a⁴/24].

The central bending moment is M = q c (2 L − c)/8 and nominal bending stress σ = M h/(2 I).

At 0.20 MPa this calculation gives:

| Idealized solid strip | Center bow of one plate | Nominal bending stress |
|---|---:|---:|
| PETG, 12 mm, unsupported by metal | 1.451 mm | 11.24 MPa |
| Steel, 6 mm | 0.0871 mm | 44.98 MPa |
| Steel, 8 mm | 0.0367 mm | 25.30 MPa |

Two 8 mm backers may therefore contribute roughly **0.073 mm combined gap bow** under this screening model at 0.20 MPa; at 0.10 MPa the corresponding estimate is 0.0367 mm. Stiffness matters much more than nominal bulk PETG compression strength. This model excludes drilled holes, printed voids, groove detail, discrete bolt support, face contact, frame stiffness, and two-way plate action. Some effects increase and others reduce deformation. It is not a proven upper bound, a finite-element result, or a rated load. The PETG and steel plates are not bonded, so treating them as one laminated composite section would give unjustified stiffness. Inspect and measure the actual assembly under load before increasing pressure.

Manufacturer data for one PETG formulation reports printed tensile/flexural moduli around 1.5–1.7 GPa, interlayer adhesion 18 ± 4 MPa, and a heat-deflection temperature of 68°C. Its results depend on print settings and specific specimens; they cannot be turned into a pressure rating for this perforated mold. Use ordinary, well-characterized PETG rather than assuming a product name such as “PETG Pro” is a strength specification. [Prusament PETG technical data sheet](https://prusament.com/wp-content/uploads/2022/10/PETG_Prusament_TDS_2021_10_EN.pdf)

Printed PETG also deforms over time under constant stress. A 2025 primary study measured nonlinear time-dependent behavior and the influence of print orientation. A short-term tensile result alone cannot predict an overnight clamp's shape or preload. [Stankevics et al., PETG viscoelastic creep](https://doi.org/10.3390/polym17152075)

**Once the frame stop contacts both platens, Ftotal = Fpulp + Fframe.** Total press or bolt force divided by card area then overstates actual pulp pressure. The stopped mold is a gap-controlled tool, while a measured press acting before stop contact is a force-controlled experiment. A fixed gap cannot independently impose a chosen pressure on every recipe: different pulp charges, compressibility and drainage will reach the stop at different forces. With insufficient pulp, the frame can be fully closed while the pulp carries almost no pressure.

Nut torque also does not establish pulp pressure. The approximate relation T = K Fbolt d is friction-sensitive; K is unknown without calibration, and PETG contact and pulp change over time. NASA's fastener guidance identifies torque control as the least accurate preload method and requires consideration of variability, relaxation and creep. This is a general mechanical principle, not a claim that this school tool follows NASA standards. [NASA-STD-5020B, section 4.3](https://standards.nasa.gov/sites/default/files/standards/NASA/B/0/2021-08-06-nasa-std-5020b_final.pdf)

For quantitative pressure trials, borrow a teacher-operated small press with a calibrated compression load cell or force gauge in the direct load path, controllable around 200–1000 N. Record force and gap together. A scale underneath the entire self-contained press does not measure its internal compression force. With bolts alone, report “frame gap and closure procedure” and omit claimed MPa.

## PETG printing and acceptance

The user mentioned an Elegoo Carbon printer; the likely model is Centauri Carbon with a 0.4 mm nozzle, which should be confirmed before selecting a machine profile. Structural print choices proposed here are independent recommendations, not tested settings for that machine.

Print platens flat with the drainage back on the bed and the pulp contact face facing up, matching the supplied STL orientation. Inspect the small 1.6 mm bridges over the channels and clear them if necessary; measure and lap the contact faces on a flat reference as needed. Print frames flat. Use 0.20 mm layers, at least six wall loops, 100% alternating rectilinear infill, and sufficient solid top/bottom layers to leave the faces dense and clean. Make the screens the removable smooth contact/release layer. Preserve drain holes and grooves; supports or strings must not block them. First-layer expansion can alter flatness, holes and aperture dimensions, so test and adjust it rather than silently scaling the entire part.

Use the actual filament manufacturer's temperature range and a calibrated PETG profile. For ELEGOO PETG PRO, ELEGOO lists 230–260°C nozzle (240°C recommended) and 65–75°C bed. A 240°C nozzle and 70°C bed are initial values for that filament only; verify the exact spool and plate profile. These are print temperatures, not pulp-press temperatures. Dry the filament according to its manufacturer, calibrate extrusion flow and maximum reliable volumetric rate, and favor well-bonded material over a high-speed visual prototype. Nozzle flow calibration affects strength because underextrusion leaves voids. Slower 30–45 mm/s exterior walls are a reasonable trial, with extrusion speed and cooling tuned for this spool. More heat is not automatically better: overheating, bubbles or dimensional loss are reasons to correct the process.

Check the slicer preview for full-density walls at every drain and bolt hole. Print a small hole/groove coupon first, then measure it. Drill/ream Ø6.6 bolt clearances gently as required; deburr all steel and plastic edges. Use a flat reference and feeler gauges to check both platen faces and frames. Record unloaded face warp and loaded center bow. The metal backer must bear continuously except at designed grooves, with no trapped debris. Water-test drainage at all perimeter exits. Reject delaminated, porous, cracked, visibly bowed or crushed parts, and stop a trial if bow or cracking grows. Keep operations at room temperature; heat-deflection data are not a permission to hot-press, oven-dry, or load PETG at that temperature.

## Dewatering and drying procedure

The card can drain on both faces. Pulp thickness is only 1–5 mm, so the through-thickness distance to a draining face is at most 0.5–2.5 mm. A lattice of nearby drain holes, supported screens and edge-open grooves gives water exits without demanding that it traverse the whole card to its perimeter. Pulp and screen permeability dominate actual flow: the drain-hole size alone does not predict time. Dense fines and very finely ground leaves can obstruct the screens.

Start with cool wet pulp that has drained to a repeatable spoonable consistency. Spread it evenly without large air pockets, install the upper screen and platen, and close in alternating opposite bolt increments. In a force-measured test, ramp gently over 30–60 seconds to 0.05 MPa first and hold for a fixed five minutes. Inspect drainage and plate condition before testing separate samples at 0.10 and 0.20 MPa. Record whether and when the stop was reached. Do not continue increasing force after the frame is firmly seated as a way to force a particular pulp pressure.

The five-minute hold is a reproducible starting choice. A primary laboratory paper study used 345 kPa for five minutes on much thinner specialized handsheets and reported that intense fibrillation improved strength while worsening drainage. Its equipment and sheets differ from this prototype, so 345 kPa is not an adopted operating recommendation here. [Park et al., cellulose fibrils and handsheet preparation](https://bioresources.cnr.ncsu.edu/resources/utilization-of-cellulose-micro-nanofibrils-as-paper-additive-for-the-manufacturing-of-security-paper/)

A closed rigid mold mostly removes free water; it does not finish drying a 5 mm wet leaf/paper card. Drying shrinks the card, so fixed-gap bolts lose pulp contact rather than maintain pressure. After the measured wet press, transfer the sample on its screen/release layer to clean blotter sheets between flat rigid drying boards. Use a modest, consistent restraint, replace damp blotters, and allow airflow around the boards. Alternatively, dry on the screens with light flat restraint. Keep the chosen method the same throughout comparisons. Dry at room temperature to a stable mass; record elapsed time. Do not claim a 24-hour drying time for every recipe and thickness. Very thick samples can stay wet inside after the surface feels dry.

## Paper, leaves and a fair school experiment

Start with two known recycled papers: uncoated office paper and uncoated brown kraft bag/packing paper. Remove staples, tape, glossy coatings and laminations. Process each paper as a separate labeled batch using the same soaking and blending procedure. The best local paper cannot be identified from the sketch or the color of its pulp; it must be compared experimentally.

Treat cleaned, untreated autumn leaf particles mainly as a variable filler inside a paper-fiber network. Remove stems and coarse veins, dry the chosen leaves to a repeatable condition, weigh them, and grind them separately. Particles below approximately 0.5–1 mm are a practical initial target, particularly for the 1 mm wet gap; record the size method rather than claiming an exact sieve result without a sieve. Select one tree species first. Do not mix unknown species and expect repeatable material strength.

There is primary evidence that paper can incorporate leaves, but treatment matters. A maple-leaf study made sheets from chemically delignified plant material; its results do not establish that untreated autumn leaves blended in water will have the same properties. Its laboratory chemical treatment is not needed for the initial school test. [Kolya and Kang, maple-leaf paper](https://doi.org/10.3390/ma18040910). An earlier tea-leaf composite study reported decreasing strength with increasing leaf fraction; this supports testing low leaf fractions first, as an analogy rather than a numerical prediction for autumn tree leaves. [Takahashi et al., authors' research abstract](https://kyushu-u.elsevierpure.com/en/publications/preparation-of-compounded-papers-using-wasted-tea-leaves/)

Use leaf fractions of 0%, 10%, 20% and 30% of total conditioned dry paper-plus-leaf mass as a first screening, with no binder added. Keep species, particle processing, blending, screen, pressure/closure procedure, drying method and environment fixed. A 100% paper sample is essential as a control. Compare starch or another teacher-approved binder later as its own variable, because it changes the experiment and recyclability behavior.

A manageable staged plan is:

1. **Pilot calibration.** With paper only, find a reproducible dry-solids charge for the middle wet gap. Record mass, drainage, force/gap curve, stop contact, dry dimensions, five-point thickness and density. Change charge before drawing conclusions if the pulp underfills or cannot approach the stop at the chosen initial force.
2. **Material screening.** Compare two paper types × four leaf fractions × three independent cards = 24 cards at one chosen gap and one repeatable press procedure. Match total dry-solids charge, not a scoop of watery slurry. If recipes reach the stop at different measured forces, include those forces in the report.
3. **Thickness study.** Use the selected recipe at all five wet gaps, with at least three cards per gap = 15 cards. Calibrate dry charge for each gap, record measured dry thickness, density and mass. A thickness study that changes density at the same time cannot attribute strength changes only to thickness.
4. **Pressure study.** With the selected recipe and a suitable charge/gap, compare three force-measured pressure steps on separate specimens. Where frame contact occurs, report the pressure before contact and the later gap-controlled phase separately. Do not label all closed-mold specimens as having the same measured pulp pressure.

Condition every sample together after drying, ideally near 23°C and 50% relative humidity if equipment is available, or document the actual room temperature/humidity. The cited handsheet study used 23°C/50% RH; a school comparison needs consistent conditions even without a controlled chamber. A stable-mass criterion such as less than 1% mass change over another 24 hours is a practical project choice, not a standard-paper moisture determination.

Record sample ID, paper source, leaf species, leaf dry fraction, solids charge, screen thickness, frame measured thickness, target and measured force, hold time, stop contact time, drying method, dry mass, final length/width, and thickness at center plus four inset corners. Use the measured outline area for final density, or state when the nominal cavity area is used. Apparent dry density is mass/(dry area × mean thickness); it is not intrinsic cellulose density.

For a simple strength comparison, support a card over a fixed 60 mm span, load it centrally through a rounded nose, and record first damage/breaking load with the same setup and loading speed. A laboratory force gauge is best; a carefully incremented small load gives only coarse comparative results. For a rectangular coupon with small deflection, approximate flexural stress is 3 F L/(2 b t²), using measured width and dry thickness. Defects, anisotropy, large deflection and crumbly leaf inclusions limit the formula. Report breaking load and geometry even when the formula is unsuitable. Because stiffness scales roughly with thickness cubed and bending capacity with thickness squared, a 5 mm card can carry much more load than a 1 mm card without being a better fiber recipe. Compare recipe performance at matched thickness/density, and retain raw observations.

## Buying list

- About 0.6 kg PETG for the complete two-platen/five-frame prototype set plus allowances; a 1 kg spool is a practical purchase. Exact consumption comes from the final slicer, not these bulk-volume estimates.
- Two flat steel backers, 130 × 100 × 8 mm, each with the same eight Ø6.6 mm hole centers, deburred. Approximate combined steel mass is 1.6 kg. Stainless is a corrosion-resistant upgrade; protect ordinary steel from persistent wet contact without blocking drainage.
- Eight fully threaded M6 × 60 mm bolts, eight compatible nuts, sixteen washers. Backers/platens/5.4 mm frame stack is 45.4 mm, plus washers and nut; confirm actual engagement and hardware thickness. Use metal hardware in the load path.
- A small sheet of specified 100–200 μm aperture screen, enough for two 84.5 × 54.5 mm pieces plus spares; check actual compressed thickness before printing the final frames.
- Calipers, a flat reference, feeler gauges and a 0.01 g readable balance suitable for several-gram cards; blotter paper or absorbent felt, flat drying boards, a drainage tray and labeled sample bags.
- Uncoated recycled office paper, uncoated brown kraft paper, cleaned leaves from a documented species, water, and a dedicated pulp blender. No binder is required for the baseline.
- For measured-pressure work, borrow a controllable small compression press and an approximately 1–2 kN calibrated compression sensor/force gauge in the direct load path. Pressure films can show uneven contact if their rated range fits, but are not a substitute for force/gap measurement.

A reusable all-metal version is the premium option: machined aluminum or stainless platens with fine removable screen, rigid metal stops and measured-force pressing. It improves stiffness and dimensional durability, especially for repeated thin cards or heated processing. It still needs an experimentally measured pressure/time/drying recipe; expensive tooling alone does not identify an optimal material.
