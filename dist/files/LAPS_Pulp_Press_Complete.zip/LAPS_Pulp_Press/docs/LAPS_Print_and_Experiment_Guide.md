# Autumn-leaf pulp card press

Autumn-leaf pulp card press

Reusable PETG mould faces • interchangeable thickness rings • steel load spreaders

School-project manufacturing and experiment guide | Revision A | 6 October 2026

> The five rings set nominal WET compressed pulp gaps of 1, 2, 3, 4 and 5 mm. They do not guarantee those finished dry thicknesses. Record the dry result and calibrate the process for your paper, leaf species, mesh and printer.

### What this design does

Two identical 130 × 100 × 12 mm PETG plates enclose an 85 × 55 mm card cavity. A removable PETG ring forms the side wall and the thickness stop. Fine woven mesh retains the fibres while 77 drain holes in each face and shallow rear channels carry water to the outside edges. Two 8 mm steel backers spread the load and reduce plate bending.

Buy one set of plates, backers and fasteners; change only the ring for each thickness trial. The supplied default assembly shows the 3 mm wet-gap ring. Do not stack the supplied rings: every ring already includes the allowance for two mesh layers.

### Read these points before printing

The printer answer was “elegoo carbon”; this guide assumes the ELEGOO Centauri Carbon with a 0.4 mm nozzle and a 256 × 256 mm bed. Confirm the machine name, nozzle and material profile in your slicer. Every printed part is at most 130 × 100 mm. No pre-sliced machine G-code is supplied.

The model is an analytical prototype, without physical proof testing or a certified pressure rating. The proposed 0.05–0.20 MPa pulp-pressure study range requires a supervised, measured-force press and inspection. Hand-tightened bolts hold a repeatable gap; they cannot establish a known pulp pressure.

| Included geometry | Nominal specification |
| --- | --- |
| Finished cavity outline | 85 × 55 mm, internal corner radius 3 mm |
| Reusable PETG faces | 2 identical plates; 130 × 100 × 12 mm; outer radius 6 mm |
| Gap choices | 1–5 mm wet pulp; ring heights 1.4–5.4 mm |
| Backing plates | 2 real steel plates, 130 × 100 × 8 mm |
| Drainage | 77 × Ø2 mm holes per face, 7 mm grid; rear channels 1.6 × 1.2 mm |

Use the separate dimensioned technical drawings and STEP files for fabrication. Rendered images and the iPhone AR view illustrate the assembly; they are not measurement tools.

## 1. Parts to print, make and buy

| Item | Qty | Purchase / manufacture specification | Estimate |
| --- | --- | --- | --- |
| Printed PETG drainage face | 2 | 130 × 100 × 12 mm; 8 × Ø6.6 bolt holes; 77 × Ø2 drains | 187.8 g each |
| Printed PETG gap rings | 1 each | Five heights: 1.4, 2.4, 3.4, 4.4, 5.4 mm | 14.3 / 24.5 / 34.7 / 44.9 / 55.1 g |
| Steel backer | 2 | 130 × 100 × 8 mm; R6 corners; 8 × Ø6.6 holes; flat and deburred | 797 g each |
| Fully threaded M6 × 60 bolt | 8 | Metal hex-head bolts; use a matching nut grade/material | Purchased |
| M6 flat large washer | 16 | Approximately Ø18 outside × 1.6 mm thick; e.g. DIN 9021 | Purchased |
| Standard M6 hex nut | 8 | Metal; avoid printed nuts and bolts | Purchased |
| Woven stainless-steel forming mesh | 2 cut pieces | 84.5 × 54.5 mm, R3 corners; aperture 100–200 µm | 0.20 mm each assumed |
| PETG filament | 1 × 1 kg spool | Approximately 549 g CAD solid mass for all printed parts; allow for calibration/brims | Density assumption 1.27 g/cm³ |

The mesh is purchased screen material, not a printed perforated sheet. A useful candidate is 100 mesh per inch with approximately 0.10 mm wire: its ideal square aperture is 25.4/100 − 0.10 = 0.154 mm. Woven-screen thickness can differ from twice the wire diameter; measure the actual material. Buy enough stock for spare pieces and a small forming strainer.

The PETG mass estimates use exact CAD volumes and a nominal density; slicer estimates and actual spool consumption will differ. Steel mass assumes 7.85 g/cm³. Make or order the steel backers from the supplied drawing; do not substitute printed plastic for this part.

### Useful school-lab tools

Digital calliper or micrometer, flat reference surface, 0.01 g balance, two small spanners, catch tray, scissors or suitable mesh shears, gloves for sharp screen edges, labelled jars, dedicated blending vessel, drying rack, absorbent blotting sheets and a force gauge for bending tests. A supervised measured-force press is optional equipment for pressure experiments; it is not included in the bolt-held mould.

Specify fully threaded 60 mm bolts. The maximum solid stack is 16 + 24 + 5.4 = 45.4 mm, or about 48.6 mm including two 1.6 mm washers. Allow a standard nut and visible thread engagement. Verify the actual hardware fits, clears the press and does not bottom out. Use one washer beneath each bolt head and one beneath each nut.

## 2. Dimensions and thickness calibration

### Shared bolt pattern

Origin: centre of the plate. All dimensions are millimetres. The eight Ø6.6 mm clearance holes are at (−53, −38), (0, −38), (53, −38), (−53, 0), (53, 0), (−53, 38), (0, 38), (53, 38). The PETG faces, gap rings and steel backers use the same pattern.

### Drainage face

The 77 Ø2 mm drains form 11 columns at x = −35, −28, …, +35 and 7 rows at y = −21, −14, …, +21. Their total nominal open area is 241.9 mm² per face, approximately 5.18% of the rounded card cavity area. Two draining faces shorten the water path; the fine mesh and pulp permeability still control actual drainage.

On the outer back face, six 1.6 mm wide × 1.2 mm deep channels run across the 130 mm plate at y = ±7, ±14 and ±21. The central row channel runs from x = −46 to +46, with branches at x = ±46 leading to the front edge. This avoids the middle side bolt holes. All channel exits must stay open over a catch tray.

### One ring at a time

| Nominal wet pulp gap | CAD ring height | Layers at 0.20 mm | Wet cavity volume |
| --- | --- | --- | --- |
| 1 mm | 1.4 mm | 7 | 4.667 mL |
| 2 mm | 2.4 mm | 12 | 9.335 mL |
| 3 mm | 3.4 mm | 17 | 14.002 mL |
| 4 mm | 4.4 mm | 22 | 18.669 mL |
| 5 mm | 5.4 mm | 27 | 23.336 mL |

Relationship: achieved wet gap ≈ measured ring height − lower mesh thickness − upper mesh thickness. This assumes the faces are flat, the ring is fully seated and deformation is small. The mesh pieces fit inside the cavity; do not lay mesh or blotting cloth across the ring lands, because that changes the stop height.

Measure each printed ring at eight positions after it cools. Aim for no more than ±0.05 mm variation as a calibration goal, not as a guaranteed printer tolerance. Also measure face flatness on a reference surface. Remove burrs and elephant-foot edges carefully; use a controlled flat sanding method only if you can remeasure the result. Record any thickness removed.

Measure the two mesh layers together between flat surfaces under light repeatable contact, without crushing them. If their combined caliper is 0.60 mm instead of 0.40 mm, every supplied ring gives approximately 0.20 mm less wet gap. Change the parametric ring height or label the measured gap. A fixed first-layer-height offset, variable layer heights or sanding changes the nominal layer-count calculation.

> For a desired finished dry thickness, first measure a pilot shrinkage ratio r = dry thickness / actual wet gap. A next trial needs wet gap ≈ target dry thickness / r, and ring height ≈ that gap + both measured mesh layers. The maximum supplied wet gap is 5 mm; the kit does not promise a 5 mm dry card.

Illustrative calibration only: a measured r = 0.8 and a 3 mm dry target suggest a 3.75 mm wet gap and 4.15 mm ring with the assumed mesh. Choose a 4.2 mm printable ring, then remeasure. In the CAD build script, add 3.8 to NOMINAL_PULP_GAPS_MM, for example [1, 2, 3, 3.8, 4, 5]; this makes the 4.2 mm ring. Keep ASSEMBLY_GAP_MM = 3 unless changing the displayed default. Revalidate hardware fit for any taller custom stack.

## 3. Load, stiffness and drainage physics

### Pressure means measured force over pulp area

The rounded cavity area is A = 85 × 55 − (4 − π) × 3² = 4667.274 mm². While only the pulp carries the applied load, pressure p = F/A. This relation ceases to describe pulp pressure when the spacer ring or another contact path carries some of the press force.

| Proposed trial pressure | Total pulp force | Equivalent kgf | Equal share / 8 bolts* |
| --- | --- | --- | --- |
| 0.05 MPa = 50 kPa | 233.4 N | 23.8 kgf | 29.2 N |
| 0.10 MPa = 100 kPa | 466.7 N | 47.6 kgf | 58.3 N |
| 0.20 MPa = 200 kPa | 933.5 N | 95.2 kgf | 116.7 N |

*Equal bolt shares are only a force-balance illustration. Tightening will not distribute forces equally, and the table gives no tightening torque or hardware rating. The kgf column is a unit conversion, not a method of applying body weight.

### Why use 8 mm steel backing plates?

A simple strip model screens bending along the long axis. It assumes a simply supported 106 mm span between the outer bolt columns, 55 mm strip width, an 85 mm long centred uniformly loaded region, steel E = 200 GPa and I = b h³ / 12. At 0.20 MPa, one solid 8 mm backer has an estimated centre deflection of 0.0367 mm and bending stress of 25.3 MPa. Two facing backers could contribute about 0.0734 mm total gap opening under these assumptions.

Using the same idealisation with a 12 mm PETG plate and E = 1.5 GPa gives about 1.45 mm deflection per plate before accounting for holes and channels. PETG faces therefore provide the cavity and drainage surface; metal supplies the useful bending stiffness. Increasing thickness is powerful because flexural stiffness scales with thickness cubed.

This is an estimate, not FEA or a verified allowable load. Real behaviour includes discrete bolts, clearances, plate bending in two directions, steel/PETG contact, local surface unevenness, channel interruptions and time-dependent PETG deformation. The steel value uses a generic elastic modulus; no steel grade or factor of safety has been certified.

### PETG printing and long holds

Printed PETG is directional. Layer adhesion, moisture, extrusion calibration and temperature affect strength. A published Prusament PETG data sheet reports roughly 1.5–1.7 GPa tensile modulus and 18 ± 4 MPa interlayer adhesion for its test specimens; these are context for the estimate, not guaranteed properties of your filament or print. Keep this prototype at room temperature; do not hot-press it. PETG can creep during long loading even well below its softening temperature.

Water flow follows the pressure gradient through the pulp and mesh. Higher pressure can help at first but can also compact the network, slow later drainage, drive fines into the mesh and increase imprinting. No leaf-pulp permeability was measured, so a drainage rate or mathematically optimal pressure cannot be predicted. Use mass and drainage observations to find a repeatable setting.

## 4. PETG printing and inspection

Print two identical PETG faces and one of each desired ring. STL dimensions are millimetres; keep scale at 100%. Steel backers and mesh envelopes are reference parts and must not be sliced as functional plastic components.

| Slicer choice | Initial setting / reason |
| --- | --- |
| Orientation | Faces: rear drainage grooves toward the bed; smooth pulp face upward. Rings: flat on the bed. |
| Nozzle / layers | 0.4 mm nozzle; 0.20 mm layer height, including 0.20 mm first layer if supported by the profile. |
| Structure | 6 perimeter walls; 100% infill; 8 top and 8 bottom layers as an initial solid-print setup. |
| Supports | No supports initially. Rear groove roofs bridge only 1.6 mm; confirm short bridges in slicer preview. |
| Adhesion | Clean build surface and use the PETG-compatible release/adhesion method specified for that surface. Brim only if needed. |
| Speeds / flow | Start with 40–60 mm/s outer walls and 80–100 mm/s inner walls; cap volumetric flow at 6–8 mm³/s initially. |
| Temperature | For ELEGOO PETG PRO only: maker range 230–260 °C nozzle, 65–75 °C bed; begin around 240 / 70 °C. |
| Fan / multiplier | Use the actual filament manufacturer’s profile. Calibrate flow and short bridging; do not assume a universal flow multiplier or fan value. |

These are conservative starting values, not a validated machine profile. A volumetric limit can reduce speeds below the requested wall values. Different PETG brands and products need their own data sheets. Dry filament using the filament manufacturer’s directions if bubbling, stringing or weak bonding occurs; do not infer drying settings from nozzle temperature.

### Inspect before contact with pulp

1. Verify that the printed thickness, outside dimensions and hole pattern match the drawing. Check for lifting corners, layer separation, missing infill and uneven top surfaces. Reject a visibly damaged face.

2. Clear all 77 holes in each face and check every channel exit. A gentle Ø2 mm hand-tool cleanup may be needed; do not enlarge holes aggressively or cut away the channel roofs.

3. Check that all eight metal bolts pass freely through the assembled holes, without forcing alignment. Carefully ream burrs to drawing size if needed. Keep enough clearance for assembly but avoid uncontrolled hole enlargement.

4. Deburr steel holes and screen edges. The steel backers must sit flat against the PETG outer faces. Remove loose machining debris and keep rust, oil and sharp edges away from the pulp.

5. Assemble without pulp, check ring seating and map the actual ring/mesh gap. Add a small water-only test over a tray to confirm edge discharge. Then run a low-force pulp pilot before larger or repeated loads.

## 5. Assembly, pressing and release

### Stack from bottom to top

| Order | Part / orientation |
| --- | --- |
| 1 | Lower 8 mm steel backer |
| 2 | Lower PETG face: channels face the steel; smooth perforated face points up |
| 3 | One chosen PETG ring, aligned to the bolt pattern |
| 4 | Lower mesh inside the ring opening, resting on the lower PETG face |
| 5 | Evenly spread, pre-drained paper/leaf pulp charge |
| 6 | Upper mesh inside the opening, on top of the pulp |
| 7 | Upper PETG face: smooth perforated face down; channels point outward |
| 8 | Upper 8 mm steel backer |

The ring surrounds the pulp and both screens, while its lands touch the PETG faces directly. Moisten the mesh so it lies flat. Keep pulp off the ring lands and do not fold the screen. Leave rear-channel outlets exposed; a catch tray belongs below the assembly, not pressed into the outlets.

### Bolts: repeatable gap mode

Install one washer beneath each bolt head and each nut. Tighten by hand in small alternating passes across the plate: opposite corners first, then the other corners, then opposite edge-centre positions. Stop when the ring is evenly seated and the plates stay aligned. Do not use power tools, impose an assumed torque-to-pressure conversion or continue tightening to crush the ring. Record the measured closed stack height.

This mode sets geometry. Pulp pressure will vary with the charge, water content and tightening. An underfilled charge can reach the ring stop with little or no compression on the pulp. After the faces reach the ring, extra bolt load increasingly passes through the ring. As pulp shrinks during drying, a fixed-gap assembly can lose pressure on the card altogether.

### Measured-force press: pressure mode

Use a supervised press with a load readout or load cell and flat platens that support the steel backers. Use the press manufacturer’s documented tare and calibration method, and record the zero setting and load-readout uncertainty before each trial. Omit the bolts during the measured dwell so they do not introduce preload or collide with the press platens. Keep the stack aligned and use the spacer as a gap stop. Any alignment fixture must not carry parallel compressive load. The teacher must check press stability, plate support and the practical setup before loading.

For a pilot, start at 0.05 MPa equivalent force and hold about 5 minutes; record drainage and whether the ring is seated. If the ring is still clear and the assembly remains flat and undamaged, test 0.10 MPa and then at most the proposed 0.20 MPa study step. For comparisons, choose one repeatable level and dwell. If the ring seats before the selected force, label the trial “stop contacted”: the displayed total force no longer establishes pulp pressure.

Unload the press before handling the stack. Release nuts gradually and lift the top plate without pulling the wet card. Lift out the ring if free, then support the card on its lower mesh and peel the upper mesh gently. Rinse holes and channels promptly. After drying, inspect the PETG for distortion or cracks before reuse.

## 6. Pulp preparation and drying

### Choose reproducible ingredients

Begin with plain, uncoated recycled office paper from one batch. Compare it with one batch of uncoated kraft paper bags as a second recycled source. Remove staples, labels, plastic tape and glued seams. Avoid thermal receipts, coated magazine stock and food-soiled paper in the first experiment. Paper source changes fibre length, additives and pulping behaviour; “recycled” alone does not define a strength.

Collect fallen leaves from one identifiable tree species and one condition. Rinse away dirt, discard visibly mouldy material, air-dry it to stable mass, and record the species and collection date. Chop or crush to roughly 1–3 mm before wet blending. After wet blending, remove thick stems and coarse fragments; for the 1 mm gap, target leaf fragments mostly below approximately 0.5–1 mm and record the sorting or sieving method. Keep this size protocol constant. Paper supplies the bonding fibre network; raw leaf fragments may interrupt it, so a high leaf percentage is not automatically stronger.

### Prepare a card charge

1. Weigh paper and leaves separately in their dry, consistently conditioned state. Define leaf percentage as dry leaf mass / total dry paper-plus-leaf mass × 100. Use no added glue, starch or chemical treatment for the first screening study.

2. Tear the paper into small pieces and soak in room-temperature water overnight. Soak the chopped leaves separately. Blend with enough water for the equipment, using the same blend time for every batch. A dedicated vessel under school supervision avoids transferring project residues into food equipment.

3. Use a forming screen of the same aperture to pre-drain the individual measured batch into a damp mash. Retain as much fibre and leaf material as practical, rinse the blender into the screen, and record visible fine-material losses. A thin 85 × 55 mm cavity holds only 4.7–23.3 mL at the selected gaps; it cannot hold an entire large volume of dilute stock slurry at once.

4. Spread the damp charge evenly into the ring opening, cover with the upper screen and close the mould gradually. Avoid a central mound. A useful first pilot is approximately 1.5 g dry solids per nominal millimetre of wet gap: 4.5 g at a 3 mm wet gap. This is a trial charge, not a predicted density or final thickness. Increase or reduce it after measuring the result, keeping the selected dose identical across recipe comparisons.

5. Record dry input mass, added water, retained solids where measurable, blend time, pre-drain method, press force/dwell or bolt-only mode, actual ring height and screen caliper. Final dry specimen mass will reveal losses and support density calculations.

### Dry gently and measure shrinkage

After wet pressing, transfer the supported sheet to clean absorbent blotters on a flat surface. Use a light, consistently applied flat drying restraint if needed to reduce curl, then change wet blotters and allow air exchange on both faces. Mesh support can remain until the sheet is handleable. Keep the method the same for every specimen; a closed fixed-gap PETG mould is not a guaranteed drying-pressure system.

Dry at room temperature. Compare mass at 24-hour intervals and call it stable when two successive readings differ by less than 1%, within the balance resolution. Then condition every specimen for a further consistent 48 hours in the same room before testing; record temperature and relative humidity if available. A target near 23 °C / 50% RH is useful if the school can actually control it. Do not describe an uncontrolled room as standardized conditioning.

## 7. Experiment plan and strength comparison

### Screen the recipe before testing every gap

| Stage | Factors held / changed | Minimum useful specimen count |
| --- | --- | --- |
| A. Recipe screen | 3 mm nominal wet gap; 2 paper sources × leaf fractions 0, 10, 20, 30%; one leaf species; 3 repeats | 24 cards |
| B. Gap screen | Best 1–2 recipes × wet gaps 1, 2, 3, 4, 5 mm; 3 repeats; same process | 15–30 cards |
| C. Confirm | Repeat the preferred recipe/gap on a new day or batch | At least 3 cards |

For a 4.5 g dry input batch, 0%, 10%, 20% and 30% leaves mean respectively 0.00, 0.45, 0.90 and 1.35 g leaves, with the balance as paper. Randomize pressing and testing order. Label each specimen before drying. Keep paper, leaf species, mesh, blend time, water, dry-solid dose, pressing sequence and drying method fixed within a comparison.

Recipe stage: hold the dry input mass and wet gap constant, so recipe-related retention and density changes become visible in the final measurements. Gap stage: start with dry-solids dose proportional to nominal wet gap and record the achieved dry density. If density varies substantially, report that the process changed both thickness and density; do not attribute all strength differences to thickness alone.

### Measurements before breaking a card

Record dry mass, length, width, five thickness measurements (centre and four interior quarter points), average thickness, thickness range, visible voids and curl. Apparent dry density in g/cm³ = 1000 × dry mass in g / [measured outline area in mm² × mean thickness in mm]. If the outline remains the supplied R3 card shape, area = measured length × measured width − (4 − π) × 3².

### A school three-point bending comparison

Place the card across two smooth, parallel supports 60 mm apart along its 85 mm length. Apply a central line load across the full width using a rounded bar and force gauge, with the same slow loading method for every card. Record peak force F, load–deflection data if available, and whether it bends, tears, delaminates or crushes. Keep fingers away from the loaded supports.

For a rectangular, simply supported beam approximation, apparent flexural failure stress σ = 3 F L / (2 b t²), with F in N and span L, width b and actual dry thickness t in mm; the result is MPa. Use measured dry dimensions, not the ring label. A 10% error in thickness produces roughly a 20% error in this stress estimate. At F = 10 N, L = 60 mm, b = 55 mm and t = 3 mm, σ ≈ 1.82 MPa; this is a calculation example only.

The 60 mm whole-card span is a practical comparative setup, not an ASTM test. For a 5 mm dry card L/t = 12, so shear and local crushing may influence results. If available, compare thinner cut strips with a span near 16t or greater, while preserving room at each end; an 80 mm span on an 85 mm card leaves very little end margin. Record the actual span and all fixture dimensions.

Report the mean and spread of peak force, apparent stress, dry thickness and density for each group. With only three repeats, show all individual values. Select the useful recipe by strength, uniformity, flatness, handling, material use and leaf content together; there is no verified best leaf percentage before testing.

## 8. Records, files and iPhone AR

### Use the included sheets

bom.csv lists quantities and procurement specifications. experiment_template.csv is a blank data table for individual cards. Retain the original blank template and duplicate it for trials. “Pressure” may be filled only when force is measured and the frame has not contacted; otherwise record bolt-only mode or stop contact and leave pressure blank.

| Record group | Fields that matter |
| --- | --- |
| Identity | Specimen ID, date, repeat, paper source, leaf species, dry leaf fraction |
| Recipe | Dry paper and leaf input, water, blend duration, visible fines loss |
| Mould | Ring measured height and variation, combined mesh caliper, actual wet gap |
| Press | Bolt-only / measured-force mode, force, stop contact, dwell, expelled water |
| Drying | Method, stable-mass readings, temperature, humidity, conditioning duration |
| Result | Dry dimensions, 5 thickness points, dry mass, density, curl, defects |
| Bending | Span, force, apparent stress, failure mode, notes |

### Blender, CAD and renders

Open the supplied .blend project in Blender to inspect the assembled and exploded model and camera views. Use the STEP parts for CAD interchange and the individual STL files for slicing the PETG parts. The CAD build script is the parametric source; STEP does not preserve its feature history. Technical drawings identify all dimensions, parts and materials; the rear-face detail is needed to inspect drainage.

PNG views show perspective, side and plan orientations. Rendered mesh envelopes represent where purchased screens sit; they are not an instruction to print fine mesh. Steel and hardware materials are illustrative. All fabrication must follow the dimensions and material labels rather than colours in a render.

### iPhone AR viewing

Save the supplied .usdz file to the iPhone Files app, or open it from a download link in Safari. Tap the file for Quick Look, then select AR if offered. Permit the camera, point toward a clear surface and move the phone slowly until a plane is found. Object mode lets you rotate the model without placing it in the room.

Check that the model appears about 130 × 100 mm at its base; pinching can change the preview scale. AR is for understanding the stack and clearances, not checking manufacturing dimensions. The package format can be validated in software, but this project has not been physically tested on your iPhone.

### When to revise the prototype

Recalibrate if the mesh, filament, nozzle, first-layer height, ring surface finish or drying method changes. A different card outline requires new faces, rings, meshes and compatible load-spreading geometry. Do not increase the trial load merely because the bolts can tighten further. If the faces bow, the ring deforms, a layer separates or drainage becomes blocked, stop, unload and inspect the affected part.

The file set gives you a concrete prototype and a way to compare results. Physical dry-card strength, a safe press-force limit, leaf chemistry and long-term PETG durability remain experimental outputs; they are not established by the CAD geometry or the bending estimate.

## 9. Evidence and scope

Sources below support material context and experimental choices. None certifies this mould. Product settings apply only to the named material, and published paper formulations differ from raw recycled-paper/autumn-leaf mash. URLs were checked for this guide on 6 October 2026.

[1] ELEGOO, PETG PRO filament product specifications.

Manufacturer nozzle range 230–260 °C and bed range 65–75 °C; use the actual filament instructions.

https://www.elegoo.com/products/petg-pro-filament-1-75mm-colored-1kg

[2] Prusament, PETG Technical Data Sheet, October 2021.

Printed-specimen modulus and interlayer-strength context; different material and test conditions from this project.

https://prusament.com/wp-content/uploads/2022/10/PETG_Prusament_TDS_2021_10_EN.pdf

[3] NASA-STD-5020B, requirements for threaded fastening systems.

Torque-control uncertainty and fastening principles; not an applicable school-mould design certification.

https://standards.nasa.gov/sites/default/files/standards/NASA/B/0/2021-08-06-nasa-std-5020b_final.pdf

[4] BioResources, “Utilization of cellulose micro/nanofibrils as paper additive for the manufacturing of security paper” (2018).

The hand-sheet procedure used a 345 kPa, 5 minute wet press and controlled conditioning. Our lower proposed trial forces are prototype choices, not a claim of identical pulp behaviour.

https://bioresources.cnr.ncsu.edu/resources/utilization-of-cellulose-micro-nanofibrils-as-paper-additive-for-the-manufacturing-of-security-paper/

[5] “Preparation of compounded papers using wasted tea leaves” (2007), author publication record.

Tea-leaf addition provides an analogy for strength changes, not a prediction for untreated tree leaves.

https://kyushu-u.elsevierpure.com/en/publications/preparation-of-compounded-papers-using-wasted-tea-leaves/

[6] Materials 18(4), article 910 (2025).

A maple-leaf paper study used chemically delignified leaves. It cannot establish the performance of this raw-leaf school recipe.

https://doi.org/10.3390/ma18040910

[7] Polymers 17(15), article 2075 (2025).

Time-dependent deformation of printed PETG supports measuring long holds rather than treating PETG as perfectly elastic.

https://doi.org/10.3390/polym17152075

### Analytical assumptions retained for review

Cavity area includes R3 corner cut-outs. Backer estimate assumes E = 200 GPa, span 106 mm, width 55 mm, thickness 8 mm and 85 mm centred load. PETG comparison assumes E = 1.5 GPa and an unperforated 12 mm strip. Mesh combined caliper is nominally 0.40 mm; PETG density 1.27 g/cm³ and steel density 7.85 g/cm³. No measured pulp permeability, print coupon strength, press calibration or dry shrinkage data was available.
