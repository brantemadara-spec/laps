"""Render the Latvian Blender how-to from the maintained Markdown source."""
from pathlib import Path
import re
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

OUT=Path(__file__).resolve().parent
for name,file in [('LVP','DejaVuSans.ttf'),('LVPBold','DejaVuSans-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+file))
pdfmetrics.registerFontFamily('LVP',normal='LVP',bold='LVPBold',italic='LVP',boldItalic='LVPBold')
navy=colors.HexColor('#163947');teal=colors.HexColor('#0E776C')
styles={
 'title':ParagraphStyle('title',fontName='LVPBold',fontSize=24,leading=30,textColor=navy,spaceAfter=15),
 'heading':ParagraphStyle('heading',fontName='LVPBold',fontSize=14,leading=19,textColor=teal,spaceBefore=14,spaceAfter=8,keepWithNext=True),
 'body':ParagraphStyle('body',fontName='LVP',fontSize=9.6,leading=14,textColor=navy,spaceAfter=7),
 'list':ParagraphStyle('list',fontName='LVP',fontSize=9.6,leading=14,textColor=navy,spaceAfter=6,leftIndent=13,firstLineIndent=-10),
 'cell':ParagraphStyle('cell',fontName='LVP',fontSize=8,leading=11,textColor=navy,wordWrap='CJK'),
 'head':ParagraphStyle('head',fontName='LVPBold',fontSize=8,leading=11,textColor=colors.white),
}
def rich(s):
    s=escape(s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'`(.+?)`',r'<font color="#0E776C">\1</font>',s)
    return s
lines=(OUT/'Blender_Lietosana_LV.md').read_text().splitlines()
story=[];i=0
while i<len(lines):
    line=lines[i].strip();i+=1
    if not line:continue
    if line.startswith('|'):
        table_lines=[line]
        while i<len(lines) and lines[i].lstrip().startswith('|'):
            table_lines.append(lines[i].strip());i+=1
        data=[]
        for ln in table_lines:
            cells=[x.strip() for x in ln.strip('|').split('|')]
            if all(re.fullmatch(r'[-: ]+',x) for x in cells):continue
            data.append(cells)
        columns=len(data[0]);widths=([45,135] if columns==2 else [82,25,73])
        t=Table([[Paragraph(rich(x),styles['head' if row==0 else 'cell']) for x in cells] for row,cells in enumerate(data)],colWidths=[w*mm for w in widths],repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),navy),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F1F5F4')]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,-1),0.25,colors.HexColor('#D8E2E2'))]))
        story.extend([t,Spacer(1,8)]);continue
    if line.startswith('# '):story.append(Paragraph(rich(line[2:]),styles['title']));continue
    if line.startswith('## '):story.append(Paragraph(rich(line[3:]),styles['heading']));continue
    if line.startswith('- '):story.append(Paragraph('• '+rich(line[2:]),styles['list']));continue
    if re.match(r'^\d+\. ',line):story.append(Paragraph(rich(line),styles['list']));continue
    story.append(Paragraph(rich(line),styles['body']))
def footer(canvas,doc):
    canvas.setFont('LVP',7);canvas.setFillColor(colors.HexColor('#53656B'))
    canvas.drawString(15*mm,11*mm,'LAPS · Blender un PETG prototips · 2026-10-06')
    canvas.drawRightString(195*mm,11*mm,str(doc.page))
doc=SimpleDocTemplate(str(OUT/'Blender_Lietosana_LV.pdf'),pagesize=(210*mm,297*mm),leftMargin=15*mm,rightMargin=15*mm,topMargin=16*mm,bottomMargin=22*mm,title='LAPS: Blender lietošana un prototipa drukāšana',author='LAPS project')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT/'Blender_Lietosana_LV.pdf')
