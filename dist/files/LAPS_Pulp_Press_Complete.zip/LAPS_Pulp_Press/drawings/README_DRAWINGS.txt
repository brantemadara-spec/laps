LAPS PULP-CARD PRESS / DRAWINGS / REV A

All DXF dimensions and units are millimetres, 1:1.
PDF sheets 01-05 are schematic scale; dimensions govern.
PDF sheets 06-08 are true 1:1 on A4, when printed at 100% Actual Size.
Check the 50 mm bar before transferring any template.
SVG sheets retain physical mm dimensions and editable vector text/lines.

P01 DXF includes separate layers for outer cut, bolt drilling, drain drilling,
back channel boundaries, and back channel centrelines. Grooves are on the
non-pulp face only. Do not cut all layers through the plate.
P02 DXF applies to all five spacer thicknesses. Only one ring is fitted.
P03 steel thickness is 8 mm; no drain holes are drilled in steel.
P04 mesh is a trimming pattern, not a machined part.

Suggested dimensional controls:
- Printed profile/XY: nominal +/-0.3 mm; calibrate actual printer.
- Bolt holes: nominal 6.6; check all M6 bolts fit before assembly.
- Ring thickness: measure at four corners; match within 0.10 mm if practical.
- Stop and pulp faces: aim for <=0.15 mm flatness across cavity.
These are workshop targets, not certified manufacturing guarantees.

Compressed mesh thickness 0.20 per face is a sizing assumption.
Actual wet gap = measured ring thickness minus measured mesh stack.
Final dry thickness is determined by the pulp recipe, compression, and drying.

The 3 mm example stack is 43.4 mm excluding washers and hardware.
Rev A supersedes preliminary 6 mm backers; final backers are 8 mm.
See the project engineering guide for force and experiment recommendations.
