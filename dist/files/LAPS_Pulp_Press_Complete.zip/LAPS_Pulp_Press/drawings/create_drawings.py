#!/usr/bin/env python3
"""Reproducible millimetre CAD drawings for the pulp-card press, revision A."""
from pathlib import Path
import math, json, html
from reportlab.pdfgen import canvas as pdfcanvas
from reportlab.lib.units import mm
import ezdxf

OUT = Path(__file__).resolve().parent
STEEL = 8.0
W, H, R = 130.0, 100.0, 6.0
CW, CH, CR = 85.0, 55.0, 3.0
PLATE_T = 12.0
HOLES = [(-53,-38),(0,-38),(53,-38),(-53,0),(53,0),(-53,38),(0,38),(53,38)]
DRAINS = [(x,y) for y in range(-21,22,7) for x in range(-35,36,7)]
GROOVES = [[(-65,y),(65,y)] for y in [-21,-14,-7,7,14,21]] + [[(-46,-50),(-46,0),(46,0),(46,-50)]]
C = {'ink':'#162b3b','blue':'#235875','grey':'#64727c','light':'#c4cdd3','petg':'#d7ebef','steel':'#dfe2e5','ring':'#f0d8b4','pulp':'#d1b388','mesh':'#5f7279','white':'#ffffff'}

def rgb(s):
    return tuple(int(s.lstrip('#')[i:i+2],16)/255 for i in (0,2,4))

class Sheet:
    def __init__(self,pdf,w,h,number,title,filename,scale='Schematic; dimensions govern'):
        self.pdf=pdf; self.w=w; self.h=h; self.number=number; self.filename=filename; self.items=[]
        pdf.setPageSize((w*mm,h*mm))
        self.text(14,h-17,'LAPS / RECYCLED PAPER + AUTUMN LEAVES',9,'blue',True)
        self.text(14,h-27,title,16,'ink',True)
        self.text(w-14,h-16,'PULP CARD PRESS  /  REV A',8,'grey',False,'right')
        self.line(14,h-33,w-14,h-33,'blue',.5)
        self.line(14,30,w-14,30,'blue',.35)
        self.text(14,22,'ALL DIMENSIONS IN mm   |   NOMINAL CAD DIMENSIONS   |   DO NOT SCALE SCHEMATIC VIEWS',7,'grey')
        self.text(14,15,scale,7,'grey')
        self.text(w-14,15,f'SHEET {number:02d} / 08  |  06 OCT 2026',7,'grey',False,'right')
    def _set(self,color='ink',lw=.25,fill=None,dash=None):
        self.pdf.setStrokeColorRGB(*rgb(C.get(color,color))); self.pdf.setLineWidth(lw*mm)
        self.pdf.setFillColorRGB(*rgb(C.get(fill or color,fill or color)))
        self.pdf.setDash([x*mm for x in dash] if dash else [])
    def line(self,x1,y1,x2,y2,color='ink',lw=.25,dash=None):
        self._set(color,lw,dash=dash); self.pdf.line(x1*mm,y1*mm,x2*mm,y2*mm)
        ds=f' stroke-dasharray="{" ".join(map(str,dash))}"' if dash else ''
        self.items.append(f'<line x1="{x1:g}" y1="{self.h-y1:g}" x2="{x2:g}" y2="{self.h-y2:g}" stroke="{C.get(color,color)}" stroke-width="{lw:g}"{ds}/>')
    def rect(self,x,y,w,h,color='ink',lw=.25,fill=None):
        self._set(color,lw,fill); self.pdf.rect(x*mm,y*mm,w*mm,h*mm,stroke=1,fill=int(fill is not None))
        self.items.append(f'<rect x="{x:g}" y="{self.h-y-h:g}" width="{w:g}" height="{h:g}" fill="{C.get(fill,fill) if fill else "none"}" stroke="{C.get(color,color)}" stroke-width="{lw:g}"/>')
    def roundrect(self,x,y,w,h,r,color='ink',lw=.25,fill=None):
        self._set(color,lw,fill); self.pdf.roundRect(x*mm,y*mm,w*mm,h*mm,r*mm,stroke=1,fill=int(fill is not None))
        self.items.append(f'<rect x="{x:g}" y="{self.h-y-h:g}" width="{w:g}" height="{h:g}" rx="{r:g}" fill="{C.get(fill,fill) if fill else "none"}" stroke="{C.get(color,color)}" stroke-width="{lw:g}"/>')
    def circle(self,x,y,r,color='ink',lw=.25,fill=None):
        self._set(color,lw,fill); self.pdf.circle(x*mm,y*mm,r*mm,stroke=1,fill=int(fill is not None))
        self.items.append(f'<circle cx="{x:g}" cy="{self.h-y:g}" r="{r:g}" fill="{C.get(fill,fill) if fill else "none"}" stroke="{C.get(color,color)}" stroke-width="{lw:g}"/>')
    def poly(self,pts,color='ink',lw=.25,fill=None,closed=False,dash=None):
        self._set(color,lw,fill,dash); p=self.pdf.beginPath(); p.moveTo(pts[0][0]*mm,pts[0][1]*mm)
        for x,y in pts[1:]: p.lineTo(x*mm,y*mm)
        if closed:p.close()
        self.pdf.drawPath(p,stroke=1,fill=int(fill is not None))
        tag='polygon' if closed else 'polyline'; pp=' '.join(f'{x:g},{self.h-y:g}' for x,y in pts)
        ds=f' stroke-dasharray="{" ".join(map(str,dash))}"' if dash else ''
        self.items.append(f'<{tag} points="{pp}" fill="{C.get(fill,fill) if fill else "none"}" stroke="{C.get(color,color)}" stroke-width="{lw:g}"{ds}/>')
    def text(self,x,y,t,size=8,color='ink',bold=False,align='left',angle=0):
        self._set(color); self.pdf.saveState(); self.pdf.translate(x*mm,y*mm); self.pdf.rotate(angle)
        self.pdf.setFont('Helvetica-Bold' if bold else 'Helvetica',size)
        {'left':self.pdf.drawString,'right':self.pdf.drawRightString,'center':self.pdf.drawCentredString}[align](0,0,t)
        self.pdf.restoreState()
        anchor={'left':'start','right':'end','center':'middle'}[align]
        rotate=f' transform="rotate({-angle:g} {x:g} {self.h-y:g})"' if angle else ''
        self.items.append(f'<text x="{x:g}" y="{self.h-y:g}" font-family="Arial,Helvetica,sans-serif" font-size="{size/mm:g}" font-weight="{"bold" if bold else "normal"}" fill="{C.get(color,color)}" text-anchor="{anchor}"{rotate}>{html.escape(t)}</text>')
    def arrow(self,x,y,angle,color='blue',length=2):
        a=math.radians(angle); d=.55*length
        pts=[(x,y),(x-length*math.cos(a)+d*math.sin(a),y-length*math.sin(a)-d*math.cos(a)),(x-length*math.cos(a)-d*math.sin(a),y-length*math.sin(a)+d*math.cos(a))]
        self.poly(pts,color,.15,color,True)
    def dimh(self,x1,x2,y,from_y,label):
        for x in (x1,x2): self.line(x,from_y,x,y+2 if y>from_y else y-2,'light',.16)
        self.line(x1,y,x2,y,'blue',.16); self.arrow(x1,y,180); self.arrow(x2,y,0)
        self.text((x1+x2)/2,y+2.2,label,8,'blue',False,'center')
    def dimv(self,y1,y2,x,from_x,label):
        for y in (y1,y2): self.line(from_x,y,x+2 if x>from_x else x-2,y,'light',.16)
        self.line(x,y1,x,y2,'blue',.16); self.arrow(x,y1,-90); self.arrow(x,y2,90)
        self.text(x-2.5,(y1+y2)/2,label,8,'blue',False,'center',90)
    def leader(self,pts,label,align='left',size=8):
        self.poly(pts,'blue',.18); p0,p1=pts[0],pts[1]
        self.arrow(*p0,math.degrees(math.atan2(p0[1]-p1[1],p0[0]-p1[0])),length=1.8)
        self.text(pts[-1][0]+(1 if align=='left' else -1),pts[-1][1]+1,label,size,'blue',False,align)
    def note(self,x,y,lines,size=8,leading=4.2,color='ink'):
        for i,t in enumerate(lines):self.text(x,y-i*leading,t,size,color)
    def label(self,x,y,num):
        self.circle(x,y,3.5,'blue',.25,'white'); self.text(x,y-1,str(num),7,'blue',True,'center')
    def finish(self):
        self.pdf.showPage()
        svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}mm" height="{self.h}mm" viewBox="0 0 {self.w} {self.h}">\n<rect width="100%" height="100%" fill="white"/>\n'+ '\n'.join(self.items)+'\n</svg>\n'
        (OUT/self.filename).write_text(svg)

def centerlines(s,cx,cy,k,w=W,h=H):
    s.line(cx-(w/2+4)*k,cy,cx+(w/2+4)*k,cy,'light',.18,[4,1,1,1])
    s.line(cx,cy-(h/2+4)*k,cx,cy+(h/2+4)*k,'light',.18,[4,1,1,1])

def face(s,cx,cy,k=1,kind='plate',grooves=False,labels=False,label_y=3):
    s.roundrect(cx-W*k/2,cy-H*k/2,W*k,H*k,R*k,'ink',.4)
    if kind=='ring':s.roundrect(cx-CW*k/2,cy-CH*k/2,CW*k,CH*k,CR*k,'ink',.4)
    centerlines(s,cx,cy,k)
    if kind=='plate':
        for x,y in DRAINS:s.circle(cx+x*k,cy+y*k,k,'ink',.2)
    for i,(x,y) in enumerate(HOLES,1):
        s.circle(cx+x*k,cy+y*k,3.3*k,'ink',.25)
        s.line(cx+(x-2)*k,cy+y*k,cx+(x+2)*k,cy+y*k,'light',.12)
        s.line(cx+x*k,cy+(y-2)*k,cx+x*k,cy+(y+2)*k,'light',.12)
        if labels:s.text(cx+(x+5)*k,cy+(y+label_y)*k,f'H{i}',7,'blue')
    if grooves:
        for pts in GROOVES:
            for j in range(len(pts)-1):
                x1,y1=pts[j];x2,y2=pts[j+1]
                if y1==y2:
                    s.line(cx+x1*k,cy+(y1-.8)*k,cx+x2*k,cy+(y2-.8)*k,'blue',.22)
                    s.line(cx+x1*k,cy+(y1+.8)*k,cx+x2*k,cy+(y2+.8)*k,'blue',.22)
                else:
                    s.line(cx+(x1-.8)*k,cy+y1*k,cx+(x2-.8)*k,cy+y2*k,'blue',.22)
                    s.line(cx+(x1+.8)*k,cy+y1*k,cx+(x2+.8)*k,cy+y2*k,'blue',.22)

def outerdims(s,cx,cy,k=1,offset=9):
    s.dimh(cx-W*k/2,cx+W*k/2,cy+H*k/2+offset,cy+H*k/2,'130')
    s.dimv(cy-H*k/2,cy+H*k/2,cx-W*k/2-offset,cx-W*k/2,'100')

def hole_table(s,x,y,width=135):
    s.text(x,y,'8 x Ø6.6 THRU  /  BOLT HOLE COORDINATES',9,'blue',True)
    s.text(x,y-6,'Origin: centre of outer profile. X right; Y up.',8,'grey')
    cols=[x,x+width/2]; positions=[HOLES[:4],HOLES[4:]]
    for c,rows in zip(cols,positions):
        s.text(c,y-13,'HOLE       X        Y',7,'grey',True)
        for j,(hx,hy) in enumerate(rows):
            idx=HOLES.index((hx,hy))+1
            s.text(c,y-19-j*5,f'H{idx}        {hx:+d}       {hy:+d}',8)
    s.line(x,y-35,x+width,y-35,'light',.15)

def section(s,cx,base,k=1.1,gap=3):
    st=gap+.4; upper=12+st; steel_top=upper+12
    xp=lambda x:cx+x*k
    zp=lambda z:base+z*k
    s.rect(xp(-65),zp(-STEEL),130*k,STEEL*k,'ink',.3,'steel')
    s.rect(xp(-65),zp(0),130*k,12*k,'ink',.3,'petg')
    s.rect(xp(-65),zp(upper),130*k,12*k,'ink',.3,'petg')
    s.rect(xp(-65),zp(steel_top),130*k,STEEL*k,'ink',.3,'steel')
    for bx in [-65,42.5]:s.rect(xp(bx),zp(12),22.5*k,st*k,'ink',.3,'ring')
    s.rect(xp(-42.5),zp(12.2),85*k,gap*k,'ink',.2,'pulp')
    for mz in [12,12.2+gap]:s.rect(xp(-42.5),zp(mz),85*k,.2*k,'mesh',.16,'mesh')
    # Drainage passage at section Y=0; channels face steel, never pulp.
    for z in [0,steel_top-1.2]:s.rect(xp(-46),zp(z),92*k,1.2*k,'blue',.16,'white')
    for dx in range(-35,36,7):
        s.rect(xp(dx-1),zp(1.2),2*k,10.8*k,'blue',.14,'white')
        s.rect(xp(dx-1),zp(upper),2*k,10.8*k,'blue',.14,'white')
    for bx in [-53,53]:
        s.rect(xp(bx-3.3),zp(-STEEL),6.6*k,(24+st+2*STEEL)*k,'ink',.18,'white')
        s.line(xp(bx),zp(-STEEL-4),xp(bx),zp(steel_top+STEEL+4),'light',.15,[3,1,1,1])
    return xp,zp

def create_pdf():
    pdf=pdfcanvas.Canvas(str(OUT/'LAPS_Pulp_Press_Technical_Drawings_RevA.pdf'))
    pdf.setTitle('LAPS pulp-card press / Rev A / manufacturing and assembly drawings')
    pdf.setAuthor('LAPS school project / dimensioned concept design')
    s=Sheet(pdf,420,297,1,'ASSEMBLY / VARIABLE WET THICKNESS','01_assembly.svg')
    face(s,106,173,1.05,'steel',labels=True); outerdims(s,106,173,1.05)
    s.text(106,108,'TOP VIEW / STEEL BACKER',9,'blue',True,'center')
    s.line(38,173,174,173,'blue',.35,[5,1])
    s.text(31,171,'A',9,'blue',True); s.text(179,171,'A',9,'blue',True)
    xp,zp=section(s,309,169,1.13,3)
    s.dimv(zp(-8),zp(35.4),397,xp(65),'43.4 overall at 3 mm wet gap')
    s.dimh(xp(-42.5),xp(42.5),zp(35.4)+11,zp(35.4),'85 cavity')
    s.text(309,145,'SECTION A-A / Y = 0 / 3 mm WET GAP SHOWN',9,'blue',True,'center')
    s.leader([(xp(0),zp(31.4)),(289,227),(256,227)],'P03 / steel backer 8')
    s.leader([(xp(15),zp(21.4)),(336,232),(350,232)],'P01 / PETG plate 12')
    s.leader([(xp(-60),zp(13.7)),(229,134),(229,128)],'P02 / spacer ring 3.4')
    s.leader([(xp(20),zp(13.7)),(333,128),(350,128)],'Pulp + 2 mesh faces')
    s.note(20,87,['CARD FOOTPRINT: 85 x 55, corner R3 (business-card format).','Nominal cavity area: 4667.3 mm² including corner radii.','8 bolt positions act through metal backers and spacer frame.'],9,5)
    s.note(220,87,['GAP RULE: wet pulp gap = measured spacer - measured mesh stack.','Rings: 1.4 / 2.4 / 3.4 / 4.4 / 5.4 (one ring at a time).','Assumed compressed mesh: 0.20 per face; measure your actual mesh.','Final dry thickness shrinks and must be measured after drying.'],9,5)
    s.text(20,52,'DESIGN STATUS: dimensional manufacturing concept; loading, print quality and flatness require validation.',8,'grey')
    s.finish()

    s=Sheet(pdf,420,297,2,'P01 / PETG DRAIN PLATES / 2 IDENTICAL PARTS','02_petg_plates.svg')
    face(s,111,171,1.1,labels=True); outerdims(s,111,171,1.1)
    s.text(111,100,'PULP FACE / FLAT / Ø2 DRAINS',9,'blue',True,'center')
    s.leader([(111-35*1.1,171+21*1.1),(70,230),(49,230)],'77 x Ø2 THRU')
    s.leader([(111+59*1.1,171+50*1.1),(193,238),(203,238)],'4 x outer R6',align='right')
    face(s,312,171,1.1,grooves=True); outerdims(s,312,171,1.1)
    s.text(312,100,'BACK FACE / GROOVES FACE STEEL',9,'blue',True,'center')
    s.leader([(312+46*1.1,171-30*1.1),(395,131),(403,131)],'Drain to edge',align='right')
    s.leader([(312,171+14*1.1),(322,232),(350,232)],'1.6 wide x 1.2 deep')
    s.note(221,91,['GROOVE MAP (centreline coordinates, mold XY):','6 horizontal runs: Y = ±7, ±14, ±21; X = -65 to +65.','Centre run: Y = 0; X = -46 to +46.','2 branches: X = ±46; Y = 0 to -50 (edge outlets).','Keep grooves on back face; upper plate is flipped in assembly.'],8,4.5)
    hole_table(s,20,88,170)
    s.note(221,59,['DRAIN ARRAY: X = -35..+35, Y = -21..+21; pitch 7 both ways.','11 columns x 7 rows = 77 holes per plate. No blind drains.','PLATE THICKNESS 12; floor above grooves 10.8 minimum.'],8,4.5)
    s.text(20,41,'Print pulp face on a flat surface; calibrate holes, remove burrs, check both faces flat. Nominal FDM XY tolerance ±0.3.',8,'grey')
    s.finish()

    s=Sheet(pdf,420,297,3,'P02 / INTERCHANGEABLE SPACERS + P04 / MESH','03_spacers_mesh.svg')
    face(s,109,177,1.1,'ring',labels=True,label_y=-6);outerdims(s,109,177,1.1)
    s.dimh(109-42.5*1.1,109+42.5*1.1,139,177-27.5*1.1,'85 opening')
    s.dimv(177-27.5*1.1,177+27.5*1.1,145,109+42.5*1.1,'55 opening')
    s.leader([(109+40*1.1,177+27.5*1.1),(172,229),(193,229)],'4 x inside R3',align='right')
    s.text(221,237,'RING THICKNESS SCHEDULE',11,'blue',True)
    cols=[221,278,339]
    for x,t in zip(cols,['PART / MARK','RING (mm)','WET GAP* (mm)']):s.text(x,226,t,8,'grey',True)
    for i in range(1,6):
        y=215-(i-1)*10
        s.text(cols[0],y,f'P02-{i} / G{i}',9)
        s.text(cols[1],y,f'{i+.4:.1f}',9)
        s.text(cols[2],y,f'{i}.0',9)
        s.line(221,y-3,396,y-3,'light',.15)
    s.note(221,163,['*Assumes two compressed mesh layers of 0.20 each.','Use only one continuous spacer ring per assembly.','Measure actual ring thickness at all 4 corners.','Required ring = desired wet gap + actual mesh thickness.','Do not assume wet gap equals final dry card thickness.'],9,5)
    s.text(221,128,'SPACER SECTION (edge strip)',9,'blue',True)
    s.rect(221,110,75,7,'ink',.35,'ring')
    s.dimv(110,117,309,296,'t = 1.4 to 5.4')
    s.note(221,95,['Horizontal flange widths: 22.5 left/right, 22.5 top/bottom.','8 x Ø6.6 THRU; same hole centres as P01 (sheet 02).','Outer profile 130 x 100 R6; cavity profile 85 x 55 R3.'],8,4.6)
    s.text(20,98,'P04 / MESH CUT PATTERN / 2 PIECES',10,'blue',True)
    s.roundrect(20,63,84.5,54.5,3,'mesh',.3)
    s.dimh(20,104.5,54,63,'84.5');s.dimv(63,117.5,113,104.5,'54.5')
    s.note(128,86,['Mesh corners R3, trim to fit freely inside opening.','Never place mesh over the ring stop faces.','100-200 µm clear aperture; buy by aperture and wire','diameter / fabric thickness, then measure compressed stack.','Stainless 304/316 or polyester monofilament.'],8,4.5)
    s.text(221,47,'FDM spacer thickness is critical: measure and lap flat as needed.',8,'grey')
    s.finish()

    s=Sheet(pdf,420,297,4,'P03 / STEEL BACKERS + FASTENER DETAILS','04_steel_hardware.svg')
    face(s,117,177,1.2,'steel',labels=True);outerdims(s,117,177,1.2)
    s.leader([(117+59*1.2,177+50*1.2),(198,247),(203,247)],'4 x R6',align='right')
    s.text(117,102,'PLAN / 2 IDENTICAL STEEL BACKERS',9,'blue',True,'center')
    s.rect(39,73,156,9.6,'ink',.4,'steel');s.dimv(73,82.6,208,195,'8')
    s.text(117,63,'EDGE VIEW / 130 x 100 x 8',9,'blue',True,'center')
    hole_table(s,237,236,154)
    s.note(237,185,['MATERIAL: mild steel plate, 8 thick, 2 pieces.','8 x Ø6.6 THRU; NO DRAIN HOLES OR BACKER GROOVES.','Flat faces; deburr holes and all edges.','Metal backers spread load over PETG plates.','Rounded R6 outline matches PETG parts.'],9,5)
    s.text(237,145,'P05-P07 / CLAMP HARDWARE',10,'blue',True)
    s.note(237,132,['8 x M6 x 60 hex bolts, property class 8.8 suggested.','16 x M6 large-series flat washers, OD18 (ISO 7093-1).','8 x M6 nuts; plain nuts are preferred for controlled assembly.','Optional wing nuts fit M6 but do not define clamping force.','Stack: 41.4 to 45.4 (gap 1 to 5), excluding washers.','With two nominal 1.6 washers: 44.6 to 48.6.','Confirm >2 complete threads visible beyond each nut.'],9,5)
    s.note(237,84,['8 backer is recommended for this concept.','Thin aluminum/acrylic backing is not an equivalent substitution.','Bolt torque alone cannot accurately determine pulp pressure.','Use a measured press force if available; consult build guide.'],8,4.8)
    s.text(20,44,'FABRICATION: a workshop can cut the profile and drill holes from the 1:1 DXF or the checked A4 template (sheet 06).',8,'grey')
    s.finish()

    s=Sheet(pdf,420,297,5,'EXPLODED ASSEMBLY / BILL OF MATERIALS','05_exploded_bom.svg')
    # Exploded side sections: displacement separates the physically distinct parts.
    cx=109;k=1.12
    layers=[(74,8,'steel','P03',130),(96,12,'petg','P01',130),(126,.5,'mesh','P04',84.5),(139,3.4,'ring','P02',130),(155,.5,'mesh','P04',84.5),(175,12,'petg','P01',130),(207,8,'steel','P03',130)]
    for i,(yy,th,mat,pid,ww) in enumerate(layers):
        if pid=='P02':
            for xx in [-65,42.5]:s.rect(cx+xx*k,yy,22.5*k,th*k,'ink',.3,mat)
        else:s.rect(cx-ww*k/2,yy,ww*k,th*k,'ink',.3,mat)
        s.label(202,yy+max(th*k/2,0.5),{'P01':1,'P02':2,'P03':3,'P04':4}[pid])
        s.line(cx+ww*k/2,yy+th*k/2,197,yy+th*k/2,'blue',.16)
    for bx in [-53,53]:s.line(cx+bx*k,61,cx+bx*k,241,'light',.2,[3,1,1,1])
    s.text(cx,245,'UPPER / NUT SIDE',9,'blue',True,'center')
    s.text(cx,61,'LOWER / BOLT-HEAD SIDE',9,'blue',True,'center')
    s.text(20,52,'Side section is exploded for assembly order; displacement is schematic.',8,'grey')
    s.text(233,238,'BILL OF MATERIALS',11,'blue',True)
    rows=[('1','P01','2','PETG drain plate 130 x 100 x 12'),('2','P02','5','PETG rings: 1.4, 2.4, 3.4, 4.4, 5.4'),('3','P03','2','Steel backer 130 x 100 x 8'),('4','P04','2','Filter mesh 84.5 x 54.5 R3'),('5','P05','8','M6 x 60 hex bolt'),('6','P06','16','M6 washer OD18, nominal t1.6'),('7','P07','8','M6 nut')]
    s.text(233,227,'ID    PART      QTY    DESCRIPTION',8,'grey',True)
    for i,(num,pid,qty,desc) in enumerate(rows):
        yy=216-i*12
        s.text(233,yy,f'{num}     {pid}       {qty}',9)
        s.text(287,yy,desc,8)
        s.line(233,yy-4,398,yy-4,'light',.15)
    s.note(233,116,['ASSEMBLY ORDER:','1. Lower steel / lower PETG (grooves down) / lower mesh.','2. One selected spacer around the mesh; evenly spread wet pulp.','3. Upper mesh / upper PETG (grooves up) / upper steel.','4. Bolts through all layers; washer under each head and nut.','5. Close evenly until stops contact; dewater through mesh + drains.'],8.5,5)
    s.note(233,76,['MATCHED PLATES: P01 upper and lower use the same print.','SPACER SET: print all 5 to compare thickness; only 1 installed.','PULP AND MESH: confined to cavity; no fibers on stop faces.','DRYING: final dry thickness and strength require experiment.'],8.5,5)
    s.finish()

    for num,kind,title,filename in [
        (6,'steel','P03 / 1:1 STEEL DRILLING TEMPLATE','06_backer_template_1to1.svg'),
        (7,'ring','P02 / 1:1 SPACER PROFILE TEMPLATE','07_ring_template_1to1.svg'),
        (8,'plate','P01 / 1:1 DRAIN FACE TEMPLATE','08_drain_template_1to1.svg')]:
        s=Sheet(pdf,210,297,num,title,filename,'TRUE SCALE 1:1 ON A4 / print Actual Size, 100%; disable Fit to Page')
        face(s,105,183,1,kind,labels=kind!='plate');outerdims(s,105,183,1,9)
        s.text(105,123,'ORIGIN (0,0) AT PROFILE CENTRE',8,'blue',True,'center')
        if kind=='steel':
            s.note(20,112,['2 x steel backers, thickness 8.','8 x Ø6.6 THRU at shared hole table, sheet 02.','Outer contour 130 x 100; 4 corners R6.','Drill / cut only after the scale bar measures exactly 50 mm.'],9,6)
        elif kind=='ring':
            s.note(20,112,['Outer contour 130 x 100 R6; opening 85 x 55 R3.','8 x Ø6.6 THRU at shared hole table, sheet 02.','Five thicknesses: 1.4 / 2.4 / 3.4 / 4.4 / 5.4.','This is a 2D fit template; fabricate using the 3D part files.'],9,6)
        else:
            s.note(20,112,['2 x PETG drain plates; thickness 12.','77 x Ø2 THRU, pitch 7; bolt holes 8 x Ø6.6 THRU.','Back channels are omitted here; see sheet 02.','This template represents the flat pulp face.'],9,6)
        s.line(30,64,80,64,'ink',.5);s.line(30,61,30,67,'ink',.5);s.line(80,61,80,67,'ink',.5)
        s.text(55,70,'CHECK: 50.00 mm',9,'blue',True,'center')
        s.text(20,45,'Check bar with a ruler before transferring any dimensions.',8,'grey')
        s.finish()
    pdf.save()

def add_round(d,m,w,h,r,layer,cx=0,cy=0):
    q=math.tan(math.pi/8)
    pts=[(-w/2+r,-h/2,0),(w/2-r,-h/2,q),(w/2,-h/2+r,0),(w/2,h/2-r,q),(w/2-r,h/2,0),(-w/2+r,h/2,q),(-w/2,h/2-r,0),(-w/2,-h/2+r,q)]
    m.add_lwpolyline([(x+cx,y+cy,b) for x,y,b in pts],format='xyb',close=True,dxfattribs={'layer':layer})

def new_dxf():
    d=ezdxf.new('R2010');d.units=ezdxf.units.MM
    for name,color in [('CUT_OUTER',7),('CUT_INNER',1),('DRILL_M6_6p6',3),('DRAIN_2p0',4),('CHANNEL_1p6_DEPTH_1p2',5),('CHANNEL_CENTRE',5),('REFERENCE',8),('ANNOTATION',7)]:
        d.layers.new(name,dxfattribs={'color':color})
    d.header['$MEASUREMENT']=1
    return d,d.modelspace()

def dxf_part(d,m,kind,cx=0,cy=0,channels=False):
    add_round(d,m,W,H,R,'CUT_OUTER',cx,cy)
    if kind=='ring':add_round(d,m,CW,CH,CR,'CUT_INNER',cx,cy)
    if kind=='mesh':
        # Replace outer profile with actual mesh outline; called separately below.
        return
    for x,y in HOLES:m.add_circle((x+cx,y+cy),3.3,dxfattribs={'layer':'DRILL_M6_6p6'})
    if kind=='plate':
        for x,y in DRAINS:m.add_circle((x+cx,y+cy),1,dxfattribs={'layer':'DRAIN_2p0'})
    if channels:
        for yy in [-21,-14,-7,7,14,21]:
            m.add_lwpolyline([(cx-65,cy+yy-.8),(cx+65,cy+yy-.8),(cx+65,cy+yy+.8),(cx-65,cy+yy+.8)],close=True,dxfattribs={'layer':'CHANNEL_1p6_DEPTH_1p2'})
        # Union outline of the central horizontal groove with both forward branches.
        pp=[(-46.8,-50),(-45.2,-50),(-45.2,-.8),(45.2,-.8),(45.2,-50),(46.8,-50),(46.8,.8),(-46.8,.8)]
        m.add_lwpolyline([(cx+x,cy+y) for x,y in pp],close=True,dxfattribs={'layer':'CHANNEL_1p6_DEPTH_1p2'})
        for path in GROOVES:m.add_lwpolyline([(cx+x,cy+y) for x,y in path],dxfattribs={'layer':'CHANNEL_CENTRE'})

def create_dxf():
    for kind,name,channels in [('plate','P01_PETG_plate_face_and_back_channels_1to1.dxf',True),('ring','P02_spacer_ring_profile_1to1.dxf',False),('steel','P03_steel_backer_8mm_1to1.dxf',False)]:
        d,m=new_dxf();dxf_part(d,m,kind,channels=channels);d.saveas(OUT/name)
    d,m=new_dxf();add_round(d,m,84.5,54.5,3,'CUT_OUTER');d.saveas(OUT/'P04_mesh_cut_pattern_1to1.dxf')
    d,m=new_dxf()
    for kind,cx,label,channels in [('plate',0,'P01 PETG plate t12; channels on back only',True),('ring',165,'P02 ring t1.4/2.4/3.4/4.4/5.4',False),('steel',330,'P03 steel backer t8',False)]:
        dxf_part(d,m,kind,cx,0,channels);m.add_text(label,dxfattribs={'height':3,'insert':(cx-65,-61),'layer':'ANNOTATION'})
    add_round(d,m,84.5,54.5,3,'CUT_OUTER',495,0)
    m.add_text('P04 mesh 84.5 x 54.5 R3; 2 pieces',dxfattribs={'height':3,'insert':(445,-61),'layer':'ANNOTATION'})
    d.saveas(OUT/'LAPS_manufacturing_profiles_1to1_mm.dxf')

def create_notes():
    manifest={'revision':'A','units':'mm','plate':{'quantity':2,'outer':[130,100,6],'thickness':12,'drain_diameter':2,'drain_count':77,'drain_pitch':7,'drain_positions':DRAINS,'bolt_hole_diameter':6.6,'bolt_positions':HOLES,'back_channels':{'width':1.6,'depth':1.2,'centrelines':GROOVES}},'spacers':{'quantity':5,'outer':[130,100,6],'opening':[85,55,3],'thicknesses':[1.4,2.4,3.4,4.4,5.4],'assumed_wet_gaps':[1,2,3,4,5]},'steel_backers':{'quantity':2,'thickness':8},'mesh':{'quantity':2,'outline':[84.5,54.5,3],'assumed_compressed_thickness_each':.2,'clear_aperture_microns':[100,200]},'assembly_3mm':{'lower_steel_z':[-8,0],'lower_plate_z':[0,12],'spacer_z':[12,15.4],'upper_plate_z':[15.4,27.4],'upper_steel_z':[27.4,35.4],'total_stack':43.4},'status':'Nominal concept; physical performance is not certified.'}
    (OUT/'dimensions_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (OUT/'README_DRAWINGS.txt').write_text('LAPS PULP-CARD PRESS / DRAWINGS / REV A\n\nAll DXF dimensions and units are millimetres, 1:1.\nPDF sheets 01-05 are schematic scale; dimensions govern.\nPDF sheets 06-08 are true 1:1 on A4, when printed at 100% Actual Size.\nCheck the 50 mm bar before transferring any template.\nSVG sheets retain physical mm dimensions and editable vector text/lines.\n\nP01 DXF includes separate layers for outer cut, bolt drilling, drain drilling,\nback channel boundaries, and back channel centrelines. Grooves are on the\nnon-pulp face only. Do not cut all layers through the plate.\nP02 DXF applies to all five spacer thicknesses. Only one ring is fitted.\nP03 steel thickness is 8 mm; no drain holes are drilled in steel.\nP04 mesh is a trimming pattern, not a machined part.\n\nSuggested dimensional controls:\n- Printed profile/XY: nominal +/-0.3 mm; calibrate actual printer.\n- Bolt holes: nominal 6.6; check all M6 bolts fit before assembly.\n- Ring thickness: measure at four corners; match within 0.10 mm if practical.\n- Stop and pulp faces: aim for <=0.15 mm flatness across cavity.\nThese are workshop targets, not certified manufacturing guarantees.\n\nCompressed mesh thickness 0.20 per face is a sizing assumption.\nActual wet gap = measured ring thickness minus measured mesh stack.\nFinal dry thickness is determined by the pulp recipe, compression, and drying.\n\nThe 3 mm example stack is 43.4 mm excluding washers and hardware.\nRev A supersedes preliminary 6 mm backers; final backers are 8 mm.\nSee the project engineering guide for force and experiment recommendations.\n')

if __name__=='__main__':
    create_pdf();create_dxf();create_notes()
    print('Created 8-page PDF, 8 SVG sheets, 5 DXF files and dimension manifest in',OUT)
