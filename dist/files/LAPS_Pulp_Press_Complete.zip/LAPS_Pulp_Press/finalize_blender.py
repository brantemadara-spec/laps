#!/usr/bin/env python3
"""Finalize the studio backdrop and render the corrected exploded view.

Run after create_blender.py:
blender -b blender/Pulp_Press.blend --python finalize_blender.py
Only studio geometry changes. The physical model and AR exports are unchanged.
"""
from pathlib import Path
import bpy
from mathutils import Vector

ROOT=Path(__file__).resolve().parent
for scene in bpy.data.scenes:
    for obj in scene.objects:
        if obj.name.startswith('Studio surface'):
            obj.scale.x*=10.0 / obj.dimensions.x
            obj.scale.y*=10.0 / obj.dimensions.y
    scene.render.resolution_percentage=100
    scene['render_pipeline']='Blender Cycles 64 samples; final PNG noise filtered with Open Image Denoise 2.5.1. No generative geometry or imagery.'

exploded=next(s for s in bpy.data.scenes if s.name.startswith('02 EXPLODED'))
bpy.context.window.scene=exploded
exploded.render.filepath=str(ROOT/'renders'/'02_exploded_45deg.png')
bpy.ops.render.render(write_still=True)
assembled=next(s for s in bpy.data.scenes if s.name.startswith('01 ASSEMBLED'))

# A bare-face top view makes the card opening and all 77 drains easy to inspect.
if not any(s.name.startswith('05 FORMING') for s in bpy.data.scenes):
    forming=bpy.data.scenes.new('05 FORMING / open card cavity')
    forming.world=assembled.world
    forming.unit_settings.system='METRIC'
    forming.unit_settings.scale_length=1
    forming.unit_settings.length_unit='MILLIMETERS'
    forming.render.engine='CYCLES'
    forming.cycles.samples=64
    forming.cycles.use_denoising=False
    forming.cycles.max_bounces=4
    forming.cycles.diffuse_bounces=2
    forming.cycles.glossy_bounces=2
    forming.render.resolution_x=1600
    forming.render.resolution_y=1200
    forming.render.resolution_percentage=100
    forming.render.image_settings.file_format='PNG'
    forming.view_settings.view_transform='AgX'
    forming.view_settings.exposure=-3
    forming['display_note']='Bare-face inspection: filters and pulp omitted to reveal the drainage grid.'
    for prefix,z in [('02 Lower PETG',0),('03 Spacer',.012)]:
        original=next(o for o in assembled.objects if o.name.startswith(prefix))
        obj=original.copy()
        forming.collection.objects.link(obj)
        obj.location=Vector((0,0,z))
    detail=next(s for s in bpy.data.scenes if s.name.startswith('04 DRAINAGE'))
    for original in detail.objects:
        if original.type=='LIGHT' or original.name.startswith('Studio surface'):
            forming.collection.objects.link(original.copy())
    data=bpy.data.cameras.new('Camera / open mold true top')
    data.type='ORTHO'
    data.ortho_scale=.17
    data.clip_start=.001
    data.clip_end=20
    cam=bpy.data.objects.new('Camera / open mold true top',data)
    forming.collection.objects.link(cam)
    cam.location=(0,0,.30)
    cam.rotation_euler=(0,0,0)
    forming.camera=cam
else:
    forming=next(s for s in bpy.data.scenes if s.name.startswith('05 FORMING'))
bpy.context.window.scene=forming
forming.render.filepath=str(ROOT/'renders'/'07_open_mold_top.png')
bpy.ops.render.render(write_still=True)

helptext=bpy.data.texts.get('READ ME / dimensions, layers and limits')
if helptext:
    body=helptext.as_string().replace(
        'Four scenes: assembled, exploded, spacer set and reverse drainage.',
        'Five scenes: assembled, exploded, spacer set, reverse drainage and open cavity.')
    helptext.clear()
    helptext.write(body+'\nOpen-cavity scene shows the bare face for drain inspection; filters and pulp are omitted.\n')
bpy.context.window.scene=assembled
assembled.camera=bpy.data.objects['Camera / assembled 45 degree perspective']
assembled.render.filepath=str(ROOT/'renders'/'01_assembled_45deg.png')
bpy.ops.object.select_all(action='DESELECT')
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA'
            area.spaces.active.shading.color_type='MATERIAL'
            area.spaces.active.overlay.show_extras=False
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'blender'/'Pulp_Press.blend'))
print('FINAL BLENDER SCENE AND EXPLODED RENDER COMPLETE')
