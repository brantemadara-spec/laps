#!/usr/bin/env python3
"""Package deliverables without execution dependencies or intermediate files."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent

def public_files():
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if 'vendor' in relative.parts or 'render_tools' in relative.parts or '__pycache__' in relative.parts:
            continue
        if path.suffix in ('.log', '.blend1', '.pyc'):
            continue
        if relative.parts[0] == 'validation' and path.suffix in ('.png', '.jpg', '.jpeg', '.txt'):
            continue
        if path.name.startswith(('test_box', 'eevee_', 'lighting_', 'drawing_review_', 'debug_', 'scratch_')):
            continue
        if path.name == 'manifest.json':
            continue
        yield path

def add(zipfile_obj, path):
    zipfile_obj.write(path, str(Path('LAPS_Pulp_Press') / path.relative_to(ROOT)))

required = [ROOT/'blender/Pulp_Press.blend', ROOT/'ar/Pulp_Press_assembled.usdz',
            ROOT/'ar/Pulp_Press_exploded.usdz', ROOT/'docs/LAPS_Print_and_Experiment_Guide.pdf',
            ROOT/'drawings/LAPS_Pulp_Press_Technical_Drawings_RevA.pdf']
required += [ROOT/'renders'/name for name in ['01_assembled_45deg.png','02_exploded_45deg.png',
             '03_assembled_side.png','04_assembled_top.png','05_five_spacers.png','06_drainage_back.png',
             '07_open_mold_top.png']]
for file in required:
    assert file.is_file() and file.stat().st_size > 0, f'Missing deliverable: {file}'

files=list(public_files())
manifest={'revision':'A','date':'2026-10-06','files':[]}
for path in files:
    manifest['files'].append({'file':str(path.relative_to(ROOT)), 'bytes':path.stat().st_size,
                              'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

with zipfile.ZipFile(OUT/'LAPS_Pulp_Press_Complete.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in files+[ROOT/'manifest.json']:
        add(archive,path)

print_files=list(sorted((ROOT/'cad').glob('*PRINT*.stl')))
assert len(print_files)==6, 'Expected one plate design plus five alternative rings'
with zipfile.ZipFile(OUT/'LAPS_Pulp_Press_Print_Files.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in print_files + [ROOT/'README.md',required[3],required[4]]:
        add(archive,path)

for name in ('LAPS_Pulp_Press_Complete.zip','LAPS_Pulp_Press_Print_Files.zip'):
    path=OUT/name
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
    print(f'{path}: {path.stat().st_size/1024**2:.2f} MiB')
