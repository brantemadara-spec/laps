# LAPS — pirkumu saraksts DEPO Berģiem

Pārbaudīts 2026. gada 6. oktobrī. Veikals: DEPO Berģi, Siguldas šoseja 6.

**Neviena DEPO Berģu cena vai atlikums nav tieši apstiprināts.** DEPO katalogs šajā pārbaudē nebija nolasāms. DEPO summas zemāk ir cenu salīdzinātāja norādes; tās nav veikala tāme. Tas nepierāda, ka DEPO nav attiecīgo preču. Citu veikalu piedāvājumi ir alternatīvas, ja DEPO nevar sagādāt vajadzīgo.

## 1. Esošā modeļa iepirkums

| Prece | Vajag | Precīzs izmērs | Veikals / cenas statuss | Iepakojuma norāde |
|---|---:|---|---|---|
| Pilnas vītnes sešstūra bultskrūves | 8 | M6 × 60 mm; solis 1,0 mm; DIN 933 / ISO 4017; vēlama klase 8.8 | Vispirms DEPO Berģi; alternatīva Delve 2. DEPO cena nav apstiprināta. Alternatīva: Delve 2 10.9 melnas, kods 93310M-6X60; 1,12 € bez PVN, aprēķināti 1,36 € ar 21% PVN. Atlikums un piegāde nav apstiprināti. | 10 gab./iep.; 1,36 €; pirkt 1 iep. |
| Sešstūra uzgriežņi | 8 | M6 × 1,0; DIN 934; atslēga 10 mm; metāla, atbilstoša stiprības klase | DEPO Berģi — cenu salīdzinātāja kandidāts. Sekundāra DEPO cenas norāde 2,11 € par 100 gab., klase 12.0; Berģu cena un atlikums nav apstiprināti. | 100 gab./iep.; 2,11 €; pirkt 1 iep. |
| Platās metāla paplāksnes | 16 | M6 DIN 9021; Ø6,4 × Ø18 × 1,6 mm; bez gumijas | DEPO Berģi — cenu salīdzinātāja kandidāts. Sekundāra DEPO cenas norāde 2,62 € par 40 nerūsējošām paplāksnēm; izmēri jāapstiprina uz iepakojuma. Berģu cena un atlikums nav apstiprināti. | 40 gab./iep.; 2,62 €; pirkt 1 iep. |
| Tērauda atbalsta plāksnes | 2 | S235/S235JR; 130 × 100 × 8 mm; R6; 8 × Ø6,6 caurumi katrā; plakanas, bez atskabargām | DEPO cena nav apstiprināta; alternatīva Metāla Alianse. Gatavās plāksnes: cena pēc tāmes. 90 €/m² ir tikai publiskā 8 mm izejmateriāla cena ar neskaidru PVN režīmu, nevis šo detaļu izgatavošanas cena. | 2 gab./iep.; Tāme / nav apstiprināts; pirkt 1 iep. |
| Smalks šķiedru noturēšanas siets | 2 | 2 × 84,5 × 54,5 mm, R3; 304/1.4301; acs 0,15 mm, stieple 0,10 mm; apm. 100 mesh | DEPO cena nav apstiprināta; alternatīva EuroSitex Latvija. Cena pēc tāmes. Viena 200 × 150 mm sagatave dod četrus gabalus, divi ir rezerves. EuroSitex publiski norāda pirkuma garumu no 1 m; maza atgriezuma pārdošana un precīzās markas atlikums jānoskaidro. | 1 gab./iep.; Tāme / nav apstiprināts; pirkt 1 iep. |
| PETG drukas pavediens | 1 | Ø1,75 mm; 1 kg spole; parasts PETG bez CF | DEPO cena nav apstiprināta; alternatīva Filaments.lv. Primāra veikala cena ar PVN; eSUN PETG Basic BLACK, publicēti 25 gab. Saņemšana Kalnciema 148 bez maksas; pakomāts 2,90 €. Printera profils pēc eSUN datiem. | 1 gab./iep.; 14,90 €; pirkt 1 iep. |

**Salīdzinājuma daļsumma 20,99 €:** Delve 2 10.9 skrūvju 10 gab. iepakojums (1,36 € ar aprēķinātu PVN) + DEPO cenu salīdzinātāja uzgriežņi (2,11 €) + paplāksnes (2,62 €) + Filaments.lv PETG (14,90 €). **Šī nav apstiprināta gala cena.** Tai vēl jāpieskaita gatavo tērauda plākšņu un sieta tāme, izvēlētā piegāde un rīki, ja tie jāpērk. Oriģinālās DEPO 8.8 skrūves aizstāj Delve alternatīvu, nevis pērk abus variantus.

Melno 10.9 skrūvju izmērs der esošajiem caurumiem; pēc mitras lietošanas nosusināt. Augstāka skrūvju klase nepalielina PETG preses pieļaujamo slodzi. Delve 2 gala iepakojuma cenu un pieejamību apstiprina pirms iegādes. Vēlamas ir cinkotas 8.8 pilnas vītnes skrūves, ja tās pieejamas DEPO.

## 2. Izvēles stiprinājumi ar vītņstieni

Izvēlas šo variantu tikai **oriģinālo 8 skrūvju un 8 uzgriežņu vietā**. Paplāksņu daudzums paliek 16. Esošie Ø6,6 mm caurumi un starplikas der; Blender renderos joprojām attēlotas oriģinālās 60 mm bultskrūves.

| Prece | Vajag | Izmērs | Iepakojums | Sekundārā DEPO cenas norāde |
|---|---:|---|---:|---:|
| Nerūsējošs vītņstienis | 1 | M6 × 1,0; A2; 1000 mm; sagriezt 8 × 70 mm | 1 | 1,70 € |
| Nerūsējoši uzgriežņi | 24 | M6 × 1,0; DIN 934; A2; 3 uz vienu stieni | 40 | 2,37 € |
| Platās nerūsējošās paplāksnes | 16 | M6 DIN 9021; Ø6,4 × Ø18 × 1,6 mm | 40 | 2,62 € |

**Stiprinājumu atsauces daļsumma 6,69 €; ar PETG 21,59 €.** Vītņstieņa 1,70 € ieraksts ir agrāk indeksēts; neviena no trim cenām vai Berģu atlikumiem nav tieši pārbaudīta. Gatavās plāksnes, siets, piegāde un instrumenti nav iekļauti.

Vienam stienim: divi savstarpēji noslēgti uzgriežņi apakšā, viena paplāksne pret apakšējo tērauda plāksni; otra paplāksne un viens uzgrieznis virs augšējās tērauda plāksnes. Apakšējos uzgriežņus savstarpēji nofiksē pirms celulozes ievietošanas. Grieztos galus novīlē; pirms masas pildīšanas pārbauda brīvu uzgriežņu kustību.

Maksimālais nominālais plākšņu un starplikas biezums ir 45,4 mm. Ar divām 1,6 mm paplāksnēm un trim apmēram 5–5,2 mm uzgriežņiem kopā ir apmēram 63,6–64,2 mm. 70 mm stienis dod rezervi vītnes izvirzījumam abos galos; faktiskos biezumus pārbauda saliekot. Aizver ar roku pakāpeniski pa diagonāli. Šis ir spraugas aizvēršanas variants, nevis izmērīta presēšanas spēka instruments.

## 3. Tērauda plāksnes un siets — izgatavošanas prasības

Tērauds: 2 identiskas, vienlaidus S235/S235JR detaļas 130 × 100 × 8 mm, ārējie stūri R6, 8 caurumi Ø6,6 mm katrā. Tās nav vītņotas atveres. Abas saskares virsmas gludas, plakanas un bez atskabargām; īpaši svarīgi 1 mm paraugiem. Urbumu centru koordinātas no detaļas centra (mm): (−53,−38), (0,−38), (53,−38), (−53,0), (53,0), (−53,38), (0,38), (53,38).

Metāla Alianse publiski norāda S235 8 mm loksni par 90 €/m² un pieejamu noliktavā, bet izvilkumā nav skaidrs PVN režīms. Divu sagatavju laukuma aritmētiskā vērtība 0,026 × 90 = 2,34 € **nav gatavo detaļu cena**. Nepieciešama tāme ar materiālu, griešanu, 16 pabeigtiem urbumiem, malu apstrādi, plakanuma prasību, darba minimumu, PVN un piegādi. Nav jāpērk pilna 1500 × 6000 mm loksne, ja piegādātājs piedāvā atgriezumu vai izgatavošanu no sava materiāla.

Siets: vēlams 304/1.4301, acs 0,15 mm (150 µm), stieple 0,10 mm, apmēram 100 mesh. Pasūtījuma sagatave 200 × 150 mm dod četrus 84,5 × 54,5 mm gabalus; nepieciešami divi, divi rezerves. Stūrus lokāli nogriež R3. 150 × 100 mm ir pietiekama minimālā sagatave diviem gabaliem.

EuroSitex Latvija ir vietējs tehniskā sieta tāmes avots; publiska minimālā pirkuma garuma norāde ir 1 m. Vispirms vajadzīga precīzās acs/stieples kombinācijas un maza atgriezuma vai parauga pieejamības atbilde. EU alternatīva getwiremesh: 34 €/m² + 6 € par griezumu, tātad 200 × 150 mm = 7,02 € pirms PVN un piegādes pēc publicētās formulas; konkrētā izmēra pieņemšana, atlikums un piegādes summa Latvijai nav apstiprināti. Tā nav gala cena.

Parasts moskītu siets neder kā automātisks aizvietotājs. Izmēra sieta saspiesto biezumu: esošie gredzeni paredz 0,20 mm katram no diviem sietiem. Ja tas atšķiras, pārkalibrē faktiskās celulozes spraugas.

Izgatavotājam paredzēti faili: `../drawings/P03_steel_backer_8mm_1to1.dxf`, `../cad/steel_backer_MAKE_2.step`, tehniskā rasējuma PDF un `Tames_pieprasijumi_LV.txt`. Tie apvienoti atsevišķajā pirkumu arhīvā.

## 4. Drukāt, aizņemties un izmantot esošo

Drukāt 2 PETG plāksnes un pa 1 no pieciem gredzeniem; gredzenu fiziskie augstumi 1,4 / 2,4 / 3,4 / 4,4 / 5,4 mm. Tie ir alternatīvi 1–5 mm **mitrās** celulozes spraugām. Visu izdruku CAD materiāla masa apmēram 549 g; vajadzīga viena 1 kg spole ar rezervi. 0,5 kg spole visam komplektam nepietiek. eSUN materiālam izmanto tā ražotāja drukas parametrus.

| Rīks — pirkt tikai, ja nevar aizņemties | Daudzums | Pārbaudīta alternatīvas cena bez piegādes |
|---|---:|---:|
| Kombinētās atslēgas, 10 mm | 2 | 2,44 € |
| Metāla bīdmērs, 0–150 mm | 1 | 5,00 € |
| Svari receptēm un sausajai masai, Vismaz 200 g; rādījuma solis 0,01 g | 1 | 6,60 € |

Rīku summa 14,04 € pirms piegādes; nav automātiski iekļauta detaļu daļsummā. Svaru 0,01 g rādījuma solis un bīdmēra dalījums negarantē kalibrētu precizitāti. Receptes svari nav presēšanas spēka mērītājs.

No mājām/skolas: ūdens paplāte ar iekšpusi vismaz 200 × 150 mm, tīrs trauks, masas maisītājs/blenderis, šķēres piemērotas sietam, tīrs absorbējošs papīrs žāvēšanai. Vītņstieņa variantam papildus metāla zāģis un vīle. Ja drukas caurumi jāattīra, vajag Ø2 mm un Ø6,6 mm atbilstošus urbjus; tērauda detaļas pasūta gatavas. Atsevišķu jaunu presi nav jāiegādājas formas aizvēršanai; spēka eksperimentos izmanto skolas izmērīta spēka presi.

Papīrs un sausas lapas ir pārstrādājams materiāls. Līme, epoksīds, PTFE aerosols, plastmasas skrūves un pieci atsevišķi formu komplekti nav šī sākuma iepirkuma daļa.

## Avoti

- [DEPO veikalu saraksts — Berģi, Siguldas šoseja 6](https://depo.lv/)
- [DEPO uzgriežņu ieraksts cenu salīdzinātājā](https://www.salidzini.lv/click.php?itemid=95754468776&q=uzgrieznis+din+934m-6)
- [DEPO paplāksņu ieraksts cenu salīdzinātājā](https://www.salidzini.lv/click.php?itemid=95755187871&q=papl%C4%81ksnes+din9021+m6)
- [Delve 2 — DIN 933 pilnas vītnes skrūves, melnas](https://www.delve2.lv/lv/products/screws-with-metric-thread/hexagon-head-bolts-full-thread-black-din-933m/)
- [Delve 2 — cenu un PVN noteikumi](https://www.delve2.lv/lv/info/terms-conditions/)
- [Filaments.lv — eSUN PETG Basic melns, 1 kg](https://filaments.lv/produkti/esun-petg-basic-melns-filaments-black/)
- [Metāla Alianse — S235 loksne 8 mm, HRS00076](https://www.metali.lv/lv/produkti/loksne-karsti-velmeta/8mm-1500x6000)
- [Metāla Alianse — detaļu griešana un urbšana](https://www.metali.lv/lv/pakalpojumi)
- [EuroSitex Latvija — nerūsējošais tehniskais siets](https://eurositex.lv/lv/Produkcija/stieples-siets--tehniskais-audums-%28stieple-lidz-1_4-mm%29/16/nerusejosie-stieplu-sieti/78/)
- [getwiremesh — 0,15 mm acs / 0,10 mm stieple](https://getwiremesh.com/shop/wiremesh-v2a-1501/)
- [REVA — 10 mm kombinētā atslēga](https://www.reva.lv/sa-6314324-kombineta-atslega-10-mm-cr-v-satin-%28indija%29/1840/1/p)
- [REVA — 150 mm metāla bīdmērs](https://www.reva.lv/ek-3015-bidmers-150mm-002mm/1061/1/p)
- [Motivs — 200 g / 0,01 g svari, 132772](https://motivs.lv/kabatas-un-juvelierizstradajumu-svari/elektroniskie-juvelierizstradajumu-svari-200g-0-01g-sudraba)
- [DEPO M6 A2 vītņstieņa cenu salīdzinātāja ieraksti](https://www.salidzini.lv/click.php?itemid=95609168596&q=v%C4%ABt%C5%86stienis+1m+ner%C5%ABs%C4%93jo%C5%A1%C4%81)
- [DEPO nerūsējošo M6 uzgriežņu 40 gab. ieraksti](https://www.salidzini.lv/click.php?itemid=95753564220&q=uzgrieznis+din+934%2C+ner%C5%ABs%C4%93jo%C5%A1%C4%81+t%C4%93rauda)

Detalizētie avotu novērojumi: `fasteners_research.md`, `filament_tools_research.md`, `metal_mesh_research.md`. Veikalu lapu atlikumi attiecas uz publikācijas brīdi, nevis uz rezervētu pasūtījumu.
