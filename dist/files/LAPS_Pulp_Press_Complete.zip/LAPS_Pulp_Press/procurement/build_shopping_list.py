"""Build the Latvian procurement note, price workbook and supplier brief."""
from pathlib import Path
from decimal import Decimal
import csv
import json
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.worksheet.datavalidation import DataValidation

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
DATE = '2026-10-06'
SOURCES = {
 'depo': ('DEPO veikalu saraksts — Berģi, Siguldas šoseja 6', 'https://depo.lv/'),
 'nuts': ('DEPO uzgriežņu ieraksts cenu salīdzinātājā', 'https://www.salidzini.lv/click.php?itemid=95754468776&q=uzgrieznis+din+934m-6'),
 'washers': ('DEPO paplāksņu ieraksts cenu salīdzinātājā', 'https://www.salidzini.lv/click.php?itemid=95755187871&q=papl%C4%81ksnes+din9021+m6'),
 'bolt': ('Delve 2 — DIN 933 pilnas vītnes skrūves, melnas', 'https://www.delve2.lv/lv/products/screws-with-metric-thread/hexagon-head-bolts-full-thread-black-din-933m/'),
 'bolt_terms': ('Delve 2 — cenu un PVN noteikumi', 'https://www.delve2.lv/lv/info/terms-conditions/'),
 'filament': ('Filaments.lv — eSUN PETG Basic melns, 1 kg', 'https://filaments.lv/produkti/esun-petg-basic-melns-filaments-black/'),
 'steel': ('Metāla Alianse — S235 loksne 8 mm, HRS00076', 'https://www.metali.lv/lv/produkti/loksne-karsti-velmeta/8mm-1500x6000'),
 'machining': ('Metāla Alianse — detaļu griešana un urbšana', 'https://www.metali.lv/lv/pakalpojumi'),
 'mesh': ('EuroSitex Latvija — nerūsējošais tehniskais siets', 'https://eurositex.lv/lv/Produkcija/stieples-siets--tehniskais-audums-%28stieple-lidz-1_4-mm%29/16/nerusejosie-stieplu-sieti/78/'),
 'mesh_eu': ('getwiremesh — 0,15 mm acs / 0,10 mm stieple', 'https://getwiremesh.com/shop/wiremesh-v2a-1501/'),
 'wrench': ('REVA — 10 mm kombinētā atslēga', 'https://www.reva.lv/sa-6314324-kombineta-atslega-10-mm-cr-v-satin-%28indija%29/1840/1/p'),
 'caliper': ('REVA — 150 mm metāla bīdmērs', 'https://www.reva.lv/ek-3015-bidmers-150mm-002mm/1061/1/p'),
 'scale': ('Motivs — 200 g / 0,01 g svari, 132772', 'https://motivs.lv/kabatas-un-juvelierizstradajumu-svari/elektroniskie-juvelierizstradajumu-svari-200g-0-01g-sudraba'),
}

fasteners = json.loads((OUT/'fasteners_research.json').read_text())
rod = fasteners.get('optional_threaded_rod_route', {})
# These descriptive links support the secondary observations, not a branch price.
SOURCES['rod'] = ('DEPO M6 A2 vītņstieņa cenu salīdzinātāja ieraksti', 'https://www.salidzini.lv/click.php?itemid=95609168596&q=v%C4%ABt%C5%86stienis+1m+ner%C5%ABs%C4%93jo%C5%A1%C4%81')
SOURCES['rod_nuts'] = ('DEPO nerūsējošo M6 uzgriežņu 40 gab. ieraksti', 'https://www.salidzini.lv/click.php?itemid=95753564220&q=uzgrieznis+din+934%2C+ner%C5%ABs%C4%93jo%C5%A1%C4%81+t%C4%93rauda')

rows = [
 dict(id='B01',part='Pilnas vītnes sešstūra bultskrūves',qty=8,spec='M6 × 60 mm; solis 1,0 mm; DIN 933 / ISO 4017; vēlama klase 8.8',shop='Vispirms DEPO Berģi; alternatīva Delve 2',pack=10,packs=1,reference=1.36,status='DEPO cena nav apstiprināta. Alternatīva: Delve 2 10.9 melnas, kods 93310M-6X60; 1,12 € bez PVN, aprēķināti 1,36 € ar 21% PVN. Atlikums un piegāde nav apstiprināti.',source='bolt'),
 dict(id='B02',part='Sešstūra uzgriežņi',qty=8,spec='M6 × 1,0; DIN 934; atslēga 10 mm; metāla, atbilstoša stiprības klase',shop='DEPO Berģi — cenu salīdzinātāja kandidāts',pack=100,packs=1,reference=2.11,status='Sekundāra DEPO cenas norāde 2,11 € par 100 gab., klase 12.0; Berģu cena un atlikums nav apstiprināti.',source='nuts'),
 dict(id='B03',part='Platās metāla paplāksnes',qty=16,spec='M6 DIN 9021; Ø6,4 × Ø18 × 1,6 mm; bez gumijas',shop='DEPO Berģi — cenu salīdzinātāja kandidāts',pack=40,packs=1,reference=2.62,status='Sekundāra DEPO cenas norāde 2,62 € par 40 nerūsējošām paplāksnēm; izmēri jāapstiprina uz iepakojuma. Berģu cena un atlikums nav apstiprināti.',source='washers'),
 dict(id='B04',part='Tērauda atbalsta plāksnes',qty=2,spec='S235/S235JR; 130 × 100 × 8 mm; R6; 8 × Ø6,6 caurumi katrā; plakanas, bez atskabargām',shop='DEPO cena nav apstiprināta; alternatīva Metāla Alianse',pack=2,packs=1,reference=None,status='Gatavās plāksnes: cena pēc tāmes. 90 €/m² ir tikai publiskā 8 mm izejmateriāla cena ar neskaidru PVN režīmu, nevis šo detaļu izgatavošanas cena.',source='steel'),
 dict(id='B05',part='Smalks šķiedru noturēšanas siets',qty=2,spec='2 × 84,5 × 54,5 mm, R3; 304/1.4301; acs 0,15 mm, stieple 0,10 mm; apm. 100 mesh',shop='DEPO cena nav apstiprināta; alternatīva EuroSitex Latvija',pack=1,packs=1,reference=None,status='Cena pēc tāmes. Viena 200 × 150 mm sagatave dod četrus gabalus, divi ir rezerves. EuroSitex publiski norāda pirkuma garumu no 1 m; maza atgriezuma pārdošana un precīzās markas atlikums jānoskaidro.',source='mesh'),
 dict(id='B06',part='PETG drukas pavediens',qty=1,spec='Ø1,75 mm; 1 kg spole; parasts PETG bez CF',shop='DEPO cena nav apstiprināta; alternatīva Filaments.lv',pack=1,packs=1,reference=14.90,status='Primāra veikala cena ar PVN; eSUN PETG Basic BLACK, publicēti 25 gab. Saņemšana Kalnciema 148 bez maksas; pakomāts 2,90 €. Printera profils pēc eSUN datiem.',source='filament'),
]
rod_rows = [
 dict(id='R01',part='Nerūsējošs vītņstienis',qty=1,spec='M6 × 1,0; A2; 1000 mm; sagriezt 8 × 70 mm',shop='DEPO Berģi — cenu salīdzinātāja kandidāts',pack=1,packs=1,reference=1.70,status='Sekundārs agrāk indeksēts DEPO piedāvājums; cena 1,70 € nav apstiprināta kā aktuāla. Berģu cena un atlikums nav apstiprināti.',source='rod'),
 dict(id='R02',part='Nerūsējoši uzgriežņi',qty=24,spec='M6 × 1,0; DIN 934; A2; 3 uz vienu stieni',shop='DEPO Berģi — cenu salīdzinātāja kandidāts',pack=40,packs=1,reference=2.37,status='Sekundāra DEPO cenas norāde 2,37 € par 40 gab.; Berģu cena un atlikums nav apstiprināti.',source='rod_nuts'),
 dict(id='R03',part='Platās nerūsējošās paplāksnes',qty=16,spec='M6 DIN 9021; Ø6,4 × Ø18 × 1,6 mm',shop='DEPO Berģi — cenu salīdzinātāja kandidāts',pack=40,packs=1,reference=2.62,status='Sekundāra DEPO cenas norāde 2,62 € par 40 gab.; Berģu cena un atlikums nav apstiprināti.',source='washers'),
]
tools = [
 dict(id='T01',part='Kombinētās atslēgas',qty=2,spec='10 mm',shop='DEPO cena nav apstiprināta; alternatīva REVA',pack=1,packs=2,reference=1.22,status='REVA 1,22 €/gab. ar PVN, publicēts pieejams; piegāde nav apstiprināta. Var aizņemties.',source='wrench'),
 dict(id='T02',part='Metāla bīdmērs',qty=1,spec='0–150 mm',shop='DEPO cena nav apstiprināta; alternatīva REVA',pack=1,packs=1,reference=5.00,status='REVA 5,00 € ar PVN, publicēts pieejams; piegāde nav apstiprināta. Rādījuma solis nav precizitātes garantija. Var aizņemties.',source='caliper'),
 dict(id='T03',part='Svari receptēm un sausajai masai',qty=1,spec='Vismaz 200 g; rādījuma solis 0,01 g',shop='DEPO cena nav apstiprināta; alternatīva Motivs',pack=1,packs=1,reference=6.60,status='Motivs 6,60 €, publicēts 10+; saņemšana Duntes 56 bez maksas, pakomāts no 1,90 €. Var aizņemties.',source='scale'),
]
basic_sum=sum(Decimal(str(x['reference']))*x['packs'] for x in rows if x['reference'] is not None)
rod_sum=sum(Decimal(str(x['reference']))*x['packs'] for x in rod_rows)
tool_sum=sum(Decimal(str(x['reference']))*x['packs'] for x in tools)
assert basic_sum==Decimal('20.99') and rod_sum==Decimal('6.69') and tool_sum==Decimal('14.04')

dataset={'date':DATE,'preferred_store':'DEPO Berģi, Siguldas šoseja 6','branch_prices_verified':False,'branch_stock_verified':False,'main':rows,'optional_rod_replaces_B01_B02_B03':rod_rows,'optional_tools':tools,'sources':SOURCES,'comparison_subtotals_eur':{'main_known_reference_only':str(basic_sum),'rod_hardware_secondary_with_stale_rod':str(rod_sum),'rod_hardware_and_filament_reference_only':str(rod_sum+Decimal('14.90')),'optional_tools_excluding_delivery':str(tool_sum)},'complete_project_total_eur':None,'total_missing':['finished steel backer quote','size-specific available mesh and shipping quote','unverified DEPO branch prices','chosen delivery and tools']}
(OUT/'shopping_data.json').write_text(json.dumps(dataset,ensure_ascii=False,indent=2)+'\n')

def money(x):
    return 'Tāme / nav apstiprināts' if x is None else f'{x:.2f} €'.replace('.',',')

md=['# LAPS — pirkumu saraksts DEPO Berģiem', '', 'Pārbaudīts 2026. gada 6. oktobrī. Veikals: DEPO Berģi, Siguldas šoseja 6.', '', '**Neviena DEPO Berģu cena vai atlikums nav tieši apstiprināts.** DEPO katalogs šajā pārbaudē nebija nolasāms. DEPO summas zemāk ir cenu salīdzinātāja norādes; tās nav veikala tāme. Tas nepierāda, ka DEPO nav attiecīgo preču. Citu veikalu piedāvājumi ir alternatīvas, ja DEPO nevar sagādāt vajadzīgo.','', '## 1. Esošā modeļa iepirkums','', '| Prece | Vajag | Precīzs izmērs | Veikals / cenas statuss | Iepakojuma norāde |','|---|---:|---|---|---|']
for x in rows:
    md.append(f"| {x['part']} | {x['qty']} | {x['spec']} | {x['shop']}. {x['status']} | {x['pack']} gab./iep.; {money(x['reference'])}; pirkt {x['packs']} iep. |")
md += ['', '**Salīdzinājuma daļsumma 20,99 €:** Delve 2 10.9 skrūvju 10 gab. iepakojums (1,36 € ar aprēķinātu PVN) + DEPO cenu salīdzinātāja uzgriežņi (2,11 €) + paplāksnes (2,62 €) + Filaments.lv PETG (14,90 €). **Šī nav apstiprināta gala cena.** Tai vēl jāpieskaita gatavo tērauda plākšņu un sieta tāme, izvēlētā piegāde un rīki, ja tie jāpērk. Oriģinālās DEPO 8.8 skrūves aizstāj Delve alternatīvu, nevis pērk abus variantus.', '', 'Melno 10.9 skrūvju izmērs der esošajiem caurumiem; pēc mitras lietošanas nosusināt. Augstāka skrūvju klase nepalielina PETG preses pieļaujamo slodzi. Delve 2 gala iepakojuma cenu un pieejamību apstiprina pirms iegādes. Vēlamas ir cinkotas 8.8 pilnas vītnes skrūves, ja tās pieejamas DEPO.', '', '## 2. Izvēles stiprinājumi ar vītņstieni', '', 'Izvēlas šo variantu tikai **oriģinālo 8 skrūvju un 8 uzgriežņu vietā**. Paplāksņu daudzums paliek 16. Esošie Ø6,6 mm caurumi un starplikas der; Blender renderos joprojām attēlotas oriģinālās 60 mm bultskrūves.', '', '| Prece | Vajag | Izmērs | Iepakojums | Sekundārā DEPO cenas norāde |','|---|---:|---|---:|---:|']
for x in rod_rows: md.append(f"| {x['part']} | {x['qty']} | {x['spec']} | {x['pack']} | {money(x['reference'])} |")
md += ['', '**Stiprinājumu atsauces daļsumma 6,69 €; ar PETG 21,59 €.** Vītņstieņa 1,70 € ieraksts ir agrāk indeksēts; neviena no trim cenām vai Berģu atlikumiem nav tieši pārbaudīta. Gatavās plāksnes, siets, piegāde un instrumenti nav iekļauti.', '', 'Vienam stienim: divi savstarpēji noslēgti uzgriežņi apakšā, viena paplāksne pret apakšējo tērauda plāksni; otra paplāksne un viens uzgrieznis virs augšējās tērauda plāksnes. Apakšējos uzgriežņus savstarpēji nofiksē pirms celulozes ievietošanas. Grieztos galus novīlē; pirms masas pildīšanas pārbauda brīvu uzgriežņu kustību.', '', 'Maksimālais nominālais plākšņu un starplikas biezums ir 45,4 mm. Ar divām 1,6 mm paplāksnēm un trim apmēram 5–5,2 mm uzgriežņiem kopā ir apmēram 63,6–64,2 mm. 70 mm stienis dod rezervi vītnes izvirzījumam abos galos; faktiskos biezumus pārbauda saliekot. Aizver ar roku pakāpeniski pa diagonāli. Šis ir spraugas aizvēršanas variants, nevis izmērīta presēšanas spēka instruments.', '', '## 3. Tērauda plāksnes un siets — izgatavošanas prasības', '', 'Tērauds: 2 identiskas, vienlaidus S235/S235JR detaļas 130 × 100 × 8 mm, ārējie stūri R6, 8 caurumi Ø6,6 mm katrā. Tās nav vītņotas atveres. Abas saskares virsmas gludas, plakanas un bez atskabargām; īpaši svarīgi 1 mm paraugiem. Urbumu centru koordinātas no detaļas centra (mm): (−53,−38), (0,−38), (53,−38), (−53,0), (53,0), (−53,38), (0,38), (53,38).', '', 'Metāla Alianse publiski norāda S235 8 mm loksni par 90 €/m² un pieejamu noliktavā, bet izvilkumā nav skaidrs PVN režīms. Divu sagatavju laukuma aritmētiskā vērtība 0,026 × 90 = 2,34 € **nav gatavo detaļu cena**. Nepieciešama tāme ar materiālu, griešanu, 16 pabeigtiem urbumiem, malu apstrādi, plakanuma prasību, darba minimumu, PVN un piegādi. Nav jāpērk pilna 1500 × 6000 mm loksne, ja piegādātājs piedāvā atgriezumu vai izgatavošanu no sava materiāla.', '', 'Siets: vēlams 304/1.4301, acs 0,15 mm (150 µm), stieple 0,10 mm, apmēram 100 mesh. Pasūtījuma sagatave 200 × 150 mm dod četrus 84,5 × 54,5 mm gabalus; nepieciešami divi, divi rezerves. Stūrus lokāli nogriež R3. 150 × 100 mm ir pietiekama minimālā sagatave diviem gabaliem.', '', 'EuroSitex Latvija ir vietējs tehniskā sieta tāmes avots; publiska minimālā pirkuma garuma norāde ir 1 m. Vispirms vajadzīga precīzās acs/stieples kombinācijas un maza atgriezuma vai parauga pieejamības atbilde. EU alternatīva getwiremesh: 34 €/m² + 6 € par griezumu, tātad 200 × 150 mm = 7,02 € pirms PVN un piegādes pēc publicētās formulas; konkrētā izmēra pieņemšana, atlikums un piegādes summa Latvijai nav apstiprināti. Tā nav gala cena.', '', 'Parasts moskītu siets neder kā automātisks aizvietotājs. Izmēra sieta saspiesto biezumu: esošie gredzeni paredz 0,20 mm katram no diviem sietiem. Ja tas atšķiras, pārkalibrē faktiskās celulozes spraugas.', '', 'Izgatavotājam paredzēti faili: `../drawings/P03_steel_backer_8mm_1to1.dxf`, `../cad/steel_backer_MAKE_2.step`, tehniskā rasējuma PDF un `Tames_pieprasijumi_LV.txt`. Tie apvienoti atsevišķajā pirkumu arhīvā.', '', '## 4. Drukāt, aizņemties un izmantot esošo', '', 'Drukāt 2 PETG plāksnes un pa 1 no pieciem gredzeniem; gredzenu fiziskie augstumi 1,4 / 2,4 / 3,4 / 4,4 / 5,4 mm. Tie ir alternatīvi 1–5 mm **mitrās** celulozes spraugām. Visu izdruku CAD materiāla masa apmēram 549 g; vajadzīga viena 1 kg spole ar rezervi. 0,5 kg spole visam komplektam nepietiek. eSUN materiālam izmanto tā ražotāja drukas parametrus.', '', '| Rīks — pirkt tikai, ja nevar aizņemties | Daudzums | Pārbaudīta alternatīvas cena bez piegādes |','|---|---:|---:|']
for x in tools: md.append(f"| {x['part']}, {x['spec']} | {x['qty']} | {money(x['reference']*x['packs'])} |")
md += ['', 'Rīku summa 14,04 € pirms piegādes; nav automātiski iekļauta detaļu daļsummā. Svaru 0,01 g rādījuma solis un bīdmēra dalījums negarantē kalibrētu precizitāti. Receptes svari nav presēšanas spēka mērītājs.', '', 'No mājām/skolas: ūdens paplāte ar iekšpusi vismaz 200 × 150 mm, tīrs trauks, masas maisītājs/blenderis, šķēres piemērotas sietam, tīrs absorbējošs papīrs žāvēšanai. Vītņstieņa variantam papildus metāla zāģis un vīle. Ja drukas caurumi jāattīra, vajag Ø2 mm un Ø6,6 mm atbilstošus urbjus; tērauda detaļas pasūta gatavas. Atsevišķu jaunu presi nav jāiegādājas formas aizvēršanai; spēka eksperimentos izmanto skolas izmērīta spēka presi.', '', 'Papīrs un sausas lapas ir pārstrādājams materiāls. Līme, epoksīds, PTFE aerosols, plastmasas skrūves un pieci atsevišķi formu komplekti nav šī sākuma iepirkuma daļa.', '', '## Avoti', '']
for key,(label,url) in SOURCES.items(): md.append(f'- [{label}]({url})')
md += ['', 'Detalizētie avotu novērojumi: `fasteners_research.md`, `filament_tools_research.md`, `metal_mesh_research.md`. Veikalu lapu atlikumi attiecas uz publikācijas brīdi, nevis uz rezervētu pasūtījumu.']
(OUT/'LAPS_Pirkumu_saraksts_DEPO_Bergi.md').write_text('\n'.join(md)+'\n')

with (OUT/'LAPS_Pirkumu_saraksts.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.writer(f,delimiter=';')
    writer.writerow(['Variants','ID','Prece','Vajadzīgais daudzums','Izmērs','Veikals','Gabali iepakojumā','Pirkt iepakojumus','Atsauces cena EUR par iepakojumu','Atsauces rindas summa EUR','Cenas statuss','Avots'])
    for group,data in [('Pamatvariants',rows),('Vītņstienis — aizstāj B01-B03',rod_rows),('Rīki — izvēles',tools)]:
        for x in data: writer.writerow([group,x['id'],x['part'],x['qty'],x['spec'],x['shop'],x['pack'],x['packs'],'' if x['reference'] is None else str(x['reference']).replace('.',','),'' if x['reference'] is None else str(round(x['reference']*x['packs'],2)).replace('.',','),x['status'],SOURCES[x['source']][1]])

wb=Workbook()
wb.remove(wb.active)
header=['ID','Prece','Vajag gab.','Precīzs izmērs','Veikals','Gab./iep.','Pirkt iep.','Atsauces cena €/iep.','Cenas statuss','Avots','Jūsu apstiprinātā cena €/iep.','Apstiprinātā summa €']
for sheet_name,data in [('Pamatvariants',rows),('DEPO_vitnstienis',rod_rows),('Riki_izveles',tools)]:
    ws=wb.create_sheet(sheet_name)
    ws.append(header)
    for i,x in enumerate(data,2):
        ws.append([x['id'],x['part'],x['qty'],x['spec'],x['shop'],x['pack'],x['packs'],x['reference'],x['status'],SOURCES[x['source']][1],None,f'=IF(ISNUMBER(K{i}),G{i}*K{i},"")'])
        ws.cell(i,10).hyperlink=SOURCES[x['source']][1]
        ws.cell(i,10).style='Hyperlink'
        for col in (8,11,12): ws.cell(i,col).number_format='0.00 "€"'
        ws.cell(i,11).fill=PatternFill('solid',fgColor='DDEFFC')
        ws.row_dimensions[i].height=94
    end=len(data)+1
    t=end+2
    ws.cell(t,2,'Apstiprināts šo rindu kopā tikai pēc visu cenu aizpildīšanas')
    ws.cell(t,12,f'=IF(COUNT(K2:K{end})={len(data)},SUM(L2:L{end}),"Trūkst cenu")')
    ws.cell(t+1,2,'Piegāde, rīki un citi varianti summā nav automātiski iekļauti.')
    if sheet_name=='DEPO_vitnstienis': ws.cell(t+2,2,'Izvēles aizstājējs B01–B03. Vītņstieņa atsauces cena ir agrāk indeksēta.')
    ws.freeze_panes='D2'; ws.auto_filter.ref=f'A1:L{end}'
    widths=[8,30,12,52,35,14,14,20,80,50,24,22]
    for c,w in enumerate(widths,1): ws.column_dimensions[chr(64+c)].width=w
    for cell in ws[1]: cell.fill=PatternFill('solid',fgColor='163947'); cell.font=Font(color='FFFFFF',bold=True); cell.alignment=Alignment(wrap_text=True,vertical='top')
    ws.row_dimensions[1].height=44
    for row_cells in ws.iter_rows(min_row=2):
        for cell in row_cells: cell.alignment=Alignment(wrap_text=True,vertical='top')
    dv=DataValidation(type='decimal',operator='greaterThanOrEqual',formula1=0,allow_blank=True)
    ws.add_data_validation(dv);dv.add(f'K2:K{end}')
info=wb.create_sheet('Lasit_vispirms',0)
for line in ['LAPS iepirkums — 2026-10-06','Vēlamais veikals: DEPO Berģi, Siguldas šoseja 6.','Neviena DEPO Berģu cena vai atlikums nav tieši apstiprināts.','H sleja ir atsauces informācija, nevis apstiprināta gala cena.','K zilajās šūnās ievadiet veikala apstiprināto cenu par iepakojumu; G slejā var labot iepakojumu skaitu.','Pamatvarianta skrūvju atsauces cena: Delve 2 klase 10.9, 10 gab.; 1,12 € bez PVN ×1,21 = 1,36 € (aprēķins).','Pamatvarianta uzgriežņu un paplāksņu cenas ir sekundāras DEPO norādes.','Pamatvarianta atsauces daļsumma 20,99 € neietver plāksnes, sietu, piegādi vai izvēles rīkus.','Plāksnēm un sietam vajadzīga tāme. To cena nav ievadīta kā 0.','Vītņstieņa variants aizstāj pamatvarianta pirmās trīs rindas; nesummējiet abus variantus.','Visi gredzeni ir atkārtoti lietojami; tie nav jāpērk katram eksperimentam.','Plašāks skaidrojums un izgatavošanas prasības ir pirkumu PDF.']:
    info.append([line])
info.column_dimensions['A'].width=135
for c in info['A']: c.alignment=Alignment(wrap_text=True,vertical='top')
for i in range(1,info.max_row+1):info.row_dimensions[i].height=32
wb.save(OUT/'LAPS_Pirkumu_budzets.xlsx')

quote='''LAPS — gatavs teksts cenas pieprasījumam. Nav nosūtīts piegādātājiem.

TĒRAUDA PLĀKSNES
Lūdzu piedāvājumu 2 identiskām S235/S235JR tērauda detaļām:
130 × 100 × 8 mm, ārējie stūri R6, 8 caurumi Ø6,6 mm katrā detaļā.
Visi caurumi ir gludi caurejoši, bez vītnes. Abām saskares virsmām jābūt
plakanām un bez atskabargām. Forma paredzēta mazas celulozes plāksnītes
aukstai presēšanai; vienmērīgs plakanums ir svarīgs 1 mm mitrās spraugas testiem.
Lūdzu norādīt sasniedzamo plakanumu un tā papildu apstrādes izmaksu, ja tāda ir.
Pielikumi: P03_steel_backer_8mm_1to1.dxf, steel_backer_MAKE_2.step un
LAPS_Pulp_Press_Technical_Drawings_RevA.pdf (plāksnes rasējums un 1:1 šablons).
Lūdzu atsevišķi norādīt materiālu, griešanu, 16 pabeigtus urbumus, atskabargu
noņemšanu, minimālo darba maksu, PVN, saņemšanas/piegādes izmaksas un termiņu.
Vēlams izgatavot no piegādātāja materiāla vai atgriezuma, bez pilnas loksnes pirkuma.

SMALKAIS SIETS
Lūdzu piedāvājumu vienai 200 × 150 mm sagatavei no nerūsējoša tērauda
304 / EN 1.4301 vienkārša pinuma sieta: acs 0,15 mm, stieple 0,10 mm
(apmēram 100 mesh). Vajadzīgas 2 oderes 84,5 × 54,5 mm, R3; pārējais rezervēm.
Ja iespējams, lūdzu arī cenu 2 gatavām kontūrām pēc P04_mesh_cut_pattern_1to1.dxf.
Lūdzu apstiprināt acs lielumu, stieples diametru, kopējo pinuma biezumu un
toleranci, pieejamību, maza atgriezuma/parauga minimālo pasūtījumu, PVN,
piegādi Latvijā un izgatavošanas/izsūtīšanas termiņu.
'''
(OUT/'Tames_pieprasijumi_LV.txt').write_text(quote)

for name,file in [('Shop','DejaVuSans.ttf'),('ShopBold','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+file))
NAVY=colors.HexColor('#163947'); TEAL=colors.HexColor('#0E776C'); GRAY=colors.HexColor('#52626A')
styles={
 'title':ParagraphStyle('title',fontName='ShopBold',fontSize=23,leading=28,textColor=NAVY,spaceAfter=8),
 'h1':ParagraphStyle('h1',fontName='ShopBold',fontSize=16,leading=21,textColor=NAVY,spaceAfter=10),
 'h2':ParagraphStyle('h2',fontName='ShopBold',fontSize=10,leading=14,textColor=TEAL,spaceBefore=10,spaceAfter=6),
 'body':ParagraphStyle('body',fontName='Shop',fontSize=9,leading=13,textColor=NAVY,spaceAfter=7),
 'small':ParagraphStyle('small',fontName='Shop',fontSize=7.9,leading=11,textColor=GRAY,spaceAfter=5),
 'cell':ParagraphStyle('cell',fontName='Shop',fontSize=7.6,leading=10.5,textColor=NAVY),
 'head':ParagraphStyle('head',fontName='ShopBold',fontSize=7.7,leading=10.5,textColor=colors.white),
}
story=[]
def p(s,style='body'):story.append(Paragraph(escape(s),styles[style]))
def h(s):p(s,'h2')
def page(s):story.append(PageBreak());p(s,'h1')
def box(s):
    t=Table([[Paragraph(escape(s),styles['body'])]],colWidths=[180*mm])
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),colors.HexColor('#EAF3F1')),('BOX',(0,0),(-1,-1),0.4,TEAL),('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
    story.append(t);story.append(Spacer(1,9))
def tab(headers,data,widths):
    cells=[[Paragraph(escape(str(s)),styles['head']) for s in headers]]+[[Paragraph(escape(str(s)),styles['cell']) for s in r] for r in data]
    t=Table(cells,colWidths=[w*mm for w in widths],repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F2F5F5')]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,-1),0.25,colors.HexColor('#D8E2E2'))]))
    story.append(t);story.append(Spacer(1,8))
def link(key,extra=''):
    label,url=SOURCES[key]
    story.append(Paragraph(f'<link href="{escape(url)}" color="#0E776C">{escape(label)}</link>'+(' — '+escape(extra) if extra else ''),styles['small']))

p('LAPS — pirkumu saraksts','title')
p('DEPO Berģi · Siguldas šoseja 6 · 6. oktobris 2026','small')
box('DEPO Berģu aktuālās cenas un atlikumus nevarēju tieši apstiprināt. DEPO summas ir sekundāras cenu salīdzinātāja norādes. Citu veikalu piedāvājumi ir alternatīvas, ja vajadzīgo DEPO nevar sagādāt. Pilnam budžetam trūkst plākšņu un sieta tāmes.')
p('1. Pamatvariants esošajam 3D modelim','h1')
tab(['Prece / daudzums','Precīzs izmērs','Cena un iegādes vieta'],[
 ['8 bultskrūves','M6 × 60; pilna vītne DIN 933; solis 1,0; vēlama klase 8.8','DEPO cena nav apstiprināta. Delve 2 alternatīva: 10.9 melnas, 10 gab.; 1,36 € ar aprēķinātu 21% PVN.'],
 ['8 uzgriežņi','M6 DIN 934; atslēga 10 mm; atbilstoša klase','DEPO salīdzinātāja norāde: 100 gab., klase 12.0; 2,11 €.'],
 ['16 paplāksnes','M6 DIN 9021; Ø6,4 × Ø18 × 1,6; metāla, bez gumijas','DEPO salīdzinātāja norāde: 40 nerūsējošas; 2,62 €.'],
 ['2 tērauda plāksnes','S235; 130 × 100 × 8; R6; 8 × Ø6,6 katrā','DEPO cena nav apstiprināta. Metāla Alianse: gatavās detaļas pēc tāmes.'],
 ['2 sieta oderes','84,5 × 54,5, R3; 304; acs 0,15; stieple 0,10 mm','DEPO cena nav apstiprināta. EuroSitex: maza atgriezuma un markas tāme.'],
 ['1 PETG spole','Ø1,75 mm; 1 kg; bez CF pildījuma','DEPO cena nav apstiprināta. Filaments.lv eSUN PETG Basic: 14,90 € ar PVN; pakomāts +2,90 €.'],
], [30,67,83])
box('Atsauces daļsumma 20,99 € = 1,36 + 2,11 + 2,62 + 14,90. Tā apvieno citu veikalu cenas un neapstiprinātas DEPO norādes. Vēl jāpieskaita gatavās plāksnes, siets, izvēlētā piegāde un rīki. Tā nav visa projekta gala cena.')
p('Delve 2 publiskais iepakojums: 93310M-6X60, 10 gab., 1,12 € bez PVN; ×1,21 → 1,36 €. Atlikums un piegāde nav apstiprināti. Ja DEPO ir vajadzīgās cinkotās 8.8 skrūves, izmanto tās šīs alternatīvas vietā. Melno skrūvju virsmas pēc mitras lietošanas nosusina.','small')
p('Nepirkt gremdgalvas skrūves, kokskrūves vai daļējas vītnes skrūves, nepārbaudot derīgumu visiem pieciem gredzeniem. Skrūves garumu 60 mm mēra zem galvas.','small')

page('2. Izvēles DEPO vītņstieņa variants')
p('Šis variants aizstāj 8 bultskrūves un 8 uzgriežņus. Paplāksnes paliek 16. Vienu variantu izvēlas visam komplektam; abus nepērk kopā. Modelī un renderos attēlotas oriģinālās 60 mm skrūves.')
tab(['Pirkt','Izmērs / izmantošana','Sekundāra DEPO norāde'],[
 ['1 vītņstienis','M6 × 1,0; A2; 1000 mm → 8 gab. pa 70 mm','1,70 €; agrāk indeksēts, aktuālā cena nav apstiprināta.'],
 ['1 uzgriežņu iep.','M6 DIN 934, nerūsējoši; 40 gab.; izmantot 24','2,37 €; Berģu cena un atlikums nav apstiprināti.'],
 ['1 paplāksņu iep.','M6 DIN 9021, nerūsējošas; 40 gab.; izmantot 16','2,62 €; Berģu cena un atlikums nav apstiprināti.'],
],[35,84,61])
box('Stiprinājumu atsauces daļsumma 6,69 €; ar PETG 21,59 €. Plāksnes, siets, piegāde un rīki nav iekļauti. Daļsumma ietver agrāk indeksēto vītņstieņa cenu un nav apstiprināts DEPO piedāvājums.')
h('Salikšana')
p('Apakšā uz katra stieņa ir divi savstarpēji nofiksēti uzgriežņi; iekšējais balstās uz paplāksnes pret tērauda plāksni. Augšā ir viena paplāksne un viens uzgrieznis. Apakšējos uzgriežņus savstarpēji noslēdz ar divām atslēgām pirms celulozes pildīšanas. Stieņu grieztos galus novīlē un pārbauda vītnes.')
p('Lielākā komplekta nominālais biezums: 24 + 16 + 5,4 = 45,4 mm. Ar paplāksnēm un trim apmēram 5–5,2 mm uzgriežņiem kopā 63,6–64,2 mm. 70 mm stienis dod vietu vītnes izvirzījumam abos galos; faktisko izmēru pārbauda saliekot. Aizver pakāpeniski pa diagonāli, saudzīgi ar roku. Uzgriežņu pievilkšana nav spiediena mērījums.')
h('Rīki — aizņemties, pirkt tikai trūkstošos')
tab(['Vajag','Alternatīva, ja DEPO nevar sagādāt','Cena bez piegādes'],[
 ['2 atslēgas 10 mm','REVA CR-V SATIN SA-6314324','2 × 1,22 = 2,44 €'],
 ['1 bīdmērs 0–150 mm','REVA metāla EK-3015','5,00 €'],
 ['1 svari 200 g / 0,01 g','Motivs, kods 132772','6,60 €'],
],[47,90,43])
p('Rīku kopā 14,04 € pirms piegādes. REVA publicē pieejamību; Motivs publicē 10+, bezmaksas saņemšanu Duntes 56 un pakomātu no 1,90 €. DEPO rīku cenas nav apstiprinātas. Rādījuma solis nav precizitātes garantija.','small')
p('Izmantot esošu paplāti ≥200 × 150 mm, trauku, masas blenderi/maisītāju un žāvēšanas papīru. Vītņstienim vajag metāla zāģi un vīli. Ja drukas caurumus jāattīra: Ø2 un Ø6,6 mm urbji. Tērauda plāksnes vēlams saņemt jau izgatavotas.','small')

page('3. Plākšņu un sieta izgatavošanas prasības')
h('Tērauda atbalsta plāksnes')
p('2 × S235/S235JR, 130 × 100 × 8 mm, ārējie stūri R6, gludas un plakanas saskares virsmas, visas malas un caurumi bez atskabargām. Katrai 8 caurejoši Ø6,6 mm urbumi bez vītnes. Vienas detaļas masa aptuveni 0,80 kg.')
tab(['Centri no plāksnes centra, mm','Centri no plāksnes centra, mm'],[['(−53, −38)   (0, −38)   (53, −38)','(−53, 0)   (53, 0)'],['(−53, 38)   (0, 38)   (53, 38)','Visu urbumu Ø6,6; detaļas biezums 8 mm']],[90,90])
p('Metāla Alianse: S235 8 mm loksne HRS00076, publiski 90 €/m² un noliktavā; PVN režīms izvilkumā nav skaidrs. 0,026 m² × 90 = 2,34 € ir tikai teorētiska sagatavju laukuma vērtība. Gatavu detaļu cena ietver darba minimumu, griešanu, 16 urbumus, atskabargu noņemšanu un vajadzīgo plakanumu. Nepieciešama tāme ar PVN un piegādi. Pilna 1500 × 6000 mm loksne šim projektam nav vajadzīga, ja piegādātājs izgatavo no sava materiāla.')
link('steel');link('machining')
h('Smalkais siets')
p('Vēlams 304 / 1.4301, vienkārša pinuma siets: acs 0,15 mm (150 µm), stieple 0,10 mm, apmēram 100 mesh. Pasūtāma viena 200 × 150 mm sagatave; no tās izgriež četrus 84,5 × 54,5 mm R3 gabalus, divi ir rezerves. Minimāli 150 × 100 mm sagatave dod divus gabalus.')
p('EuroSitex Latvija piedāvā tehnisko nerūsējošo sietu, bet publiski norāda garumu no 1 m. Precīzās markas atlikums un maza atgriezuma/parauga iespēja jānoskaidro. getwiremesh EU alternatīvai publicēta formula 34 €/m² + 6 € par griezumu: 200 × 150 mm aritmētiski 7,02 € pirms PVN un piegādes. Konkrētā izmēra pieņemšana, atlikums un Latvijas piegādes cena nav apstiprināti. Tas nav gala piedāvājums.')
link('mesh');link('mesh_eu')
box('Parasts moskītu siets nav automātisks aizvietotājs. Izmēra saspiesto sieta biezumu. Gredzeni paredz 2 × 0,20 mm; citam sietam faktiskā celulozes sprauga jāpārkalibrē.')
h('Izgatavotājam dotie faili')
p('P03_steel_backer_8mm_1to1.dxf · steel_backer_MAKE_2.step · LAPS_Pulp_Press_Technical_Drawings_RevA.pdf · P04_mesh_cut_pattern_1to1.dxf · Tames_pieprasijumi_LV.txt. Pirkumu arhīvā tie ir jau pievienoti. Pieprasījuma teksts ir sagatavots, nav nosūtīts.')
h('Ko drukāt')
p('2 PETG plāksnes un pa vienam no pieciem gredzeniem, augstumi 1,4 / 2,4 / 3,4 / 4,4 / 5,4 mm. Gredzens nosaka 1–5 mm mitro spraugu, nevis garantētu sauso biezumu. Visu izdruku CAD masa apmēram 549 g; viena 1 kg spole dod rezervi. eSUN profilam izmanto eSUN ražotāja parametrus.')

page('4. Avoti un budžeta aizpildīšana')
p('Pārbaudīts 2026. gada 6. oktobrī. Veikalu publicētie atlikumi nav rezervācija. Neviena alternatīvā veikala lapa neapliecina DEPO Berģu pieejamību.')
link('depo')
h('DEPO cenu norādes — sekundārs avots')
link('nuts','100 gab.; 2,11 €; Berģu cena nav apstiprināta')
link('washers','40 gab.; 2,62 €; Berģu cena nav apstiprināta')
link('rod','1000 mm M6 A2; 1,70 € ir agrāk indeksēta norāde')
link('rod_nuts','40 gab.; 2,37 €; Berģu cena nav apstiprināta')
h('Citu veikalu pārbaudītās produktu lapas')
link('bolt','10 gab. M6 × 60, klase 10.9; 1,12 € bez PVN')
link('filament','14,90 € ar PVN; pakomāts +2,90 €; publicēti 25 gab.')
link('wrench','1,22 €/gab. ar PVN; vajag 2')
link('caliper','5,00 € ar PVN')
link('scale','6,60 €; pakomāts no 1,90 €')
h('Darba faili')
p('LAPS_Pirkumu_budzets.xlsx: zilajās šūnās ievada apstiprināto cenu par iepakojumu. Var labot pērkamo iepakojumu skaitu. Rindu gala summa parādās tikai, kad visas attiecīgā varianta cenas aizpildītas. Nezināmās cenas ir tukšas, nevis 0 €.')
p('LAPS_Pirkumu_saraksts.csv ir vienkārša tabula; Markdown versijā ir plašāki paskaidrojumi. Tāmes teksts un CAD faili ir atsevišķajā pirkumu ZIP un atjaunotajā pilnajā projekta ZIP.')
box('Pamatvariants: atsauces daļsumma 20,99 € + gatavo plākšņu tāme + sieta tāme + izvēlētā piegāde. Vītņstienis: atsauces daļsumma ar PETG 21,59 € + tie paši iztrūkstošie izdevumi. Izvēles rīki 14,04 € pirms piegādes. Gala budžets pašlaik nav apstiprināts.')
p('Skrūvju klase un paplāksnes nerada zināmu celulozes spiedienu. Formas aizvēršanai lieto roku spēku; spiediena pētījumos izmanto skolas izmērīta spēka presi un projekta eksperimentu rokasgrāmatu.','small')

def footer(canvas,doc):
    canvas.setStrokeColor(colors.HexColor('#D9E3E3'));canvas.line(15*mm,16*mm,195*mm,16*mm)
    canvas.setFont('Shop',7);canvas.setFillColor(GRAY)
    canvas.drawString(15*mm,11*mm,'LAPS · DEPO Berģi · cenu pārbaude 2026-10-06')
    canvas.drawRightString(195*mm,11*mm,str(doc.page))
doc=SimpleDocTemplate(str(OUT/'LAPS_Pirkumu_saraksts_DEPO_Bergi.pdf'),pagesize=(210*mm,297*mm),leftMargin=15*mm,rightMargin=15*mm,topMargin=16*mm,bottomMargin=22*mm,title='LAPS pirkumu saraksts — DEPO Berģi',author='LAPS project')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print('Built Latvian shopping PDF, Markdown, CSV, editable workbook, JSON and quote text.')
