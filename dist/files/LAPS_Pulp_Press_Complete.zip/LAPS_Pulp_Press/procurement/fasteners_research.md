# Stiprinājumi celulozes presformai — izpēte 2026-10-06

Vēlamā iegādes vieta: **DEPO Berģi**. Šajā izpētē nav verificēts neviens Berģu veikala atlikums vai cena. DEPO vietne pārlūkošanas rīkā atgrieza tukšu dinamisku lapu; cenu salīdzinātājs parāda dažus DEPO piedāvājumus. Tas **nepierāda**, ka konkrētā prece ir vai nav Berģos. Pasūtījumi un saziņa ar veikaliem nav veikta.

## Precīzs nepieciešamo stiprinājumu saraksts

| Detaļa | Izmērs un prasība | Nepieciešams |
|---|---|---:|
| Sešstūra bultskrūve | M6 × 60 mm, parastā M6 vītne ar soli 1,0 mm; pilna vītne līdz galvai, DIN 933 / ISO 4017; vēlams cinkots tērauds, klase 8.8; atslēga 10 mm | 8 gab. |
| Sešstūra uzgrieznis | M6, solis 1,0 mm, DIN 934, parasts uzgrieznis; atslēga 10 mm | 8 gab. |
| Platā metāla paplāksne | M6 DIN 9021; nomināli Ø6,4 × Ø18 × 1,6 mm; bez gumijas, metāla; pa vienai abās skrūves pusēs | 16 gab. |

M6 × 60 mm garums ir zem galvas līdz skrūves galam. Pilna vītne vajadzīga, lai to pašu skrūvi varētu izmantot ar visām piecām starplikām. Nepirkt kokskrūves, gremdgalvas skrūves vai DIN 931 ar nepārbaudītu vītnes garumu. Atsevišķs DIN 603 variants ar pusapaļu galvu nav sākotnējā projekta stiprinājums.

## DEPO kandidāti — cenas ir sekundāra avota norādes

| Prece, kas redzama cenu salīdzinātājā | Iepakojums | Pirkt iepakojumus | Salidzini.lv rādītā DEPO piedāvājuma cena | Aprēķins pēc šīs norādes | DEPO preces kods / Berģu cena |
|---|---:|---:|---:|---:|---|
| Uzgriežņi DIN 934 M6, klase 12.0 | 100 gab. | 1 | 2,11 € | 2,11 € | Nav verificēts |
| Platās nerūsējošā tērauda paplāksnes DIN 9021 M6 | 40 gab. | 1 | 2,62 € | 2,62 € | Nav verificēts |
| Pilnas vītnes sešstūra bultskrūve DIN 933 M6 × 60, klase 8.8 | Nav identificēts | Nav nosakāms | Nav verificēts | Nav nosakāms | Nav verificēts |

2,11 € un 2,62 € ir cenas, kas parādījās atvērtajās Salidzini.lv lapās šīs izpētes laikā. Vecākās meklētāja izdrukās tiem pašiem kandidātiem bija 2,05 € un 2,56 €. Tāpēc tos nedrīkst saukt par apstiprinātām DEPO Berģu aktuālajām cenām un nedrīkst no tiem izveidot apstiprinātu pilnu DEPO kopējo summu. Paplāksnes ārējais Ø18 un biezums 1,6 ir projekta prasība; atbilstošie izmēri konkrētajā DEPO iepakojumā jāpārbauda.

- [Uzgriežņu piedāvājumu lapa](https://www.salidzini.lv/cena?q=uzgrieznis+din+934m-6). DEPO ieraksts: 100 gab., 2,11 €. [Saite uz konkrēto DEPO piedāvājumu caur Salidzini.lv](https://www.salidzini.lv/click.php?itemid=95754468776&q=uzgrieznis+din+934m-6). Šis identifikators ir Salidzini.lv piedāvājuma ID, **nevis DEPO SKU**.
- [Paplāksņu piedāvājumu lapa](https://www.salidzini.lv/cena?q=papl%C4%81ksnes+din9021+m6). DEPO ieraksts: 40 gab., 2,62 €. [Saite uz konkrēto DEPO piedāvājumu caur Salidzini.lv](https://www.salidzini.lv/click.php?itemid=95755187871&q=papl%C4%81ksnes+din9021+m6). Šis identifikators ir Salidzini.lv piedāvājuma ID, **nevis DEPO SKU**.
- [DEPO Online](https://online.depo.lv/): tieši atvērta, bet produkta saturs, cenas un veikala izvēle pārlūkošanas rīkam nebija nolasāmi.

## Nosacītas alternatīvas tikai tad, ja DEPO vajadzīgā prece nav pieejama

Šīs nav norāde automātiski mainīt veikalu. Tās ir atsevišķi verificēti interneta piedāvājumi gadījumam, ja vajadzīgo detaļu neatrod DEPO. Berģu atlikums joprojām nav noskaidrots. Piegāde nav iekļauta.

| Pārdevējs / detaļa | Preces kods | Iepakojums | Nepieciešamie iepakojumi | Publicētā cena | Rindas summa | Piezīme |
|---|---|---:|---:|---:|---:|---|
| Delve 2 — FORTIS DIN 933, pilna vītne, M6 × 60, cinkota, 8.8 | FOR-933-6X60 | 200 gab. | 1 | 16,00 € bez PVN | 19,36 €, aprēķinot ar 21% PVN | Primārajā tabulā norādīts pilnais iepakojums; nepamatot, ka var pirkt tikai 8 gab. |
| Delve 2 — DIN 933, pilna vītne, M6 × 60, melna, 10.9 | 93310M-6X60 | 10 gab. | 1 | 1,12 € bez PVN | 1,36 €, aprēķinot ar 21% PVN | Derīgs izmēra variants; augstāka klase nemaina PETG preses slodzes robežu; pēc mitras lietošanas jātur sauss |
| K-Senukai — Haushalt DIN 933 M6 × 60, nerūsējoša | 000000000502120868 | 10 gab. | 1 | 3,59 € parastā / 2,39 € lojalitātes | 3,59 € / 2,39 € | Pilna vītne norādīta; stiprības klase nav norādīta, tā jāpārbauda |
| INSERV — ESSVE DIN 934 M6 FZB | 61068525 | 100 gab. | 1 | 4,40 € | 4,40 € | M6, 10 mm atslēga, 5,2 mm augstums; lapa rādīja saņemšanu 13. oktobrī |
| INSERV — ESSVE DIN 9021 M6 FZB | 61068297 | 100 gab. | 1 | 4,70 € | 4,70 € | Ø6,4 × Ø18 × 1,6 mm tieši norādīts; lapa rādīja saņemšanu 13. oktobrī |

Avoti, atvērti 2026-10-06:

- [Delve 2: cinkotas DIN 933 pilnas vītnes skrūves](https://www.delve2.lv/lv/products/screws-with-metric-thread/hexagon-head-bolts-full-thread-zinc-palted-din-933zn/?op=20&p=2). M6×60 rindā iepakojums 200 un cena 16,00 €.
- [Delve 2: melnas DIN 933 pilnas vītnes skrūves](https://www.delve2.lv/lv/products/screws-with-metric-thread/hexagon-head-bolts-full-thread-black-din-933m/). M6×60 rindā iepakojums 10 un cena 1,12 €.
- [K-Senukai: 10 nerūsējošas M6×60 DIN 933 skrūves](https://www.ksenukai.lv/p/skruve-din-933-haushalt-din933-6-mm-x-60-mm-10-gab/c53j). Tiešā lapa rādīja 3,59 € parasto / 2,39 € lojalitātes interneta cenu; fizisko veikalu cenas var atšķirties.
- [INSERV: M6 DIN 934 uzgriežņi, 100 gab.](https://www.inserv.lv/products/80791/din934-uzgrieznis-m6-fzb-100gab-essbox-61068525-essve). Tiešā lapa rādīja 4,40 €.
- [INSERV: M6 DIN 9021 paplāksnes, 100 gab.](https://www.inserv.lv/products/80804/paplaksne-din9021-m6-fzb-100gab-essbox-61068297-essve). Tiešā lapa rādīja 4,70 € un visus trīs paplāksnes izmērus.

[Delve 2 noteikumu 3.2. punkts](https://www.delve2.lv/lv/info/terms-conditions/) nosaka cenas bez PVN, ja nav skaidri norādīts citādi. Produktu tabulā citāda norāde nebija redzama. Tāpēc tabulā blakus publicētajai cenai ir atsevišķs aprēķins ar 21% PVN; faktiskā gala cena jāpārbauda pirms iegādes. [INSERV noteikumu 2. punkts](https://www.inserv.lv/info/noteikumi) tieši apstiprina, ka 4,40 € un 4,70 € ietver 21% PVN.

Piemērs: Delve 2 melnās 10.9 skrūves ar aprēķināto PVN + INSERV uzgriežņi un paplāksnes = **10,46 €**, bez piegādes. Tas ir nosacīts divu alternatīvu veikalu variants, **nevis DEPO Berģu piedāvājums**. Izvēloties 8.8 cinkoto 200 gab. skrūvju iepakojumu ar aprēķināto PVN, tā pati summa ir 28,46 €.

## Izvēles variants: visas trīs stiprinājumu pozīcijas no DEPO

Sākotnējās DIN 933, 8.8, M6 × 60 bultskrūves paliek pirmā izvēle, ja tās ir Berģu veikalā. Ja tās neatrod, izskatāms M6 A2 vītņstieņa variants: viens 1 m stienis, sagriezts **8 × 70 mm**; **24 M6 DIN 934 nerūsējošie uzgriežņi** un **16 M6 DIN 9021 nerūsējošās platās paplāksnes**. Mehānisko derīgumu un preses spēka robežu izvērtē atsevišķi; A2 materiāla apzīmējums pats nenorāda konkrētu stiprības klasi.

| DEPO kandidāts | Iegādāties | Izmantot | Cenu salīdzinātājā atvērtās lapas cena | Avota svaigums, piekļuve 2026-10-06 |
|---|---:|---:|---:|---|
| M6 A2 nerūsējošais vītņstienis, 1 m | 1 gab. | 8 × 70 mm | 1,70 € | Atvērtā lapa rīka izdrukā bija kešota pirms 4 mēnešiem; otra lapa — pirms mēneša. **Aktualitāte nav apstiprināta.** |
| M6 DIN 934 nerūsējošie uzgriežņi, 40 gab. | 1 iep. | 24 gab. | 2,37 € | Salidzini.lv lapa rādīja pārmeklēšanu šodien; sekundārs avots. Vecāks izraksts rādīja 2,32 €. |
| M6 DIN 9021 nerūsējošās platās paplāksnes, 40 gab. | 1 iep. | 16 gab. | 2,62 € | Salidzini.lv lapa rādīja pārmeklēšanu šodien; sekundārs avots. |

**6,69 € ir tikai šo trīs redzamo norāžu atsauces summa**, ietverot neatjauninātu vītņstieņa cenu. Tā nav verificēta aktuāla DEPO Berģu iepirkuma summa. DEPO SKU, PVN iekļaušana, materiāla stiprības klase un Berģu atlikumi nav verificēti.

- [M6 A2 1 m stieņa cenu lapa](https://www.salidzini.lv/cena?q=v%C4%ABt%C5%86stienis+1m+ner%C5%ABs%C4%93jo%C5%A1%C4%81), DEPO ieraksts 1,70 €; [konkrētā piedāvājuma pāradresācija](https://www.salidzini.lv/click.php?itemid=95609168596&q=v%C4%ABt%C5%86stienis+1m+ner%C5%ABs%C4%93jo%C5%A1%C4%81).
- [Nerūsējošo DIN 934 uzgriežņu cenu lapa](https://www.salidzini.lv/cena?offset=36&q=uzgrieznis+din+934%2C+ner%C5%ABs%C4%93jo%C5%A1%C4%81+t%C4%93rauda), M6 40 gab. DEPO ieraksts **2,37 €**; [konkrētā piedāvājuma pāradresācija](https://www.salidzini.lv/click.php?itemid=95753564220&q=uzgrieznis+din+934%2C+ner%C5%ABs%C4%93jo%C5%A1%C4%81+t%C4%93rauda).
- [Nerūsējošo DIN 9021 paplāksņu cenu lapa](https://www.salidzini.lv/cena?q=papl%C4%81ksnes+din9021+m6), M6 40 gab. DEPO ieraksts **2,62 €**.

1 m stieņa garuma pietiek: 8 × 70 = 560 mm, atstājot 440 mm zāģējuma platumiem un atlikumam. Abu nogriezto galu asas malas jānoņem; uzgriezni var uzskrūvēt pirms griešanas, lai pēc griešanas palīdzētu sakārtot pirmo vītnes vijumu. Trīs uzgriežņi katram stienim paredz divus savstarpēji kontrētus uzgriežņus vienā galā un vienu darba uzgriezni otrā. Darbam jāpārbauda, ka visā starpliku diapazonā uzgriezņi satver pilnu vītni un grieztās malas nav atstātas asas.

## Instrumenti — DEPO kandidāti, cena un Berģu atlikums nav verificēti

Vajadzīgi divi 10 mm uzgriežņu atslēgas gali, viens skrūves galvai un viens uzgrieznim. Var lietot esošus instrumentus. Ja caurumi pēc drukāšanas jāattīra: Ø2 mm urbis drenāžas caurumiem un Ø6,6 mm urbis skrūvju caurumiem; Ø6,5 mm var būt praktisks attīrīšanas variants, ja skrūve brīvi iet cauri. Tērauda plākšņu apstrādei nepieciešams metāla urbis un piemērots darbnīcas aprīkojums.

- [Salidzini.lv: Jasper urbji](https://www.salidzini.lv/cena?q=urbis+jasper) rāda DEPO Jasper Ø2 mm HSS urbi par 0,45 €. Tas ir tikai sekundārs, agrāk indeksēts DEPO piedāvājums.
- [Salidzini.lv: Tactix 10 mm reversa atslēga](https://www.salidzini.lv/cena?offset=190&q=tactix) meklētāja rezultātā rādīja DEPO 6,03 €. Tas ir agrāk indeksēts, sekundārs piedāvājums; to nevar uzrādīt kā 6. oktobrī apstiprinātu DEPO Berģu cenu.
- Ø6,6 vai Ø6,5 mm konkrēts DEPO urbis un vienkārša 10 mm atslēga netika verificēti. Cenas nav izdomātas.
