# PETG un darba rīki — pārbaudītas interneta cenas

Pārbaudīts **2026. gada 6. oktobrī**. Prioritāte: **DEPO Berģi**. Pasūtījumi nav veikti un pārdevēji nav kontaktēti. Šīs piezīmes attiecas uz filamentu un rīkiem; skrūves, tērauda plāksnes un siets tiek pārbaudīti atsevišķi.

## DEPO Berģi pārbaudes rezultāts

[DEPO interneta veikals](https://online.depo.lv/) pārlūkošanas rīkam atgrieza dinamisku lapu bez nolasāma preču satura. Meklējumos par PETG filamentu, 10 mm atslēgām, bīdmēriem un svariem šajā domēnā pārbaudāmas produktu lapas neatradu. Tādēļ **cenas un atlikums DEPO Berģi nav apstiprināti**. Tas nav pierādījums, ka veikalā šo preču nav.

Zemāk esošie citu veikalu piedāvājumi ir pārbaudītas alternatīvas, ja vajadzīgo preci DEPO Berģi nevar iegādāties. Tos nevajag pasniegt kā DEPO cenas vai iekļaut obligātajā budžetā kā papildu pirkumus.

## Obligātais drukas materiāls

Vajag **1 spoli parasta PETG, Ø1,75 mm, 1 kg**, bez oglekļa šķiedras (CF) pildījuma. Abām PETG plāksnēm un visiem pieciem gredzeniem CAD aprēķins ir apmēram **549 g** pie 1,27 g/cm³ blīvuma; 0,5 kg spole visam komplektam nepietiek. 1 kg dod rezervi kalibrēšanai, apmalēm un atkārtotām izdrukām. Tas ir projekta daudzuma aprēķins, nevis pārdevēja patēriņa solījums.

| Pārdevējs un produkts | Cena par vienu 1 kg spoli | Pārbaudītā pieejamība | Piegāde / saņemšana | Vienas spoles izmaksas |
| --- | --- | --- | --- | --- |
| [Filaments.lv — eSUN PETG Basic BLACK, 1,75 mm, 1 kg](https://filaments.lv/produkti/esun-petg-basic-melns-filaments-black/) | **14,90 € ar PVN** | Produkta lapā: 25 gab. uz vietas; norādīta izsūtīšana 24 h laikā | Bez maksas saņemot Kalnciema ielā 148, Rīgā; Latvijas pakomāts **2,90 €**, aptuveni 1–2 dienas pēc izsūtīšanas | **14,90 € saņemot pašam** vai **17,80 € ar pakomātu** |
| [ELEGOO EU — PETG PRO, 1,75 mm, 1 kg](https://eu.elegoo.com/products/petg-pro-filament-1-75mm-colored-1kg) | **13,99 €** attēlotā EUR cena | Produkta lapā pieejama pirkšanas poga; konkrētās krāsas noliktavas atlikums nav apstiprināts | Latvija ir piegādes sarakstā; pasūtījumam zem 50 € norādīta **15 €** piegāde; Latvijai aptuveni 4–8 darba dienas | **28,99 €**, ja pasūta tikai vienu spoli un piemēro attēloto piegādes tarifu |

Ja DEPO piemērotu filamentu neatrod, šeit pārbaudītais Latvijas variants ir izdevīgāks par vienas ELEGOO spoles atsevišķu piegādi. Izvēlēto krāsu un cenu pārbauda pirms apmaksas. eSUN un ELEGOO ir atšķirīgi materiāli: printera profilu izvēlas pēc iegādātā filamenta datu lapas, nevis automātiski pārnes ELEGOO PETG PRO temperatūras.

Pelēks eSUN PETG Basic bija pieejams arī [atsevišķā produkta lapā](https://filaments.lv/produkti/esun-petg-basic-peleks-filaments-grey/) par 14,90 €; galvenajā tabulā melnajam variantam ir skaidri nolasāms atlikums. Nav vajadzīgs pirkt vairākas krāsas.

## Rīki — aizņemties vispirms; pirkt tikai tad, ja nav skolā vai mājās

Šie rīki ir vajadzīgi darbam un mērījumiem, bet tie nav papildu preses konstrukcijas daļas. Cenas ir citu Latvijas veikalu pārbaudītas interneta cenas, **nevis DEPO Berģi plaukta cenas**. Vispirms DEPO jāmeklē tie paši izmēri; alternatīvas izmantot, ja DEPO nav piemērota piedāvājuma.

| Rīks / vajadzīgais daudzums | Pārbaudīts alternatīvs produkts | Cena | Atlikums un piegāde | Piezīme projektam |
| --- | --- | --- | --- | --- |
| **2 × 10 mm kombinētā uzgriežņu atslēga** | [REVA — CR-V SATIN 10 mm, SA-6314324](https://www.reva.lv/sa-6314324-kombineta-atslega-10-mm-cr-v-satin-%28indija%29/1840/1/p) | **1,22 € ar PVN/gab.; 2,44 € par 2 gab.** | Lapā “Ir pieejams”; piegādes cena un termiņš nav publicēts nolasītajā piedāvājumā | Standarta M6 sešstūra galvai un uzgrieznim; pārbaudīt iegādāto skrūvju galvas platumu |
| **1 × metāla bīdmērs, 0–150 mm** | [REVA — 150 mm, EK-3015](https://www.reva.lv/ek-3015-bidmers-150mm-002mm/1061/1/p) | **5,00 € ar PVN/gab.** | “Ir pieejams”; piegādes cena nav apstiprināta | Nosaukumā norādīti 0,02 mm; tas nav neatkarīgi pārbaudīts precizitātes apliecinājums. Salīdzināt ar zināmu biezumu vai izmantot skolas mikrometru |
| **1 × digitālais bīdmērs, 0–150 mm**, alternatīva iepriekšējam | [REVA — KINGRONY DC-6B](https://www.reva.lv/dc-6b-bidmers-elektroniskais-150mm-kingrony/1062/1/p) | **7,43 € ar PVN/gab.** | “Ir pieejams”; piegādes cena nav apstiprināta | Nepirkt abus bīdmērus; digitālais ir izvēles alternatīva. Precizitātes specifikācija nolasītajā lapā nebija dota |
| **1 × svari ar 0,01 g rādījuma soli**, vismaz 200 g ietilpība | [Motivs.lv — 200 g / 0,01 g, kods 132772](https://motivs.lv/kabatas-un-juvelierizstradajumu-svari/elektroniskie-juvelierizstradajumu-svari-200g-0-01g-sudraba) | **6,60 €/gab.** | Ir noliktavā, 10+ gab.; 2 AAA baterijas komplektā; saņemšana Duntes ielā 56, Rīgā bez maksas; pakomāts **no 1,90 €** | Sausai receptei un kartītes masai. 0,01 g rādījums pats par sevi negarantē kalibrētu precizitāti. Šie svari nav instruments 933 N iekšējā presēšanas spēka mērīšanai |

Pārbaudītā lētākā rīku alternatīva bez dubultām izvēlēm: divas atslēgas + mehāniskais bīdmērs + svari = **14,04 €**, neieskaitot nezināmo REVA piegādi un izvēlēto Motivs piegādi. Ja tie jau pieejami skolā vai mājās, jauno rīku pirkuma izmaksas ir **0 €**. Šo summu neiekļaut obligāto detaļu kopējā cenā automātiski.

INSERV [Partner PA-3010 10 mm atslēga](https://www.inserv.lv/products/176488/partner-pa-3010-kombineta-atslega-10mm-12-skaldnu-oglekla-terauds-pretkorozijas-parklajums) bija norādīta par 1,10 €, taču pieejamība tikai **2026. gada 26. oktobrī**. Tādēļ šo zemāko cenu neizmantot kā uzreiz pieejamu pirkumu.

## Var izmantot esošas saimniecības lietas

| Lieta | Piemērots izmērs / daudzums | Pirkuma statuss |
| --- | --- | --- |
| Ūdens savākšanas paplāte | Iekšējais laukums vismaz **200 × 150 mm**, ar apmali; preses pamatne 130 × 100 mm | Izmantot esošu paplāti, cenu nepiešķirt |
| Absorbējošs, tīrs papīrs vai blotēšanas loksnes | Vismaz **100 × 70 mm** uz kartīti; vairākas maināmas loksnes | Esoši neapdrukāti papīra dvieļi vai skolas materiāls; nožūšanas metodē saglabāt vienādu izvēli |
| Tīrs trauks un maisīšanas/blendēšanas piederumi | Piemēroti katrai atsevišķai masas partijai | Aizņemties skolā; nav jāpērk jauns blenderis preses komplektam |

Papīra dvieļus nelikt uz gredzena balsta virsmām: tie mainītu mitrās spraugas biezumu. Tie paredzēti žāvēšanai pēc mitrās presēšanas.

## Avotu pārbaudes piezīmes

- Filaments.lv melnā eSUN produkta lapā tieši nolasīta 14,90 € cena ar PVN, 1,75 mm / 1 kg specifikācija un noliktavas skaits. Tajā pašā lapā publicētas Latvijas piegādes cenas un bezmaksas saņemšanas adrese.
- ELEGOO EU produkta lapā tieši nolasīta 13,99 € cena, Latvijas piegādes iespēja, zem 50 € pasūtījuma 15 € tarifs un Latvijas 4–8 darba dienu tabula. Krāsas atlikums nav verificēts.
- REVA katrā produkta lapā norādīta cena un atsevišķi cena bez PVN, tāpēc tabulā izmantota attēlotā gala cena ar PVN. Piegādes informācija neuzrādīja tarifus.
- Motivs produkta lapā tieši nolasīta 6,60 € cena, 10+ atlikums, saņemšana bez maksas un pakomāts no 1,90 €. Precīza gala piegādes summa atkarīga no izvēles.
- Neviena norādītā cita veikala cena vai atlikums neapliecina DEPO Berģi krājumu. Neatbilstoši izstrādājumi (piemēram, PETG loksnes filamenta vietā, 0,1 g svari 0,01 g svaru vietā vai 10 mm sešstūra L atslēga 10 mm uzgriežņu atslēgas vietā) nav izmantoti kā aizvietotāji.
