# Steel backers and forming mesh: sourcing research

Checked 6 October 2026. Preferred shop: **DEPO Berģi**. This is read-only sourcing research: no supplier was contacted, no quote requested, no cart submitted and no order placed. Prices below are public page observations or clearly marked calculations, not supplier quotations. The Metali.lv stock price was refreshed by the coordinating agent later in the same session to €90.00/m²; an earlier page extraction showed €87.00/m² and has been superseded here.

## What is actually verified at DEPO Berģi

**Neither the required 8 mm steel backers nor the required fine forming mesh has a verified DEPO Berģi product price or stock quantity.** The [DEPO online catalog](https://online.depo.lv/) yielded no readable product content through the available page reader, and searches did not identify a primary DEPO listing matching either specification. This is a verification limitation, not evidence that DEPO lacks the materials. National listings and price-comparison results are not Berģi stock confirmation.

Do not substitute thin decorative steel sheet or ordinary mosquito/insect mesh for these parts. The backer needs nominal **8 mm flat steel**, not 0.8 mm decorative sheet. The screen needs **100–200 µm aperture**, not a similarly named 100 mesh-count product with unspecified wire or opening. Two stacked thin steel sheets are not mechanically equivalent to one continuous 8 mm backer unless their assembly is separately designed.

## Steel backers: local sources that can make the actual part

The purchase specification is **2 identical pieces, steel S235/S235JR, 130 × 100 × 8 mm, four outer corners R6, 8 × Ø6.6 mm through-holes per piece, deburred, flat contact faces**. All hole centers are relative to the plate center: (±53, ±38), (0, ±38), (±53, 0) mm. These are clearance holes, not M6 tapped holes. Send the finished backer DXF and technical drawing, rather than only asking for “two small plates.”

| Supplier and verified source | Public price and stock evidence | What it buys | Cost still requiring a quote |
|---|---|---|---|
| [Metāla Alianse / Metali.lv, 8 mm S235 stock, SKU HRS00076](https://www.metali.lv/lv/produkti/loksne-karsti-velmeta/8mm-1500x6000) | Page displays **€90.00 per m²**, stock status **“Noliktavā”**. Nominal parent sheet **8 × 1500 × 6000 mm**. Both VAT-inclusive and VAT-exclusive controls appear; the extracted page does not establish which is selected, so VAT basis must be confirmed. | Raw stock sheet material, not two completed backers. Minimum billable area/quantity is not verified. | Two contours with R6 corners, 16 drilled finished holes, deburring, flatness/finish, job minimum, VAT, delivery/pickup and lead time. |
| [Metāla Alianse cutting services](https://www.metali.lv/lv/pakalpojumi/detalu-izgriesana) and [drilling services](https://www.metali.lv/lv/pakalpojumi/urbsana) | Supplier describes cutting and drilling; no price for this particular geometry is posted. Its [service overview](https://www.metali.lv/lv/pakalpojumi) accepts drawings and lists custom part cutting and drilling. | A real route to order the complete specified pair from the stocked material. | **Quote required** for completed parts. Published raw stock price must not be treated as machining price. |
| [Metāla Bāze, Riga, custom fabrication and delivery](https://metalabaze.lv/pakalpojumi/) | Supplier advertises laser parts from DXF/DWG/STEP/PDF, single parts through series, steel up to 20 mm, drilling/finishing and delivery throughout Latvia. It says a material/processing/delivery offer is normally prepared in one working day. No public price for the specified backers. | Another local supplier able to quote a complete 8 mm pair. Exact 8 mm stock and lead time are not independently confirmed. | **Quote required**, including material, 16 holes, contour cutting, deburring, flatness, VAT and delivery to the user's address. |

Metāla Alianse lists its address as V. Baloža iela 13a, Valmiera. Metāla Bāze lists Vienības gatve 20, Riga. These are alternatives to the user's preferred DEPO Berģi, not claimed DEPO subcontractors.

For scale only, two rectangular blanks cover 2 × 0.130 × 0.100 = **0.026 m²**. At €90/m², their theoretical raw area value is **€2.34** before any minimum billable area, kerf, processing or unresolved VAT. This is **not an available purchase price** for two finished plates. A small custom job's setup/cutting/drilling charges can dominate its raw metal value, so the finished pair's total cannot be responsibly invented from that calculation.

Machining/fit details to include in the quote:

- Supplier to preserve the drawing's hole positions and finished diameter. At 8 mm stock, Ø6.6 mm holes may need drilling or finishing rather than assuming every cutting process produces a clean accurate clearance hole.
- No checker/tread plate, corrugated plate, or heavily bowed scrap. Ask for smooth, burr-free contact faces and state that plate bow matters for a 1 mm pulp gap; request the supplier's proposed flatness and any additional facing/flattening cost.
- Corrosion protection must not create a thick, uneven bearing face or obstruct the PETG outlet grooves. Ordinary S235 can be dried and stored dry; stainless steel is a quoteable corrosion-resistant upgrade with similar stiffness but a different cost.
- Weight is approximately **0.80 kg per finished 8 mm backer**, about **1.6 kg per pair**, before a supplier-specific finish. Shipping a finished small pair is very different from shipping a full 1500 × 6000 mm stock sheet.

## Fine forming mesh: technical matches and public prices

The desired screen is plain-woven stainless steel **AISI 304 / EN 1.4301**, or **AISI 316 / EN 1.4401** as an upgrade; nominal aperture **0.15 mm (150 µm)** and wire diameter **0.10 mm**, often sold as **100 mesh**. Aperture and overall woven thickness are different. About 0.20 mm thickness is an engineering expectation for two over/under wires, **not a verified compressed thickness warranty**. Measure the purchased mesh under the intended load before accepting the mold's 0.40 mm total mesh allowance.

Final fitted pieces: **2 × 84.5 × 54.5 mm, R3 corners**, trimmed to lie entirely inside the 85 × 55 mm cavity and never over the frame stop. Retail rectangle cutting normally does not include R3 trimming. A single **150 × 100 mm** raw screen rectangle can yield two pieces by rotating them: two 54.5 mm widths occupy 109 mm along the 150 mm side, and 84.5 mm fits the 100 mm side. A **200 × 150 mm** rectangle can yield four pieces, providing two spares, with only a small extra material charge compared with shipping.

| Supplier and verified product | Published specification and price | Suggested order quantity | Latvia delivery and total-price limit |
|---|---|---|---|
| [getwiremesh, Germany: V2A 0.15 mm aperture / 0.10 mm wire / mesh 100](https://getwiremesh.com/shop/wiremesh-v2a-1501/) | **€34/m²**, plus **€6 service per cut**; VAT is applied at checkout. Product page identifies AISI 304 / 1.4301. It shows a price update dated 22 July 2026. | **1 × 200 × 150 mm rectangle**, then cut four card screens locally. Published formula gives **€7.02 before VAT and shipping**: €34 × 0.03 m² + €6. A 150 × 100 mm rectangle is €6.51 by the same formula. These are arithmetic estimates from the displayed tariff, not a submitted custom-size checkout. | Product and [supplier homepage](https://getwiremesh.com/) explicitly advertise worldwide DHL delivery, with custom widths 100–1000 mm. Latvia therefore falls within the stated service area. **Latvia shipping fee, checkout VAT, minimum size validation, live stock, dispatch time and final total remain unverified.** |
| [Metal Market, V2A 1.4301 fine sieve/filter mesh, SKU 24013](https://metal-market.eu/en/products/stainless-steel-sieve-filter-mesh-0-15-mm-mesh-100-v2a-1-4301-made-to-measure) | Product gives **0.15 mm aperture, 0.10 mm wire, mesh 100**, custom cut, and displays **€7 tax included**. The reader does not expose which dimensions that amount represents. Both a “Sold out” label and an “Add to cart” element appear; availability cannot be determined from the extracted text. | Request/configure **1 × 200 × 150 mm rectangle**, or the smallest accepted rectangle containing two card pieces. **Do not present €7 as the confirmed price of that selected size.** | [Official shipping policy](https://metal-market.eu/policies/shipping-policy): rest of EU **€11 shipping**, no minimum order value, usual transit approximately 1–9 working days. Latvia is also in the country selector. **Size-specific item amount + €11** is the publicly supported price structure; exact delivered total and stock still need confirmation. |
| [EuroSitex Latvia, stainless technical wire cloth](https://eurositex.lv/lv/Produkcija/stieples-siets--tehniskais-audums-%28stieple-lidz-1_4-mm%29/16/nerusejosie-stieplu-sieti/78/) | Supplier lists 1.4301 stainless, aperture range 0.020–10 mm, wire range 0.020–2 mm. It says standard widths are 1–2 m and purchase length starts at **1 m**; exact 0.15/0.10 grade stock is not confirmed. | Ask whether a small offcut, sample or two cut pieces are possible before buying the stated 1 m length. | A Latvian technical supplier in Daugavpils; [inquiry page](https://eurositex.lv/lv/pieprasijums) exists. **Quote required** for exact grade, minimum quantity, cutting and local delivery. No public exact price obtained. |

The public Metal Market €7 starting amount plus €11 shipping is **not a verified €18 delivered solution**, because its custom dimensions and stock remain unresolved. Likewise, getwiremesh's €7.02 tariff calculation is **not a final delivered total**. These limits should remain explicit in a shopping list rather than silently supplying an attractive but unsupported number.

A secondary German listing from the same named operator, [Drahtgeflecht-Shop 0.15/0.10 mesh](https://www.drahtgeflecht-shop.de/shop/drahtgeflecht-mit-015mm-maschenweite-01mm-drahtstaerke/), displays €34/m² and €6 cutting/packing with 19% German VAT included. This differs from getwiremesh's checkout-VAT presentation; do not mix the two stores' tax bases or combine one store's item price with another store's shipping fee.

## Choices that need recalibration

- Ordinary insect mesh cannot be accepted based on its name or price. Verify aperture in µm, wire diameter and compressed thickness. Coarse mesh can lose fines through the drainage system and mark the card more strongly.
- A 0.10 mm aperture stainless fabric woven with 0.063 mm wire, as offered by some technical suppliers, is an alternative **filter grade**, but its expected thickness is about 0.126 mm rather than 0.20 mm. Two such screens could shift the actual wet pulp gap by roughly 0.15 mm with the existing frames. The exact amount must be measured; do not replace mesh and retain the nominal gap claims without recalibration.
- Nylon/polyester filter fabric with a specified 100–200 µm opening can be tested for forming, but its weave thickness and compressibility are not equivalent to stainless 100 mesh. No exact low-cost Latvian fabric purchase with a verified price and compressed thickness was found in this search.

## Copyable specifications for obtaining prices

**Backer quote text (no message sent):**

> Please quote two identical S235/S235JR steel backers, nominal 130 × 100 × 8 mm, outside corners R6, with eight Ø6.6 mm through clearance holes in each part, using the attached DXF and current technical drawing. Deburr both faces and all edges. These are flat support plates for a small room-temperature pulp press; please state achievable flatness and any facing/flattening charge. Please itemize material, contour cutting, 16 finished holes, finishing, minimum/setup charge, VAT and delivery to Latvia, and confirm availability and lead time. The material must be a continuous flat 8 mm plate.

**Mesh quote/configuration text (no message sent):**

> Please quote one 200 × 150 mm rectangle of plain-woven AISI 304 / EN 1.4301 stainless screen, nominal aperture 0.15 mm and wire diameter 0.10 mm, approximately 100 mesh. It will be locally trimmed into four 84.5 × 54.5 mm R3 card screens. Please confirm mesh aperture, wire diameter, overall thickness/tolerance, availability, minimum order and the total with VAT and delivery to Latvia. If custom card outlines are available, please quote two 84.5 × 54.5 mm R3 pieces separately.

The quoted paragraphs specify engineering requirements authored for this project. They are not supplier instructions copied from a website, and have not been sent to anyone.
