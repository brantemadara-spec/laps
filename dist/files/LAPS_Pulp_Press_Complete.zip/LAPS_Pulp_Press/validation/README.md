# iPhone AR delivery validation

The final iPhone files are `../ar/Pulp_Press_assembled.usdz` and `../ar/Pulp_Press_exploded.usdz`. Download either USDZ to the iPhone, open it in Files or Safari, then choose **AR** in Apple's Quick Look viewer. The assembled file is the easiest way to check the press's real size. A compatible iPhone and an environment where AR surface detection works are required. No iPhone hardware test was performed in this workspace.

Both files passed structural validation with Pixar USD 26.8: 28 official USD schema validators, resolved material and relationship connections, finite mesh points and extents, correct physical dimensions, contained assets, ZIP CRC, uncompressed archive entries, and 64-byte data alignment. They contain a single binary USD layer with no texture dependencies. The root prim is `/PulpPress`, the up axis is **Y**, and `metersPerUnit` is explicitly **1**. Mesh coordinates are in metres.

| File | X width | Y height | Z depth | Meshes | Triangles |
| --- | ---: | ---: | ---: | ---: | ---: |
| Assembled | 130 mm | 64 mm | 100 mm | 48 | 141,592 |
| Exploded | 162 mm | 156 mm | 100 mm | 13 | 132,632 |

The assembled footprint is verified against **130 × 100 mm** with a tolerance of 0.2 mm. The exploded view is intentionally wider and taller because its parts and reference fastener are separated. These extents include the illustrated hardware; they are not the cavity dimensions or the pressed card thickness.

## Scale and export workflow

The CAD STL sources use millimetres. The Blender build bakes a **0.001** multiplier into the imported vertex coordinates: 130 mm becomes 0.130 m. The Blender scene uses metric units with `scale_length = 1`. Blender's GLB exporter maps Blender's **Z-up** coordinates into glTF's **Y-up** coordinates. The GLB-to-USDZ converter retains that Y-up basis and writes `metersPerUnit = 1`. It does not apply another millimetre conversion. All GLB world transforms are baked into the USD mesh points. The model is placed with its lowest point at Y = 0 for Quick Look floor placement.

The available Blender 4.3.2 binary was compiled without USD support (`bpy.app.build_options.usd` is false). The alternative export pipeline uses Blender's GLB export, then `glb_to_usdz.py` with Pixar USD's `CreateNewARKitUsdzPackage`. PBR base colour, opacity, roughness and metallic values are represented with USD PreviewSurface. This converter intentionally rejects textured GLB materials because this design needs only solid colours; it does not silently discard textures.

To reproduce the USDZ files, install `usd-core==26.8`, `trimesh==5.1.1`, `numpy`, and `pillow` into your Python environment. A `vendor` directory exists only for execution in this workspace and should not be included in the project download.

```sh
python validation/glb_to_usdz.py ar/Pulp_Press_assembled.glb ar/Pulp_Press_assembled.usdz
python validation/glb_to_usdz.py ar/Pulp_Press_exploded.glb ar/Pulp_Press_exploded.usdz
python validation/inspect_usdz.py ar/Pulp_Press_assembled.usdz --footprint-mm 130 100 --report validation/assembled_usdz_report.json
python validation/inspect_usdz.py ar/Pulp_Press_exploded.usdz --report validation/exploded_usdz_report.json
```

These commands assume the working directory is the `pulp_press` folder. The two JSON reports preserve the detailed results. A small 130 × 100 × 24 mm box was also converted as an independent pipeline smoke check. Structural validation confirms package and scale correctness, but does not establish actual AR rendering on an iPhone or mechanical suitability of the press.
