# Blender render denoising

These PNGs originate from the supplied Blender scene and Cycles renderer. The available Blender binary lacks Open Image Denoise support, so optional noise cleanup is performed by Intel Open Image Denoise **2.5.1** as a separate render-processing step. This uses the **RT** filter in **LDR + sRGB**, high-quality CPU mode. No generative image editing, new geometry, resizing, cropping, or image redrawing is involved. The original PNG alpha channel is retained.

The `oidnDenoise` executable accepts PFM files rather than PNG. `denoise_render.py` reads a PNG into float RGB, writes a little-endian PFM, runs OIDN, and restores the output to PNG with the original dimensions and alpha. The current Blender PNGs are display-referred AgX output; the sRGB flag lets OIDN process this colour space correctly. These colour-only inputs do not have albedo or normal guide passes, so very fine detail may soften slightly. Inspect the cleaned image when deciding whether to use it.

The 45-degree preview at `render_tools/01_assembled_45deg_denoised.png` preserves **1600 × 1200** pixels. The actual OIDN run took **8.6 seconds** using eight CPU threads. Average RGB change was **1.44 levels out of 255**; noise on broad plate faces and the background was visibly reduced. Plate outlines, hexagonal nuts, spacer edges, and drainage slots remained present. The original render was not overwritten when producing this preview.

All **seven delivered PNG views**, numbered 01 through 07 in `renders`, were subsequently processed with this same high-quality filter. Every file retains **1600 × 1200** pixels and its original alpha channel. Each final file's SHA-256 digest was checked against the processed output recorded in `denoising_report.json`. Average RGB changes range from **0.62 to 1.89 levels out of 255**. Visual inspection confirmed readable plate and spacer silhouettes, bolt holes, drainage grooves, spacer labels, and all **77 holes** in the open-mold view. Revised view 02 uses the enlarged studio backdrop rendered by Blender before denoising. Exact raw Blender PNG backups remain in the execution workspace under `render_tools/raw_renders` and are excluded from the project download.

Retain this instruction file and `denoise_render.py` in the download. Exclude the `render_tools` directory, which contains the downloaded binary, library dependencies, archive, and development preview.

## Reproduce

Use Python with `numpy` and `Pillow`. Download the official Linux binary archive from:

<https://github.com/RenderKit/oidn/releases/download/v2.5.1/oidn-2.5.1.x86_64.linux.tar.gz>

Extract it under `validation/render_tools`, so the executable is at `validation/render_tools/oidn-2.5.1.x86_64.linux/bin/oidnDenoise`. Then run from the `pulp_press` directory:

```sh
python validation/denoise_render.py renders/01_assembled_45deg.png renders/01_assembled_45deg_clean.png --threads 8
```

The same command can be repeated for other render views. Choose an output path different from the input when comparing results. `--strength 0.8` mixes 80% of the cleaned colour with 20% of the original if you prefer lighter cleanup. `--oidn /path/to/oidnDenoise` overrides the expected binary location for another installation. Final geometry and camera configuration remain in the Blender file; the script operates only on rendered colour pixels.
