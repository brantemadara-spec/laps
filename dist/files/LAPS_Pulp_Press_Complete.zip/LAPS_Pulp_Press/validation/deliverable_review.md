# Independent deliverable review

Reviewed 6 October 2026 against `data/cad_dimensions.json`.

- Visually inspected all eight technical-drawing PDF pages at 1600 px and the corrected spacer page at 1800 px. Main labels and dimensions are legible. The spacer opening dimension/bolt-hole overlap and assembly spacer leader were corrected by the drawing author.
- Drawings agree with the CAD on the 130 × 100 mm footprint, 85 × 55 mm R3 cavity, 12 mm PETG platens, 8 mm steel backers, eight Ø6.6 bolt holes, 77 Ø2 drainage holes, and 1.6 × 1.2 mm rear grooves. The 3 mm wet-gap example has a 43.4 mm plate/backer stack, excluding hardware.
- All five spacer heights are 1.4, 2.4, 3.4, 4.4 and 5.4 mm. Their nominal 1–5 mm wet-gap labels depend on two measured screens, each assumed 0.20 mm thick under compression. The drawings explicitly distinguish wet gap from final dry thickness and instruct use of one ring at a time.
- Reviewed Blender assembly script transforms, metres conversion, mirrored upper platen, mesh placement and purchased hardware. No major geometry/assembly error found in this source review. Renderer and USDZ validation are separate checks.
- Checked the engineering pressure arithmetic and stiffness discussion. Rounded cavity area is 4667.274 mm²; 0.05/0.10/0.20 MPa correspond to 233/467/933 N before stop contact. Beam-screening figures are consistent with their stated assumptions and are clearly not a tested load rating or an optimum pressure.
- Stale engineering groove dimensions and print-orientation wording were reported to the root author for harmonization. Final guide agrees with CAD: 1.6 × 1.2 mm grooves, drainage back down, pulp face up; bridge and clear the narrow rear channels, then measure/lap faces as needed.
- Read the full manufacturing/experiment guide and visually inspected all ten PDF pages at 1400 px. No clipped text, overlapping tables or major numerical contradictions found. The wet/dry limitation is prominent on page 1 and the dry-thickness calibration section. Mesh allowances, pressure-before-stop limits, bolt-only gap mode, physical validation limits and printing assumptions are clear. The custom 3.8 mm wet-gap / 4.2 mm ring example matches the CAD source parameters.

This review does not validate physical load capacity, PETG print strength, drying performance or a paper/leaf recipe.

## Standalone native Blender script

Independently reviewed the paste-and-run script and its seven binary STL files in Blender 4.3.2. A first Boolean issue caused duplicate numerical vertices at drain rims; the author corrected this with rounded cutter coordinates and a very small Boolean weld, while retaining closed-mesh checks.

The final independent STL check confirms one connected closed component, consistent winding, positive volume and no zero-area triangles per file. Bounds match 130 × 100 mm and the expected 12 / 1.4 / 2.4 / 3.4 / 4.4 / 5.4 mm heights. Native mesh volumes differ by less than 0.02% from the original CAD STLs, as expected for different circular tessellations.

258 BVH ray checks confirm all 77 drain holes and 8 bolt holes per platen, all nine rear groove segments, 1.2 mm groove floors and intact 12 mm upper faces. They also check all five 85 × 55 mm ring openings, R3 corner bands and bolt holes. Running the script twice preserves an ordinary pre-existing scene object and an unmarked object added to the generated scene, while rebuilding exactly seven generated parts.

Reproducible check: `review_native_blender_stl.py`; results: `native_blender_independent_review.json`. No third-party Python dependency was needed for these Blender checks.
