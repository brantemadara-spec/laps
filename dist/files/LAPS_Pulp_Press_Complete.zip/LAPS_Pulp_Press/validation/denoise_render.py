#!/usr/bin/env python3
"""Denoise a Blender LDR PNG with Intel Open Image Denoise's RT filter.

No rendering, generative editing, resizing, cropping, or geometry replacement.
RGB is processed in sRGB mode; the original alpha channel is retained.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import tempfile

import numpy as np
from PIL import Image


def write_pfm(path, rgb):
    height, width, _ = rgb.shape
    with Path(path).open("wb") as f:
        f.write(f"PF\n{width} {height}\n-1.0\n".encode("ascii"))
        f.write(np.flipud(rgb).astype("<f4").tobytes())


def read_pfm(path):
    with Path(path).open("rb") as f:
        if f.readline().strip() != b"PF":
            raise ValueError("Expected three-channel PFM")
        width, height = map(int, f.readline().split())
        scale = float(f.readline())
        dtype = "<f4" if scale < 0 else ">f4"
        rgb = np.frombuffer(f.read(), dtype=dtype)
        if len(rgb) != width * height * 3:
            raise ValueError("PFM pixel count mismatch")
        return np.flipud(rgb.reshape(height, width, 3)).copy()


def denoise(input_path, output_path, oidn, threads=8, strength=1.0):
    if not 0 <= strength <= 1:
        raise ValueError("strength must be from 0 to 1")
    original = Image.open(input_path)
    rgba = np.asarray(original.convert("RGBA"), dtype=np.uint8)
    rgb = rgba[:, :, :3].astype(np.float32) / 255
    with tempfile.TemporaryDirectory(prefix="pulp-oidn-") as temporary:
        input_pfm = Path(temporary) / "input.pfm"
        output_pfm = Path(temporary) / "output.pfm"
        write_pfm(input_pfm, rgb)
        command = [str(oidn), "--device", "cpu", "--filter", "RT", "--ldr", str(input_pfm), "--srgb", "--quality", "high", "--threads", str(threads), "--output", str(output_pfm)]
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        denoised = read_pfm(output_pfm)
    if denoised.shape != rgb.shape or not np.isfinite(denoised).all():
        raise ValueError("Denoiser produced incorrect dimensions or nonfinite pixels")
    processed = np.clip(rgb * (1 - strength) + denoised * strength, 0, 1)
    rgba_out = rgba.copy()
    rgba_out[:, :, :3] = np.rint(processed * 255).astype(np.uint8)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    save_options = {"compress_level": 6}
    if "icc_profile" in original.info:
        save_options["icc_profile"] = original.info["icc_profile"]
    Image.fromarray(rgba_out).save(output_path, **save_options)
    delta = np.abs(rgba_out[:, :, :3].astype(float) - rgba[:, :, :3].astype(float))
    return {"input": str(input_path), "output": str(output_path), "dimensions": list(original.size), "strength": strength, "alpha_preserved": bool(np.array_equal(rgba_out[:, :, 3], rgba[:, :, 3])), "mean_absolute_RGB_change_8bit": float(delta.mean()), "max_RGB_change_8bit": float(delta.max()), "method": "Intel Open Image Denoise 2.5.1 RT filter, CPU, LDR+sRGB, high quality", "tool_stdout": result.stdout.strip(), "tool_stderr": result.stderr.strip()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--oidn", type=Path, default=Path(__file__).resolve().parent / "render_tools/oidn-2.5.1.x86_64.linux/bin/oidnDenoise")
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--strength", type=float, default=1.0)
    args = parser.parse_args()
    print(json.dumps(denoise(args.input, args.output, args.oidn, args.threads, args.strength), indent=2))
