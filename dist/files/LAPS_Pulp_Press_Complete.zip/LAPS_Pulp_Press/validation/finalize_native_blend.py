import bpy
from pathlib import Path
root=Path('/workspace/pulp_press')
code=root/'blender/LAPS_Blender_Prototips.py'
text=bpy.data.texts.get(code.name) or bpy.data.texts.load(str(code))
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='TEXT_EDITOR':
            area.spaces.active.text=text
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(root/'blender/prototype_generated/LAPS_Prototips.blend'))
print('Embedded standalone source in saved prototype Blender file.')
