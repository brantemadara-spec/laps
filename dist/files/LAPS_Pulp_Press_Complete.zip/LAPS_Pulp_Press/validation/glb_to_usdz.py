#!/usr/bin/env python3
"""Convert a meter-scale, Y-up GLB into a self-contained iPhone AR USDZ.

This deliberately supports the untextured PBR meshes used by this project.
All GLB world transforms are baked, eliminating unsupported transform issues.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

VENDOR = Path(__file__).resolve().parent / "vendor"
if VENDOR.is_dir():
    sys.path.insert(0, str(VENDOR))

import numpy as np
import trimesh
from pxr import Gf, Kind, Sdf, Tf, Usd, UsdGeom, UsdShade, UsdUtils, Vt


def material_properties(mesh):
    material = getattr(mesh.visual, "material", None)
    if material is not None and getattr(material, "baseColorTexture", None) is not None:
        raise ValueError("Textured GLB material is unsupported by this project's converter")
    base = getattr(material, "baseColorFactor", None)
    if base is None:
        base = getattr(mesh.visual, "main_color", [70, 170, 170, 255])
    base = np.asarray(base, dtype=float)
    if base.max() > 1:
        base /= 255.0
    metallic = getattr(material, "metallicFactor", 0.0)
    roughness = getattr(material, "roughnessFactor", 0.5)
    return base, 0.0 if metallic is None else metallic, 0.5 if roughness is None else roughness


def convert(source: Path, target: Path, *, ground: bool = True) -> dict:
    scene = trimesh.load_scene(source, process=False)
    meshes = []
    for node_name in scene.graph.nodes_geometry:
        transform, geom_name = scene.graph[node_name]
        original = scene.geometry[geom_name]
        if not isinstance(original, trimesh.Trimesh):
            continue
        mesh = original.copy()
        mesh.apply_transform(transform)
        if len(mesh.faces) == 0:
            continue
        if not np.isfinite(mesh.vertices).all():
            raise ValueError(f"Nonfinite mesh points: {node_name}")
        meshes.append((str(node_name), mesh))
    if not meshes:
        raise ValueError("GLB does not contain any triangle meshes")

    all_vertices = np.vstack([m.vertices for _, m in meshes])
    ground_offset = -float(all_vertices[:, 1].min()) if ground else 0.0
    target.parent.mkdir(parents=True, exist_ok=True)
    usd_file = target.with_suffix(".usdc")
    stage = Usd.Stage.CreateNew(str(usd_file))
    UsdGeom.SetStageMetersPerUnit(stage, 1.0)
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.y)
    root = UsdGeom.Xform.Define(stage, "/PulpPress")
    stage.SetDefaultPrim(root.GetPrim())
    Usd.ModelAPI(root.GetPrim()).SetKind(Kind.Tokens.component)
    Usd.ModelAPI(root.GetPrim()).SetAssetName(target.stem)
    root.GetPrim().SetCustomDataByKey("description", "Reusable paper and autumn-leaf pulp press, 85 by 55 mm card cavity")
    UsdGeom.Scope.Define(stage, "/PulpPress/Materials")

    material_cache = {}
    for index, (name, mesh) in enumerate(meshes):
        path = "/PulpPress/" + Tf.MakeValidIdentifier(name) + f"_{index:03d}"
        usd_mesh = UsdGeom.Mesh.Define(stage, path)
        vertices = mesh.vertices.copy()
        vertices[:, 1] += ground_offset
        usd_mesh.CreatePointsAttr(Vt.Vec3fArray.FromNumpy(vertices.astype(np.float32)))
        usd_mesh.CreateFaceVertexCountsAttr(Vt.IntArray([3] * len(mesh.faces)))
        usd_mesh.CreateFaceVertexIndicesAttr(Vt.IntArray.FromNumpy(mesh.faces.flatten().astype(np.int32)))
        usd_mesh.CreateSubdivisionSchemeAttr(UsdGeom.Tokens.none)
        usd_mesh.CreateOrientationAttr(UsdGeom.Tokens.rightHanded)
        usd_mesh.CreateDoubleSidedAttr(True)
        usd_mesh.CreateNormalsAttr(Vt.Vec3fArray.FromNumpy(np.asarray(mesh.vertex_normals, dtype=np.float32)))
        usd_mesh.SetNormalsInterpolation(UsdGeom.Tokens.vertex)
        bounds = np.vstack([vertices.min(axis=0), vertices.max(axis=0)])
        usd_mesh.CreateExtentAttr(Vt.Vec3fArray.FromNumpy(bounds.astype(np.float32)))
        color, metallic, roughness = material_properties(mesh)
        usd_mesh.CreateDisplayColorAttr([Gf.Vec3f(*map(float, color[:3]))])
        key = tuple(color) + (float(metallic), float(roughness))
        if key not in material_cache:
            material = UsdShade.Material.Define(stage, f"/PulpPress/Materials/Material_{len(material_cache):02d}")
            shader = UsdShade.Shader.Define(stage, material.GetPath().AppendChild("PreviewSurface"))
            shader.CreateIdAttr("UsdPreviewSurface")
            shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*map(float, color[:3])))
            shader.CreateInput("opacity", Sdf.ValueTypeNames.Float).Set(float(color[3]) if len(color) > 3 else 1.0)
            shader.CreateInput("metallic", Sdf.ValueTypeNames.Float).Set(float(metallic))
            shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(float(roughness))
            shader.CreateOutput("surface", Sdf.ValueTypeNames.Token)
            material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
            material_cache[key] = material
        binding = UsdShade.MaterialBindingAPI.Apply(usd_mesh.GetPrim())
        binding.Bind(material_cache[key])
    stage.GetRootLayer().Save()
    del stage
    if target.exists():
        target.unlink()
    if not UsdUtils.CreateNewARKitUsdzPackage(Sdf.AssetPath(str(usd_file)), str(target)):
        raise RuntimeError("USD ARKit packaging failed")
    usd_file.unlink()
    bounds = all_vertices.max(axis=0) - all_vertices.min(axis=0)
    return {
        "source": str(source), "target": str(target), "mesh_count": len(meshes),
        "dimensions_metres_XYZ": bounds.tolist(), "up_axis": "Y", "meters_per_unit": 1.0,
        "ground_translation_metres": ground_offset,
    }


if __name__ == "__main__":
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("glb", type=Path)
    parser.add_argument("usdz", type=Path)
    parser.add_argument("--keep-origin", action="store_true", help="Keep the original GLB origin instead of putting the model's lowest point on the floor")
    args = parser.parse_args()
    print(json.dumps(convert(args.glb, args.usdz, ground=not args.keep_origin), indent=2))
