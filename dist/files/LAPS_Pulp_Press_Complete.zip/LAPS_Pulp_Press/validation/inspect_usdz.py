#!/usr/bin/env python3
"""Validate self-contained USDZ mesh data, archive format, and physical scale.

This is a structural validation, not a test on an iPhone.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import struct
import sys
import zipfile

VENDOR = Path(__file__).resolve().parent / "vendor"
if VENDOR.is_dir():
    sys.path.insert(0, str(VENDOR))

import numpy as np
from pxr import Sdf, Usd, UsdGeom, UsdShade, UsdValidation


def inspect(path: Path, footprint_mm=None, tolerance_mm=0.2) -> dict:
    errors, warnings = [], []
    archive_entries = []
    archive_names = set()
    with path.open("rb") as handle, zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        if not entries or Path(entries[0].filename).suffix.lower() not in {".usd", ".usda", ".usdc"}:
            errors.append("First archive entry is not a USD layer")
        for entry in entries:
            archive_names.add(entry.filename)
            handle.seek(entry.header_offset)
            header = handle.read(30)
            if len(header) != 30 or header[:4] != b"PK\x03\x04":
                errors.append(f"Invalid local ZIP header: {entry.filename}")
                continue
            fields = struct.unpack("<IHHHHHIIIHH", header)
            offset = entry.header_offset + 30 + fields[-2] + fields[-1]
            if entry.compress_type != zipfile.ZIP_STORED:
                errors.append(f"Compressed archive entry: {entry.filename}")
            if offset % 64:
                errors.append(f"Archive data is not aligned to 64 bytes: {entry.filename}")
            if entry.flag_bits & 1:
                errors.append(f"Encrypted archive entry: {entry.filename}")
            archive_entries.append({"name": entry.filename, "bytes": entry.file_size, "data_offset": offset, "alignment_remainder": offset % 64, "compression": entry.compress_type})
        damaged = archive.testzip()
        if damaged:
            errors.append(f"ZIP CRC check failed: {damaged}")

    stage = Usd.Stage.Open(str(path))
    if not stage:
        return {"file": str(path), "valid": False, "errors": errors + ["Could not open USD stage"], "warnings": warnings}
    validators = UsdValidation.ValidationRegistry().GetOrLoadAllValidators()
    schema_issues = UsdValidation.ValidationContext(validators).Validate(stage)
    for issue in schema_issues:
        if issue.GetType() == UsdValidation.ValidationErrorType.Error:
            errors.append(issue.GetErrorAsString())
        elif issue.GetType() == UsdValidation.ValidationErrorType.Warn:
            warnings.append(issue.GetErrorAsString())
    units = UsdGeom.GetStageMetersPerUnit(stage)
    axis = str(UsdGeom.GetStageUpAxis(stage))
    if not np.isfinite(units) or units <= 0:
        errors.append(f"Invalid metersPerUnit: {units}")
    if not stage.GetDefaultPrim():
        errors.append("Missing defaultPrim")
    if not stage.HasAuthoredMetadata("metersPerUnit"):
        errors.append("metersPerUnit is not explicitly authored")
    if not stage.HasAuthoredMetadata("upAxis"):
        errors.append("upAxis is not explicitly authored")
    if axis not in {"Y", "Z"}:
        errors.append(f"Unsupported up axis: {axis}")

    meshes, point_clouds = [], []
    xforms = UsdGeom.XformCache(Usd.TimeCode.Default())
    for prim in stage.Traverse():
        for attr in prim.GetAttributes():
            value = attr.Get()
            assets = []
            if isinstance(value, Sdf.AssetPath):
                assets = [value]
            elif attr.GetTypeName() == Sdf.ValueTypeNames.AssetArray and value is not None:
                assets = list(value)
            for asset in assets:
                if asset.path and not asset.resolvedPath:
                    errors.append(f"Unresolved asset: {prim.GetPath()} {attr.GetName()}={asset.path}")
                if asset.path.startswith(("/", "http:", "https:", "file:")):
                    errors.append(f"External asset path: {asset.path}")
            for connection in attr.GetConnections():
                if not stage.GetObjectAtPath(connection):
                    errors.append(f"Broken attribute connection: {connection}")
        for relationship in prim.GetRelationships():
            for target in relationship.GetTargets():
                if not stage.GetObjectAtPath(target):
                    errors.append(f"Broken relationship target: {target}")
        for arc_name in ("references", "payload"):
            arc = prim.GetMetadata(arc_name)
            if arc is not None:
                for item in arc.GetAppliedItems():
                    if item.assetPath and item.assetPath not in archive_names:
                        errors.append(f"External {arc_name} arc: {item.assetPath}")
        if not prim.IsA(UsdGeom.Mesh):
            continue
        mesh = UsdGeom.Mesh(prim)
        points = np.asarray(mesh.GetPointsAttr().Get(), dtype=np.float64)
        indices = np.asarray(mesh.GetFaceVertexIndicesAttr().Get(), dtype=np.int64)
        counts = np.asarray(mesh.GetFaceVertexCountsAttr().Get(), dtype=np.int64)
        if points.ndim != 2 or points.shape[1] != 3 or not len(points) or not np.isfinite(points).all():
            errors.append(f"Invalid mesh points: {prim.GetPath()}")
            continue
        if not len(counts) or (counts < 3).any() or counts.sum() != len(indices):
            errors.append(f"Invalid face topology: {prim.GetPath()}")
        if len(indices) and (indices.min() < 0 or indices.max() >= len(points)):
            errors.append(f"Mesh face index outside points array: {prim.GetPath()}")
        extent = np.asarray(mesh.GetExtentAttr().Get(), dtype=np.float64)
        computed = np.vstack([points.min(axis=0), points.max(axis=0)])
        if extent.shape != (2, 3) or not np.isfinite(extent).all() or not np.allclose(extent, computed, atol=1e-6):
            errors.append(f"Invalid or incorrect authored extent: {prim.GetPath()}")
        normals = mesh.GetNormalsAttr().Get()
        if normals is not None and not np.isfinite(np.asarray(normals)).all():
            errors.append(f"Nonfinite normals: {prim.GetPath()}")
        binding = UsdShade.MaterialBindingAPI(prim)
        material, _ = binding.ComputeBoundMaterial()
        if not material:
            errors.append(f"No bound material: {prim.GetPath()}")
        else:
            shader, _, _ = material.ComputeSurfaceSource()
            if not shader or shader.GetIdAttr().Get() != "UsdPreviewSurface":
                errors.append(f"No supported preview surface: {prim.GetPath()}")
        transform = xforms.GetLocalToWorldTransform(prim)
        matrix = np.asarray(transform)
        homogeneous = np.column_stack([points, np.ones(len(points))])
        world_points = (homogeneous @ matrix)[:, :3]
        if not np.isfinite(world_points).all():
            errors.append(f"Nonfinite world points: {prim.GetPath()}")
        point_clouds.append(world_points)
        meshes.append({"path": str(prim.GetPath()), "vertices": len(points), "faces": len(counts), "material": str(material.GetPath()) if material else None})

    dimensions, bounds = None, None
    if point_clouds:
        world = np.vstack(point_clouds)
        bounds = np.vstack([world.min(axis=0), world.max(axis=0)]) * units * 1000
        dimensions = bounds[1] - bounds[0]
        if (dimensions <= 0).any() or (dimensions > 5000).any():
            errors.append("Physical dimensions are empty or exceed a 5 m school-project model")
        if footprint_mm is not None:
            horizontal = dimensions[[0, 2]] if axis == "Y" else dimensions[[0, 1]]
            if not np.allclose(np.sort(horizontal), np.sort(footprint_mm), atol=tolerance_mm, rtol=0):
                errors.append(f"Horizontal footprint {horizontal.tolist()} mm does not match {list(footprint_mm)} mm within {tolerance_mm} mm")
    else:
        errors.append("No mesh prims found")
    return {
        "file": str(path), "valid": not errors, "validation_scope": "Structural USDZ, USD mesh and material integrity, package containment, and measured physical scale; no iPhone hardware test",
        "errors": errors, "warnings": warnings, "meters_per_unit": units, "up_axis": axis,
        "default_prim": str(stage.GetDefaultPrim().GetPath()) if stage.GetDefaultPrim() else None,
        "dimensions_mm_XYZ": dimensions.tolist() if dimensions is not None else None,
        "bounds_mm": bounds.tolist() if bounds is not None else None,
        "mesh_count": len(meshes), "total_triangles": sum(m["faces"] for m in meshes),
        "usd_schema_validators_run": len(validators),
        "meshes": meshes, "archive_entries": archive_entries,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("files", type=Path, nargs="+")
    parser.add_argument("--footprint-mm", type=float, nargs=2, metavar=("WIDTH", "DEPTH"))
    parser.add_argument("--tolerance-mm", type=float, default=0.2)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    results = [inspect(p.resolve(), args.footprint_mm, args.tolerance_mm) for p in args.files]
    output = json.dumps(results, indent=2)
    if args.report:
        args.report.write_text(output + "\n")
    print(output)
    sys.exit(0 if all(r["valid"] for r in results) else 1)
