"""Independent binary-STL topology, dimensional and feature checks in Blender."""
import bpy, bmesh, struct, json, math, runpy
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

ROOT=Path('/workspace/pulp_press')
OUT=ROOT/'blender/prototype_generated/STL'
CAD=json.loads((ROOT/'data/cad_dimensions.json').read_text())
REPORT={'parts':[], 'feature_checks':[], 'rerun_check':{}}

def read_stl(path):
    raw=path.read_bytes(); n=struct.unpack_from('<I',raw,80)[0]
    assert len(raw)==84+50*n, path
    verts=[]; faces=[]; index={}
    for t in range(n):
        values=struct.unpack_from('<12fH',raw,84+50*t)
        face=[]
        for j in (3,6,9):
            co=values[j:j+3]
            if co not in index:
                index[co]=len(verts);verts.append(co)
            face.append(index[co])
        faces.append(face)
    mesh=bpy.data.meshes.new(path.stem+'_review_mesh')
    mesh.from_pydata(verts,[],faces);mesh.update()
    bm=bmesh.new();bm.from_mesh(mesh)
    return mesh,bm

def properties(mesh,bm):
    bounds=[[min(v.co[i] for v in mesh.vertices),max(v.co[i] for v in mesh.vertices)] for i in range(3)]
    remaining=set(bm.verts);components=0
    while remaining:
        components+=1;stack=[remaining.pop()]
        while stack:
            v=stack.pop()
            for edge in v.link_edges:
                other=edge.other_vert(v)
                if other in remaining:remaining.remove(other);stack.append(other)
    return {'bounds_mm':bounds,'dimensions_mm':[b-a for a,b in bounds],
            'volume_mm3':bm.calc_volume(signed=True),'components':components,
            'non_manifold_edges':sum(not e.is_manifold for e in bm.edges),
            'boundary_edges':sum(e.is_boundary for e in bm.edges),
            'inconsistent_winding_edges':sum(e.is_manifold and not e.is_contiguous for e in bm.edges),
            'degenerate_triangles':sum(f.calc_area()<1e-10 for f in bm.faces),
            'triangles':len(bm.faces)}

def ray(bvh,origin,direction,distance=1000):
    return bvh.ray_cast(Vector(origin),Vector(direction),distance)[0]

def add_check(label,passed):
    REPORT['feature_checks'].append({'check':label,'passed':bool(passed)})
    assert passed, label

bolts=CAD['parameters']['bolt_points_xy_mm']
drains=CAD['parameters']['drain_points_xy_mm']
for filename in sorted(OUT.glob('*.stl')):
    mesh,bm=read_stl(filename); props=properties(mesh,bm)
    isplate=filename.name.startswith('plate_')
    gap=None if isplate else int(filename.name.split('_')[1].replace('mm',''))
    cadname='petg_drain_plate_PRINT_2' if isplate else f'gap_ring_{gap}mm_pulp_{gap+.4:.1f}mm_actual_PRINT_1'
    cadmesh,cadbm=read_stl(ROOT/'cad'/(cadname+'.stl'))
    cadprops=properties(cadmesh,cadbm)
    relative=(props['volume_mm3']-cadprops['volume_mm3'])/cadprops['volume_mm3']
    props.update({'file':filename.name,'cad_volume_mm3':cadprops['volume_mm3'],
                  'volume_difference_percent':100*relative})
    REPORT['parts'].append(props)
    assert props['components']==1 and props['non_manifold_edges']==0
    assert props['inconsistent_winding_edges']==0 and props['degenerate_triangles']==0
    assert props['volume_mm3']>0 and abs(relative)<0.0002
    expected=[130,100,12 if isplate else gap+.4]
    assert all(abs(a-b)<1e-5 for a,b in zip(props['dimensions_mm'],expected))
    bvh=BVHTree.FromBMesh(bm)
    top=13 if isplate else gap+1
    for x,y in bolts:
        add_check(f'{filename.name}: bolt ({x},{y}) through and diameter band',
                  all(ray(bvh,(x+dx,y+dy,top),(0,0,-1)) is None for dx,dy in [(0,0),(3,0),(0,3),(-3,0),(0,-3)])
                  and all(ray(bvh,(x+dx,y+dy,top),(0,0,-1)) is not None for dx,dy in [(3.5,0),(0,3.5),(-3.5,0),(0,-3.5)]))
    if isplate:
        for x,y in drains:
            add_check(f'{filename.name}: drain ({x},{y}) through and diameter band',
                      all(ray(bvh,(x+dx,y+dy,13),(0,0,-1)) is None for dx,dy in [(0,0),(.8,0),(0,.8),(-.8,0),(0,-.8)])
                      and all(ray(bvh,(x+dx,y+dy,13),(0,0,-1)) is not None for dx,dy in [(1.2,0),(0,1.2),(-1.2,0),(0,-1.2)]))
        for y in (-21,-14,-7,7,14,21):
            add_check(f'{filename.name}: full-width rear groove y={y} open',ray(bvh,(-66,y,.6),(1,0,0),132) is None)
        add_check(f'{filename.name}: centre rear groove open',ray(bvh,(-46.5,0,.6),(1,0,0),93) is None)
        for x in (-46,46):
            add_check(f'{filename.name}: branch outlet x={x} open',ray(bvh,(x,-51,.6),(0,1,0),51) is None)
        points=[(-60,y) for y in (-21,-14,-7,7,14,21)]+[(40,0),(-46,-40),(46,-40)]
        for x,y in points:
            hit=ray(bvh,(x,y,.6),(0,0,1))
            upper=ray(bvh,(x,y,13),(0,0,-1))
            add_check(f'{filename.name}: groove floor1.2 and upper face12 at({x},{y})',
                      hit is not None and abs(hit.z-1.2)<1e-5 and upper is not None and abs(upper.z-12)<1e-5)
        add_check(f'{filename.name}: material remains beside groove',ray(bvh,(-60,-20,.6),(0,0,-1)) is not None)
    else:
        add_check(f'{filename.name}: 85x55 cavity dimension band',
                  all(ray(bvh,(x,y,top),(0,0,-1)) is None for x,y in [(0,0),(42.4,0),(-42.4,0),(0,27.4),(0,-27.4)])
                  and all(ray(bvh,(x,y,top),(0,0,-1)) is not None for x,y in [(42.6,0),(-42.6,0),(0,27.6),(0,-27.6)]))
        add_check(f'{filename.name}: R3 cavity corner band',
                  ray(bvh,(41.6,26.6,top),(0,0,-1)) is None
                  and ray(bvh,(42,27,top),(0,0,-1)) is not None)
    bm.free();cadbm.free()

# Run the generator twice while preserving both an existing scene object and
# an unmarked user object added to its own generated scene between runs.
default_cube=bpy.data.objects.get('Cube')
ns=runpy.run_path(str(ROOT/'blender/LAPS_Blender_Prototips.py'),run_name='laps_rerun_review')
g=ns['main'].__globals__
g['OUTPUT_DIR']=ROOT/'validation/native_rerun_review'
g['EXPORT_STL']=False;g['SAVE_BLEND']=False
g['main']()
generated_scene=bpy.data.scenes[g['SCENE_NAME']]
sentinel=bpy.data.objects.new('User_Unmarked_Sentinel',None)
generated_scene.collection.objects.link(sentinel)
g['main']()
kept_default=(default_cube is not None and bpy.data.objects.get('Cube')==default_cube)
kept_sentinel=bpy.data.objects.get('User_Unmarked_Sentinel')==sentinel and sentinel.name in generated_scene.objects
generated=[o for o in generated_scene.objects if o.get('generator')==g['TAG']]
REPORT['rerun_check']={'default_user_object_preserved':kept_default,
                       'unmarked_object_in_generated_scene_preserved':kept_sentinel,
                       'generated_part_count_after_second_run':len(generated)}
assert kept_default and kept_sentinel and len(generated)==7
REPORT['passed']=True
(ROOT/'validation/native_blender_independent_review.json').write_text(json.dumps(REPORT,indent=2)+'\n')
print('INDEPENDENT REVIEW PASSED:',len(REPORT['parts']),'STLs;',len(REPORT['feature_checks']),'feature checks; rerun preservation.',flush=True)
